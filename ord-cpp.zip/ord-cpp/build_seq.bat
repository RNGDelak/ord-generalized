@echo off
setlocal enabledelayedexpansion
cd /d C:\Users\DELL\Documents\Qoder\2026-09-27\3a26177d\ord-cpp
set "PATH=C:\Users\DELL\dev\w64devkit\bin;%PATH%"
set "CXXFLAGS=-std=c++17 -O2 -Isrc -Ivendor/glad/include -Ivendor/stb -Ivendor/imgui-1.91.8 -Ivendor/imgui-1.91.8/backends -Ivendor/glfw-3.4/include -D_GLFW_WIN32"
set "CFLAGS=-O2 -Ivendor/glad/include -Ivendor/glfw-3.4/include -D_GLFW_WIN32"
set "LOG=build_seq.log"
echo BUILD START > %LOG%

set "CXXFILES=src/main.cpp src/app.cpp src/engine.cpp src/renderer.cpp src/text.cpp src/bigint.cpp src/json.cpp src/config.cpp src/notations/registry.cpp src/notations/bms.cpp src/notations/worm.cpp src/notations/plprss.cpp src/notations/ebo.cpp vendor/imgui-1.91.8/imgui.cpp vendor/imgui-1.91.8/imgui_draw.cpp vendor/imgui-1.91.8/imgui_tables.cpp vendor/imgui-1.91.8/imgui_widgets.cpp vendor/imgui-1.91.8/misc/cpp/imgui_stdlib.cpp vendor/imgui-1.91.8/backends/imgui_impl_glfw.cpp vendor/imgui-1.91.8/backends/imgui_impl_opengl3.cpp"
set "CFILES=vendor/glad/glad.c vendor/glfw-3.4/src/context.c vendor/glfw-3.4/src/init.c vendor/glfw-3.4/src/input.c vendor/glfw-3.4/src/monitor.c vendor/glfw-3.4/src/platform.c vendor/glfw-3.4/src/vulkan.c vendor/glfw-3.4/src/window.c vendor/glfw-3.4/src/egl_context.c vendor/glfw-3.4/src/osmesa_context.c vendor/glfw-3.4/src/null_init.c vendor/glfw-3.4/src/null_joystick.c vendor/glfw-3.4/src/null_monitor.c vendor/glfw-3.4/src/null_window.c vendor/glfw-3.4/src/wgl_context.c vendor/glfw-3.4/src/win32_init.c vendor/glfw-3.4/src/win32_joystick.c vendor/glfw-3.4/src/win32_module.c vendor/glfw-3.4/src/win32_monitor.c vendor/glfw-3.4/src/win32_thread.c vendor/glfw-3.4/src/win32_time.c vendor/glfw-3.4/src/win32_window.c"

set FAIL=0
for %%f in (%CXXFILES%) do (
    set "SRC=%%f"
    set "OBJ=build\!SRC:/=\!.o"
    for %%d in (!OBJ!) do if not exist "%%~dpd" mkdir "%%~dpd"
    echo [CXX] !SRC! >> %LOG%
    g++ %CXXFLAGS% -c !SRC! -o !OBJ! >> %LOG% 2>&1
    if errorlevel 1 ( echo [FAIL] !SRC! >> %LOG% & set FAIL=1 & goto link )
)
for %%f in (%CFILES%) do (
    set "SRC=%%f"
    set "OBJ=build\!SRC:/=\!.o"
    for %%d in (!OBJ!) do if not exist "%%~dpd" mkdir "%%~dpd"
    echo [CC] !SRC! >> %LOG%
    gcc %CFLAGS% -c !SRC! -o !OBJ! >> %LOG% 2>&1
    if errorlevel 1 ( echo [FAIL] !SRC! >> %LOG% & set FAIL=1 & goto link )
)
:link
if "%FAIL%"=="1" ( echo BUILD_FAILED >> %LOG% & exit /b 1 )
echo [LINK] >> %LOG%
set "OBJS="
for %%f in (%CXXFILES% %CFILES%) do (
    set "SRC=%%f"
    set "OBJS=!OBJS! build\!SRC:/=\!.o"
)
g++ -o ord.exe !OBJS! -lopengl32 -lgdi32 >> %LOG% 2>&1
if errorlevel 1 ( echo LINK_FAILED >> %LOG% & exit /b 1 )
echo BUILD_OK >> %LOG%
