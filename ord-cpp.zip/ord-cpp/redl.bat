@echo off
cd /d C:\Users\DELL\Documents\Qoder\2026-09-27\3a26177d\ord-cpp
echo REDL2 START > redl.log
curl -sL -w "glad.h code=%%{http_code} size=%%{size_download}\n" -o vendor\glad\include\glad\glad.h https://raw.githubusercontent.com/JoeyDeVries/LearnOpenGL/master/includes/glad/glad.h >> redl.log 2>&1
curl -sL -w "khr code=%%{http_code} size=%%{size_download}\n" -o vendor\glad\include\KHR\khrplatform.h https://raw.githubusercontent.com/JoeyDeVries/LearnOpenGL/master/includes/KHR/khrplatform.h >> redl.log 2>&1
echo REDL2 DONE >> redl.log
