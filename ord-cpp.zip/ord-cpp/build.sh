#!/bin/sh
# Sequential build under w64devkit's shell; logs every step.
cd "C:/Users/DELL/Documents/Qoder/2026-09-27/3a26177d/ord-cpp" || exit 1
# GXX_DIR may override the toolchain bin directory (Windows path or /c/... both ok).
BIN="${GXX_DIR:-C:/Users/DELL/dev/w64devkit/bin}"
GXX="$BIN/g++.exe"
GCC="$BIN/gcc.exe"
LOG=build_sh.log
: > "$LOG"
mkdir -p build

CXXFLAGS="-std=c++17 -O2 -Isrc -Ivendor/glad/include -Ivendor/stb -Ivendor/imgui-1.91.8 -Ivendor/imgui-1.91.8/backends -Ivendor/glfw-3.4/include -D_GLFW_WIN32"
CFLAGS="-O2 -Ivendor/glad/include -Ivendor/glfw-3.4/include -D_GLFW_WIN32"

CXXFILES="src/main.cpp src/app.cpp src/engine.cpp src/renderer.cpp src/text.cpp src/bigint.cpp src/json.cpp src/config.cpp src/notations/registry.cpp src/notations/bms.cpp src/notations/worm.cpp src/notations/plprss.cpp src/notations/ebo.cpp vendor/imgui-1.91.8/imgui.cpp vendor/imgui-1.91.8/imgui_draw.cpp vendor/imgui-1.91.8/imgui_tables.cpp vendor/imgui-1.91.8/imgui_widgets.cpp vendor/imgui-1.91.8/misc/cpp/imgui_stdlib.cpp vendor/imgui-1.91.8/backends/imgui_impl_glfw.cpp vendor/imgui-1.91.8/backends/imgui_impl_opengl3.cpp"
CFILES="vendor/glad/glad.c vendor/glfw-3.4/src/context.c vendor/glfw-3.4/src/init.c vendor/glfw-3.4/src/input.c vendor/glfw-3.4/src/monitor.c vendor/glfw-3.4/src/platform.c vendor/glfw-3.4/src/vulkan.c vendor/glfw-3.4/src/window.c vendor/glfw-3.4/src/egl_context.c vendor/glfw-3.4/src/osmesa_context.c vendor/glfw-3.4/src/null_init.c vendor/glfw-3.4/src/null_joystick.c vendor/glfw-3.4/src/null_monitor.c vendor/glfw-3.4/src/null_window.c vendor/glfw-3.4/src/wgl_context.c vendor/glfw-3.4/src/win32_init.c vendor/glfw-3.4/src/win32_joystick.c vendor/glfw-3.4/src/win32_module.c vendor/glfw-3.4/src/win32_monitor.c vendor/glfw-3.4/src/win32_thread.c vendor/glfw-3.4/src/win32_time.c vendor/glfw-3.4/src/win32_window.c"

OBJS=""
fail=0
for f in $CXXFILES; do
    o="build/$(echo "$f" | sed 's|[/.]|_|g').o"
    OBJS="$OBJS $o"
    if [ "$o" -nt "$f" ]; then echo "[SKIP] $f" >> "$LOG"; continue; fi
    echo "[CXX] $f" >> "$LOG"
    if ! "$GXX" $CXXFLAGS -c "$f" -o "$o" >> "$LOG" 2>&1; then
        echo "[FAIL] $f" >> "$LOG"; fail=1; break
    fi
done
if [ $fail -eq 0 ]; then
    for f in $CFILES; do
        o="build/$(echo "$f" | sed 's|[/.]|_|g').o"
        OBJS="$OBJS $o"
        if [ "$o" -nt "$f" ]; then echo "[SKIP] $f" >> "$LOG"; continue; fi
        echo "[CC] $f" >> "$LOG"
        if ! "$GCC" $CFLAGS -c "$f" -o "$o" >> "$LOG" 2>&1; then
            echo "[FAIL] $f" >> "$LOG"; fail=1; break
        fi
    done
fi
if [ $fail -eq 1 ]; then
    echo "BUILD_FAILED" >> "$LOG"; exit 1
fi
echo "[LINK]" >> "$LOG"
# Collect any leftover older flat objects too (in case lists changed)
if ! "$GXX" -o ord.exe $OBJS -lopengl32 -lgdi32 >> "$LOG" 2>&1; then
    echo "LINK_FAILED" >> "$LOG"; exit 1
fi
echo "BUILD_OK" >> "$LOG"
