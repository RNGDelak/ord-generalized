@echo off
cd /d C:\Users\DELL\Documents\Qoder\2026-09-27\3a26177d\ord-cpp
set "PATH=C:\Users\DELL\dev\w64devkit\bin;%PATH%"
echo TEST START > syntax_app.log
g++ --version >> syntax_app.log 2>&1
echo rc_version=%errorlevel% >> syntax_app.log
g++ -std=c++17 -O0 -fsyntax-only -Isrc -Ivendor/glad/include -Ivendor/stb -Ivendor/imgui-1.91.8 -Ivendor/imgui-1.91.8/backends -Ivendor/glfw-3.4/include -D_GLFW_WIN32 src/app.cpp >> syntax_app.log 2>&1
echo rc_syntax=%errorlevel% >> syntax_app.log
echo TEST DONE >> syntax_app.log
