@echo off
setlocal
cd /d %~dp0

set "W64DIR=C:\Users\DELL\dev\w64devkit\bin"
if not "%GXX_DIR%"=="" set "W64DIR=%GXX_DIR%"
if not exist "%W64DIR%\sh.exe" (
    echo sh.exe not found in %W64DIR%
    echo Set GXX_DIR to the w64devkit bin directory containing sh.exe/g++.exe and retry.
    exit /b 1
)

"%W64DIR%\sh.exe" build.sh
if errorlevel 1 (
    echo.
    echo Build FAILED - see build_sh.log
    exit /b 1
)
echo.
echo Build OK: %cd%\ord.exe
