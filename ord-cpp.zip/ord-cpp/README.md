# Generalized Transfinite Number Line — C++ / OpenGL port

A native Windows port of the browser-based [ord-generalized](https://github.com/RNGDelak/ord-generalized)
ordinal-notation visualizer by **RNGDelak** (MIT licensed). The original JavaScript
(`plot.js`, `ui.js`, `Libs/BMS.js`) is rendered with WebGL/DOM; this port reproduces the same
math and rendering with **C++17 + OpenGL 3.3 (GLFW + glad + Dear ImGui + stb_truetype)**.

## Features

- All four ordinal notation systems, switchable at runtime (replaces the browser's
  JS code-injection mechanism): **BMS** (default), **Worm principle**, **PLPrSS**, **EBO**.
- Faithful port of the adaptive-precision BigInt viewport (arbitrary-precision integers,
  base 1e9), tick importance/brightness model, harmonic interval spacing, mathstick mode,
  diagonal ticks, mode-stack labels and aliases, cursor tooltip with fundamental-sequence
  preview, ordinal finder, viewport setter, HUD, zoom/pan keyboard & mouse controls,
  selection zoom, undo, slow mode.
- Dear ImGui settings menu replicating the original config panel: preset selector,
  sliders (aspect ratio, tick spacing/height/width/anchor, label count, FPS precision,
  max interval division/depth), checkboxes, background color, raw JSON editor,
  "Apply Configuration", and 5 save slots (persisted to `slots/slotN.json`).

## Browser-only features not ported

- JavaScript notation injection (replaced by compiled-in presets).
- URL hash sharing of notation + config (replaced by JSON editor + slots).
- Pointer lock zoom mode (a toast notes this; drag/wheel zoom still work).

## Building (Windows, MinGW)

Dependencies are vendored in `vendor/` (glad, stb_truetype, ImGui 1.91.8, GLFW 3.4 source).

1. Install a MinGW-w64 toolchain (e.g. [w64devkit](https://github.com/skeeto/w64devkit))
   so that `g++.exe` is available.
2. Run:

   ```bat
   build.bat
   ```

   By default it expects the toolchain at `C:\Users\DELL\dev\w64devkit\bin`;
   override with `set GXX_DIR=<dir containing g++.exe and sh.exe>` if needed.
   `build.bat` drives `build.sh` under the toolchain's `sh.exe`, compiles every
   source into flat objects under `build/` (skipping up-to-date ones), links
   `ord.exe`, and logs each step to `build_sh.log`. A `Makefile` is also provided
   for `make` users, but `build.bat`/`build.sh` is the tested path.

3. Run `ord.exe`. A system font is auto-detected for text rendering
   (Times New Roman / Segoe UI / Arial / Calibri / DejaVu Sans).

## Controls

Same keybinds as the original (see the in-app "Hint" dialog, key `?` region of the
settings menu): arrows pan, `+`/`-` or wheel zoom, `a`/`s` depth, `f`/`g`/`i`/`m`/`h`/`l`/`d`/`z`/`r`/`2`
toggle display modes, `Shift+S` slow mode, `Ctrl+Z` undo viewport, `Space`+arrow
toggle-hold panning.

## Original credits

- Original web app: RNGDelak, *Generalized Transfinite Number Line* — MIT License.
- Dear ImGui — Omar Cornut, MIT License.
- GLFW — zlib/libpng License. glad — MIT License. stb_truetype — Sean Barrett, public domain / MIT.
