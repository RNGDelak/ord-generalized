// Common notation module interface: C++ port of the `window.notation` object
// exported by each Libs/*.js file.
#pragma once
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include "config.h"

// Type-erased ordinal handle. Each notation casts it to its own concrete type.
using Ord = std::shared_ptr<void>;

struct Notation {
    virtual ~Notation() = default;

    virtual std::string title() const = 0;
    virtual Ord zero() const = 0;
    virtual Ord limit() const = 0;

    virtual int cmp(const Ord& a, const Ord& b) const = 0;
    virtual bool isSuccessor(const Ord& a) const = 0;
    virtual Ord fs(const Ord& a, long long n) const = 0;

    // JS: `seq[ofs][seq[ofs].length - 1] === 0` in segmentBigInt. True only for
    // notations whose ordinals are flat number arrays (PLPrSS); for BMS/Worm/EBO
    // the last element is an array/object, so `=== 0` is always false.
    virtual bool lastEntryIsZero(const Ord& a) const { return false; }

    virtual std::vector<std::string> displayNames() const = 0;
    virtual std::string display(const Ord& a, const std::string& modeName) const = 0;
    virtual std::string classifyOrdinal(const Ord& a) const = 0; // hex color

    virtual std::vector<std::pair<std::string, std::string>> ordinalTypes() const = 0; // name -> color
    virtual std::vector<std::pair<std::string, Ord>> aliases() const = 0;              // name -> ordinal

    virtual bool hasParser() const { return false; }
    virtual Ord parse(const std::string& s) const { (void)s; return nullptr; }

    // notation.config.modes in JS (defaults to [{mode:0,target:"both"}])
    virtual std::vector<ModeSpec> initialModes() const { return { { 0, "both" } }; }
};

// Registry of compiled-in notations (replaces runtime JS script injection).
std::vector<std::pair<std::string, std::shared_ptr<Notation>>> availableNotations();
