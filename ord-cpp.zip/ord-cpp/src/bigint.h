// Arbitrary-precision signed integer, base 1e9 little-endian.
// Port of the JS BigInt subset used by plot.js / ui.js.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

class BigInt {
public:
    std::vector<uint32_t> d; // base 1e9, little-endian, normalized (no leading zeros)
    bool neg = false;

    BigInt() {}
    BigInt(long long v);

    static BigInt pow10(long long e);            // 10^e, e >= 0
    static BigInt parseDecimal(const std::string& s); // supports leading '-'

    bool isZero() const { return d.empty(); }
    int sgn() const { return isZero() ? 0 : (neg ? -1 : 1); }

    static int cmpAbs(const BigInt& a, const BigInt& b);
    static int cmp(const BigInt& a, const BigInt& b);

    BigInt operator-() const { BigInt r = *this; if (!r.isZero()) r.neg = !r.neg; return r; }
    friend BigInt operator+(const BigInt& a, const BigInt& b);
    friend BigInt operator-(const BigInt& a, const BigInt& b);
    friend BigInt operator*(const BigInt& a, const BigInt& b);
    friend BigInt operator/(const BigInt& a, const BigInt& b); // truncated toward zero
    friend BigInt operator%(const BigInt& a, const BigInt& b);

    BigInt& operator+=(const BigInt& o) { return *this = *this + o; }
    BigInt& operator-=(const BigInt& o) { return *this = *this - o; }
    BigInt& operator*=(const BigInt& o) { return *this = *this * o; }
    BigInt& operator/=(const BigInt& o) { return *this = *this / o; }

    bool operator<(const BigInt& o) const { return cmp(*this, o) < 0; }
    bool operator<=(const BigInt& o) const { return cmp(*this, o) <= 0; }
    bool operator>(const BigInt& o) const { return cmp(*this, o) > 0; }
    bool operator>=(const BigInt& o) const { return cmp(*this, o) >= 0; }
    bool operator==(const BigInt& o) const { return cmp(*this, o) == 0; }
    bool operator!=(const BigInt& o) const { return cmp(*this, o) != 0; }

    // Fast paths for multiplying/dividing by 10^e (used with PRECISION_SCALE).
    BigInt mulPow10(long long e) const;
    BigInt divPow10(long long e) const; // truncated

    std::string toString() const;
    double toDouble() const;
    long long numDigits() const; // decimal digit count of |value| (0 -> 1)

private:
    void normalize();
    static void addAbs(const BigInt& a, const BigInt& b, BigInt& out);
    static void subAbs(const BigInt& a, const BigInt& b, BigInt& out); // |a| >= |b|
    static void divModAbs(const BigInt& a, const BigInt& b, BigInt& q, BigInt& r);
};
