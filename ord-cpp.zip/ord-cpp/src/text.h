// Rich-text renderer over stb_truetype: supports <sup> <sub> <b> <i>,
// HTML entities (&omega; etc.), UTF-8 literals and '\n' line breaks.
#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include "renderer.h"

class TextRenderer {
public:
    bool init(Renderer* renderer, int atlasW = 4096, int atlasH = 2048, float bakeSize = 64.0f);
    void shutdown();

    // alignX: "left" | "center" | "right"; alignY: "top" | "middle" | "bottom"
    void draw(const std::string& rich, float x, float y, float sizePx, const Color& c,
              const std::string& alignX = "left", const std::string& alignY = "top",
              float rotDeg = 0.0f);

    void measure(const std::string& rich, float sizePx, float& outW, float& outH);

    unsigned atlasTex() const { return texId; }
    float bakeSize() const { return bakePx; }
    float ascentPx() const { return ascent; }
    float descentPx() const { return descent; } // negative

private:
    Renderer* rend = nullptr;
    unsigned texId = 0;
    int AW = 0, AH = 0;
    float bakePx = 48;
    float ascent = 0, descent = 0, lineGap = 0;

    std::vector<uint32_t> cps;          // codepoint list (index == char_index)
    std::map<uint32_t, int> cpIndex;    // codepoint -> index in cps
    std::vector<unsigned char> packed;  // stbtt_packedchar[cps.size()] as raw bytes

    int cpIdx(uint32_t cp) const;
    void layout(const std::string& rich, float sizePx, float x, float y,
                const Color& c, const std::string& alignX, const std::string& alignY,
                bool emit, float rotDeg, float& outW, float& outH);
};
