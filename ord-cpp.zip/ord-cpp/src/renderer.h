// Batched screen-space quad/line renderer (OpenGL 3.3 core, glad).
#pragma once
#include <map>
#include <vector>
#include <cstdint>

struct Color {
    float r = 1, g = 1, b = 1, a = 1;
    Color() {}
    Color(float r_, float g_, float b_, float a_ = 1) : r(r_), g(g_), b(b_), a(a_) {}
};

struct Vert {
    float x, y, u, v;
    float r, g, b, a;
};

class Renderer {
public:
    bool init();
    void shutdown();
    void resize(int w, int h);

    void begin(float bgR, float bgG, float bgB, float bgA = 1.0f);

    void pushQuad(float x, float y, float w, float h, const Color& c);
    void pushLine(float x1, float y1, float x2, float y2, const Color& c, float width = 2.0f);
    // Textured quad with optional rotation (degrees) around (ox, oy).
    void pushTexQuad(float x, float y, float w, float h, const Color& c,
                     float u0, float v0, float u1, float v1, unsigned texId,
                     float rotDeg = 0, float ox = 0, float oy = 0);
    void flush();

    unsigned whiteTex() const { return whiteTexId; }
    int width() const { return W; }
    int height() const { return H; }

private:
    unsigned prog = 0, vao = 0, vbo = 0, whiteTexId = 0;
    int W = 1, H = 1;
    std::map<unsigned, std::vector<Vert>> batches; // by texture id

    void pushVert(unsigned tex, float x, float y, float u, float v, const Color& c);
};
