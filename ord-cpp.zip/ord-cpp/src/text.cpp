#include "text.h"
#include <glad/glad.h>
#define STB_TRUETYPE_IMPLEMENTATION
#include <stb_truetype.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <fstream>
#include <map>

namespace {

bool readFile(const char* path, std::vector<unsigned char>& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    out.assign((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    return !out.empty();
}

const char* findSystemFont() {
    static const char* candidates[] = {
        "C:/Windows/Fonts/times.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibri.ttf",
        "C:/Windows/Fonts/DejaVuSans.ttf",
        "C:/Windows/Fonts/msgothic.ttc",
    };
    for (const char* c : candidates) {
        std::ifstream f(c, std::ios::binary);
        if (f) return c;
    }
    return nullptr;
}

// HTML entity name (without & and ;) -> codepoint
uint32_t entityToCp(const std::string& name) {
    static const std::map<std::string, uint32_t> m = {
        { "amp", 0x26 }, { "lt", 0x3C }, { "gt", 0x3E }, { "quot", 0x22 }, { "apos", 0x27 },
        { "nbsp", 0x20 }, { "middot", 0xB7 }, { "sdot", 0x22C5 }, { "cdot", 0x22C5 },
        { "times", 0xD7 }, { "infin", 0x221E }, { "deg", 0xB0 }, { "plusmn", 0xB1 },
        { "rarr", 0x2192 }, { "larr", 0x2190 }, { "harr", 0x2194 }, { "rArr", 0x21D2 },
        { "part", 0x2202 }, { "empty", 0x2205 }, { "le", 0x2264 }, { "ge", 0x2265 }, { "ne", 0x2260 },
        // Greek
        { "alpha", 0x3B1 }, { "beta", 0x3B2 }, { "gamma", 0x3B3 }, { "Gamma", 0x393 },
        { "delta", 0x3B4 }, { "Delta", 0x394 }, { "epsilon", 0x3B5 }, { "varepsilon", 0x3B5 },
        { "zeta", 0x3B6 }, { "eta", 0x3B7 }, { "theta", 0x3B8 }, { "Theta", 0x398 },
        { "iota", 0x3B9 }, { "kappa", 0x3BA }, { "lambda", 0x3BB }, { "Lambda", 0x39B },
        { "mu", 0x3BC }, { "nu", 0x3BD }, { "xi", 0x3BE }, { "Xi", 0x39E },
        { "pi", 0x3C0 }, { "Pi", 0x3A0 }, { "rho", 0x3C1 }, { "sigma", 0x3C3 }, { "Sigma", 0x3A3 },
        { "tau", 0x3C4 }, { "upsilon", 0x3C5 }, { "phi", 0x3C6 }, { "Phi", 0x3A6 },
        { "chi", 0x3C7 }, { "psi", 0x3C8 }, { "Psi", 0x3A8 }, { "omega", 0x3C9 }, { "Omega", 0x3A9 },
    };
    auto it = m.find(name);
    return it == m.end() ? 0 : it->second;
}

// Decode one UTF-8 codepoint; advance i.
uint32_t decodeUtf8(const std::string& s, size_t& i) {
    unsigned char c = (unsigned char)s[i];
    uint32_t cp;
    int extra;
    if (c < 0x80) { cp = c; extra = 0; }
    else if ((c >> 5) == 0x6) { cp = c & 0x1F; extra = 1; }
    else if ((c >> 4) == 0xE) { cp = c & 0x0F; extra = 2; }
    else if ((c >> 3) == 0x1E) { cp = c & 0x07; extra = 3; }
    else { i++; return 0xFFFD; }
    i++;
    for (int k = 0; k < extra && i < s.size(); k++, i++) {
        cp = (cp << 6) | ((unsigned char)s[i] & 0x3F);
    }
    return cp;
}

struct Item {
    uint32_t cp;
    float scale; // 1.0 normal, ~0.7 sup/sub
    float dy;    // baseline offset in em units (times sizePx)
    bool bold;
};

} // namespace

int TextRenderer::cpIdx(uint32_t cp) const {
    auto it = cpIndex.find(cp);
    return it == cpIndex.end() ? -1 : it->second;
}

bool TextRenderer::init(Renderer* renderer, int atlasW, int atlasH, float bakeSize) {
    rend = renderer;
    AW = atlasW;
    AH = atlasH;
    bakePx = bakeSize;

    // Build codepoint list.
    cps.clear();
    for (uint32_t c = 0x20; c <= 0x7E; c++) cps.push_back(c);
    for (uint32_t c = 0xA0; c <= 0xFF; c++) cps.push_back(c);
    for (uint32_t c = 0x384; c <= 0x3CE; c++) cps.push_back(c);
    uint32_t extra[] = { 0x22C5, 0x221E, 0x2192, 0x2190, 0x2194, 0x21D2,
                         0x2202, 0x2205, 0x2264, 0x2265, 0x2260, 0x2248, 0x2026 };
    for (uint32_t c : extra) cps.push_back(c);
    cpIndex.clear();
    for (size_t i = 0; i < cps.size(); i++) cpIndex[cps[i]] = (int)i;

    const char* fontPath = findSystemFont();
    if (!fontPath) {
        fprintf(stderr, "TextRenderer: no system font found\n");
        return false;
    }
    std::vector<unsigned char> fontdata;
    if (!readFile(fontPath, fontdata)) {
        fprintf(stderr, "TextRenderer: cannot read font %s\n", fontPath);
        return false;
    }

    std::vector<unsigned char> pixels((size_t)atlasW * atlasH, 0);
    stbtt_pack_context pc;
    if (!stbtt_PackBegin(&pc, pixels.data(), atlasW, atlasH, 0, 1, nullptr)) {
        fprintf(stderr, "TextRenderer: stbtt_PackBegin failed\n");
        return false;
    }
    stbtt_PackSetOversampling(&pc, 2, 2);
    stbtt_PackSetSkipMissingCodepoints(&pc, 1);

    packed.assign(cps.size() * sizeof(stbtt_packedchar), 0);
    stbtt_packedchar* chars = reinterpret_cast<stbtt_packedchar*>(packed.data());

    std::vector<int> cpInts(cps.begin(), cps.end());
    stbtt_pack_range range;
    range.font_size = bakePx;
    range.first_unicode_codepoint_in_range = 0;
    range.array_of_unicode_codepoints = cpInts.data();
    range.num_chars = (int)cpInts.size();
    range.chardata_for_range = chars;
    range.h_oversample = 2;
    range.v_oversample = 2;
    stbtt_PackFontRanges(&pc, fontdata.data(), 0, &range, 1);
    stbtt_PackEnd(&pc);

    // Font metrics (vertical).
    stbtt_fontinfo info;
    if (stbtt_InitFont(&info, fontdata.data(), 0)) {
        int a = 0, d = 0, g = 0;
        stbtt_GetFontVMetrics(&info, &a, &d, &g);
        float sc = stbtt_ScaleForPixelHeight(&info, bakePx);
        ascent = a * sc;
        descent = d * sc; // negative
        lineGap = g * sc;
    } else {
        ascent = bakePx * 0.8f;
        descent = -bakePx * 0.2f;
        lineGap = 0;
    }

    // Upload atlas as single-channel texture.
    glGenTextures(1, &texId);
    glBindTexture(GL_TEXTURE_2D, texId);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, atlasW, atlasH, 0, GL_RED, GL_UNSIGNED_BYTE, pixels.data());
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);
    return true;
}

void TextRenderer::shutdown() {
    if (texId) glDeleteTextures(1, &texId);
    texId = 0;
}

namespace {

// Parse rich text into lines of Items.
std::vector<std::vector<Item>> parseRich(const std::string& s) {
    std::vector<std::vector<Item>> lines;
    lines.push_back({});
    bool bold = false, italic = false, sup = false, sub = false;
    size_t i = 0;
    while (i < s.size()) {
        char c = s[i];
        if (c == '<') {
            size_t end = s.find('>', i);
            if (end == std::string::npos) { i++; continue; }
            std::string tag = s.substr(i + 1, end - i - 1);
            std::string low;
            for (char ch : tag) low += (char)tolower((unsigned char)ch);
            bool closing = !low.empty() && low[0] == '/';
            if (closing) low = low.substr(1);
            // strip attributes
            size_t sp = low.find(' ');
            if (sp != std::string::npos) low = low.substr(0, sp);
            if (low == "b" || low == "strong") bold = !closing;
            else if (low == "i" || low == "em") italic = !closing;
            else if (low == "sup") sup = !closing;
            else if (low == "sub") sub = !closing;
            else if (low == "br") lines.push_back({});
            else if (low == "div" || low == "p") { if (!closing) lines.push_back({}); }
            // other tags ignored
            i = end + 1;
            continue;
        }
        if (c == '&') {
            size_t end = s.find(';', i);
            if (end != std::string::npos && end - i <= 12) {
                std::string name = s.substr(i + 1, end - i - 1);
                uint32_t cp = entityToCp(name);
                if (cp) {
                    float sc = (sup || sub) ? 0.68f : 1.0f;
                    float dy = sup ? -0.45f : (sub ? 0.22f : 0.0f);
                    lines.back().push_back({ cp, sc, dy, bold || italic });
                    i = end + 1;
                    continue;
                }
            }
            // literal '&'
            lines.back().push_back({ (uint32_t)'&', 1.0f, 0.0f, bold });
            i++;
            continue;
        }
        if (c == '\n') { lines.push_back({}); i++; continue; }
        uint32_t cp = decodeUtf8(s, i);
        float sc = (sup || sub) ? 0.68f : 1.0f;
        float dy = sup ? -0.45f : (sub ? 0.22f : 0.0f);
        lines.back().push_back({ cp, sc, dy, bold });
    }
    return lines;
}

} // namespace

void TextRenderer::layout(const std::string& rich, float sizePx, float x, float y,
                          const Color& c, const std::string& alignX, const std::string& alignY,
                          bool emit, float rotDeg, float& outW, float& outH) {
    outW = 0;
    outH = 0;
    if (!texId) return;
    stbtt_packedchar* chars = reinterpret_cast<stbtt_packedchar*>(packed.data());
    float baseScale = sizePx / bakePx;
    float screenAscent = ascent * baseScale;
    float screenDescent = descent * baseScale; // negative
    float lineHeight = (ascent - descent + lineGap) * baseScale;
    if (lineHeight <= 0) lineHeight = sizePx * 1.2f;

    auto lines = parseRich(rich);

    // Compute per-line widths.
    std::vector<float> lineW(lines.size(), 0.0f);
    for (size_t li = 0; li < lines.size(); li++) {
        float pen = 0;
        for (const Item& it : lines[li]) {
            int idx = cpIdx(it.cp);
            if (idx < 0) { pen += sizePx * 0.3f * it.scale; continue; }
            float bx = 0, by = 0;
            stbtt_aligned_quad q;
            stbtt_GetPackedQuad(chars, AW, AH, idx, &bx, &by, &q, 0);
            pen += bx * baseScale * it.scale;
        }
        lineW[li] = pen;
        outW = std::max(outW, pen);
    }
    outH = lineHeight * (float)lines.size();

    float originX = x;
    if (alignX == "center") originX = x - outW * 0.5f;
    else if (alignX == "right") originX = x - outW;

    float firstBaseline = y + screenAscent;
    if (alignY == "middle") firstBaseline = y - outH * 0.5f + screenAscent;
    else if (alignY == "bottom") firstBaseline = y - outH + screenAscent;

    if (!emit) return;

    float blockTop = firstBaseline - screenAscent;
    for (size_t li = 0; li < lines.size(); li++) {
        float baselineY = firstBaseline + lineHeight * (float)li;
        float penX = originX;
        if (alignX == "center") penX = originX + (outW - lineW[li]) * 0.5f;
        else if (alignX == "right") penX = originX + (outW - lineW[li]);
        for (const Item& it : lines[li]) {
            int idx = cpIdx(it.cp);
            if (idx < 0) { penX += sizePx * 0.3f * it.scale; continue; }
            float bx = 0, by = 0;
            stbtt_aligned_quad q;
            stbtt_GetPackedQuad(chars, AW, AH, idx, &bx, &by, &q, 0);
            float sc = baseScale * it.scale;
            float gx = penX + q.x0 * sc;
            float gy = baselineY + it.dy * sizePx + q.y0 * sc;
            float gw = (q.x1 - q.x0) * sc;
            float gh = (q.y1 - q.y0) * sc;
            rend->pushTexQuad(gx, gy, gw, gh, c, q.s0, q.t0, q.s1, q.t1, texId, rotDeg, originX, blockTop);
            if (it.bold) {
                float off = std::max(0.6f, sizePx * 0.045f);
                rend->pushTexQuad(gx + off, gy, gw, gh, c, q.s0, q.t0, q.s1, q.t1, texId, rotDeg, originX, blockTop);
            }
            penX += bx * sc;
        }
    }
}

void TextRenderer::draw(const std::string& rich, float x, float y, float sizePx, const Color& c,
                        const std::string& alignX, const std::string& alignY, float rotDeg) {
    float w, h;
    layout(rich, sizePx, x, y, c, alignX, alignY, true, rotDeg, w, h);
}

void TextRenderer::measure(const std::string& rich, float sizePx, float& outW, float& outH) {
    Color c;
    layout(rich, sizePx, 0, 0, c, "left", "top", false, 0, outW, outH);
}
