#include "bigint.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

static const uint64_t BASE = 1000000000ull;

void BigInt::normalize() {
    while (!d.empty() && d.back() == 0) d.pop_back();
    if (d.empty()) neg = false;
}

BigInt::BigInt(long long v) {
    if (v < 0) { neg = true; }
    unsigned long long u = v < 0 ? -(unsigned long long)v : (unsigned long long)v;
    while (u) { d.push_back((uint32_t)(u % BASE)); u /= BASE; }
    normalize();
}

BigInt BigInt::pow10(long long e) {
    BigInt r;
    if (e < 0) e = 0;
    r.d.resize((size_t)(e / 9) + 1, 0);
    r.d.back() = 1;
    for (long long i = 0; i < e % 9; i++) r.d.back() *= 10;
    r.normalize();
    return r;
}

BigInt BigInt::parseDecimal(const std::string& s) {
    BigInt r;
    size_t i = 0;
    if (!s.empty() && (s[0] == '-' || s[0] == '+')) { r.neg = (s[0] == '-'); i = 1; }
    while (i < s.size() && s[i] == '0') i++;
    std::string digits = s.substr(i);
    if (digits.empty()) { r.d.clear(); r.neg = false; return r; }
    for (size_t end = digits.size(); end > 0;) {
        size_t start = end > 9 ? end - 9 : 0;
        uint32_t chunk = 0;
        for (size_t k = start; k < end; k++) chunk = chunk * 10 + (uint32_t)(digits[k] - '0');
        r.d.push_back(chunk);
        end = start;
    }
    r.normalize();
    return r;
}

int BigInt::cmpAbs(const BigInt& a, const BigInt& b) {
    if (a.d.size() != b.d.size()) return a.d.size() < b.d.size() ? -1 : 1;
    for (size_t i = a.d.size(); i-- > 0;) {
        if (a.d[i] != b.d[i]) return a.d[i] < b.d[i] ? -1 : 1;
    }
    return 0;
}

int BigInt::cmp(const BigInt& a, const BigInt& b) {
    if (a.isZero() && b.isZero()) return 0;
    if (a.neg != b.neg) return a.neg ? -1 : 1;
    int c = cmpAbs(a, b);
    return a.neg ? -c : c;
}

void BigInt::addAbs(const BigInt& a, const BigInt& b, BigInt& out) {
    out.d.assign(std::max(a.d.size(), b.d.size()) + 1, 0);
    uint64_t carry = 0;
    for (size_t i = 0; i < out.d.size(); i++) {
        uint64_t s = carry;
        if (i < a.d.size()) s += a.d[i];
        if (i < b.d.size()) s += b.d[i];
        out.d[i] = (uint32_t)(s % BASE);
        carry = s / BASE;
    }
    out.normalize();
}

void BigInt::subAbs(const BigInt& a, const BigInt& b, BigInt& out) {
    out.d.assign(a.d.size(), 0);
    long long borrow = 0;
    for (size_t i = 0; i < a.d.size(); i++) {
        long long s = (long long)a.d[i] - borrow - (i < b.d.size() ? (long long)b.d[i] : 0);
        if (s < 0) { s += (long long)BASE; borrow = 1; } else borrow = 0;
        out.d[i] = (uint32_t)s;
    }
    out.normalize();
}

BigInt operator+(const BigInt& a, const BigInt& b) {
    BigInt r;
    if (a.neg == b.neg) {
        BigInt::addAbs(a, b, r);
        r.neg = a.neg && !r.isZero();
    } else {
        int c = BigInt::cmpAbs(a, b);
        if (c == 0) return BigInt();
        if (c > 0) { BigInt::subAbs(a, b, r); r.neg = a.neg; }
        else { BigInt::subAbs(b, a, r); r.neg = b.neg; }
    }
    return r;
}

BigInt operator-(const BigInt& a, const BigInt& b) {
    return a + (-b);
}

BigInt operator*(const BigInt& a, const BigInt& b) {
    BigInt r;
    if (a.isZero() || b.isZero()) return r;
    r.d.assign(a.d.size() + b.d.size(), 0);
    for (size_t i = 0; i < a.d.size(); i++) {
        uint64_t carry = 0;
        for (size_t j = 0; j < b.d.size(); j++) {
            uint64_t cur = (uint64_t)r.d[i + j] + (uint64_t)a.d[i] * b.d[j] + carry;
            r.d[i + j] = (uint32_t)(cur % BASE);
            carry = cur / BASE;
        }
        size_t k = i + b.d.size();
        while (carry) {
            uint64_t cur = (uint64_t)r.d[k] + carry;
            if (k >= r.d.size()) r.d.push_back(0);
            r.d[k] = (uint32_t)(cur % BASE);
            carry = cur / BASE;
            k++;
        }
    }
    r.neg = (a.neg != b.neg);
    r.normalize();
    return r;
}

// ---- Binary helpers for general division (rare path) ----
namespace {

using Bin = std::vector<uint64_t>;

Bin decToBin(const BigInt& v) {
    Bin out;
    for (size_t i = v.d.size(); i-- > 0;) {
        uint64_t carry = v.d[i];
        for (size_t j = 0; j < out.size(); j++) {
            unsigned __int128 cur = (unsigned __int128)out[j] * BASE + carry;
            out[j] = (uint64_t)cur;
            carry = (uint64_t)(cur >> 64);
        }
        if (carry) out.push_back(carry);
    }
    while (!out.empty() && out.back() == 0) out.pop_back();
    return out;
}

BigInt binToDec(const Bin& bin) {
    BigInt pow2_64 = BigInt(4294967296LL) * BigInt(4294967296LL);
    BigInt p32(4294967296LL);
    BigInt result;
    for (size_t i = bin.size(); i-- > 0;) {
        result = result * pow2_64;
        long long hi = (long long)(bin[i] >> 32);
        long long lo = (long long)(bin[i] & 0xFFFFFFFFull);
        result = result + BigInt(hi) * p32 + BigInt(lo);
    }
    return result;
}

int binBit(const Bin& v, long long i) {
    return (int)((v[i / 64] >> (i % 64)) & 1ull);
}

int binCmp(const Bin& x, const Bin& y) {
    if (x.size() != y.size()) return x.size() < y.size() ? -1 : 1;
    for (size_t i = x.size(); i-- > 0;) if (x[i] != y[i]) return x[i] < y[i] ? -1 : 1;
    return 0;
}

void binSub(Bin& x, const Bin& y) {
    long long borrow = 0;
    for (size_t i = 0; i < x.size(); i++) {
        unsigned __int128 s = (unsigned __int128)x[i] - (unsigned __int128)(i < y.size() ? y[i] : 0) - (unsigned __int128)borrow;
        if (s >> 127) { /* negative */
            s += ((unsigned __int128)1 << 64);
            borrow = 1;
        } else borrow = 0;
        x[i] = (uint64_t)s;
    }
    while (!x.empty() && x.back() == 0) x.pop_back();
}

void binShl1(Bin& x) {
    uint64_t carry = 0;
    for (size_t i = 0; i < x.size(); i++) {
        uint64_t nc = x[i] >> 63;
        x[i] = (x[i] << 1) | carry;
        carry = nc;
    }
    if (carry) x.push_back(carry);
}

long long binBits(const Bin& v) {
    if (v.empty()) return 0;
    long long b = (long long)(v.size() - 1) * 64;
    uint64_t top = v.back();
    while (top) { b++; top >>= 1; }
    return b;
}

} // namespace

void BigInt::divModAbs(const BigInt& a, const BigInt& b, BigInt& q, BigInt& r) {
    q = BigInt(); r = BigInt();
    if (b.isZero()) { q = a; return; }
    if (cmpAbs(a, b) < 0) { r = a; return; }

    // Fast path: b is a power of ten -> use decimal shift division.
    {
        bool isPow10 = (b.d.size() == 1 && b.d[0] == 1) || true;
        // detect 10^e: single word 1,10,100,...,1e8 with rest zeros? check via toString cost; simpler:
        isPow10 = false;
        if (!b.d.empty()) {
            uint32_t top = b.d.back();
            int e9 = 0; // exponent from full words
            uint32_t t = top;
            while (t % 10 == 0 && t != 0) { t /= 10; e9++; }
            if (t == 1) {
                bool allZero = true;
                for (size_t i = 0; i + 1 < b.d.size(); i++) if (b.d[i] != 0) { allZero = false; break; }
                if (allZero) {
                    long long e = (long long)(b.d.size() - 1) * 9 + e9;
                    q = a.divPow10(e);
                    r = a - q * b;
                    return;
                }
            }
        }
        (void)isPow10;
    }

    Bin A = decToBin(a), B = decToBin(b);
    long long aBits = binBits(A);

    Bin rem, quotient((size_t)(aBits / 64) + 1, 0);
    for (long long i = aBits - 1; i >= 0; i--) {
        binShl1(rem);
        if (binBit(A, i)) {
            if (rem.empty()) rem.push_back(1); else rem[0] |= 1ull;
        }
        if (binCmp(rem, B) >= 0) {
            binSub(rem, B);
            quotient[(size_t)(i / 64)] |= (1ull << (i % 64));
        }
    }
    while (!quotient.empty() && quotient.back() == 0) quotient.pop_back();

    q = binToDec(quotient);
    r = binToDec(rem);
}

BigInt operator/(const BigInt& a, const BigInt& b) {
    if (b.isZero()) return BigInt();
    BigInt q, r;
    BigInt::divModAbs(a, b, q, r);
    q.neg = (a.neg != b.neg) && !q.isZero();
    q.normalize();
    return q;
}

BigInt operator%(const BigInt& a, const BigInt& b) {
    if (b.isZero()) return BigInt();
    BigInt q, r;
    BigInt::divModAbs(a, b, q, r);
    r.neg = a.neg && !r.isZero();
    r.normalize();
    return r;
}

BigInt BigInt::mulPow10(long long e) const {
    if (e <= 0 || isZero()) return *this;
    long long words = e / 9;
    int rem = (int)(e % 9);
    uint32_t factor = 1;
    for (int i = 0; i < rem; i++) factor *= 10;
    BigInt r;
    r.d.assign(d.size() + (size_t)words + 1, 0);
    uint64_t carry = 0;
    for (size_t i = 0; i < d.size(); i++) {
        uint64_t cur = (uint64_t)d[i] * factor + carry;
        r.d[i + (size_t)words] = (uint32_t)(cur % BASE);
        carry = cur / BASE;
    }
    if (carry) r.d[d.size() + (size_t)words] = (uint32_t)carry;
    r.neg = neg;
    r.normalize();
    return r;
}

BigInt BigInt::divPow10(long long e) const {
    if (e <= 0 || isZero()) return *this;
    long long words = e / 9;
    int rem = (int)(e % 9);
    if ((long long)d.size() <= words) return BigInt();
    uint32_t factor = 1;
    for (int i = 0; i < rem; i++) factor *= 10;
    BigInt r;
    r.d.assign(d.size() - (size_t)words, 0);
    uint64_t carry = 0;
    for (size_t i = d.size(); i-- > (size_t)words;) {
        uint64_t cur = carry * BASE + d[i];
        r.d[i - (size_t)words] = (uint32_t)(cur / factor);
        carry = cur % factor;
    }
    r.neg = neg;
    r.normalize();
    return r;
}

std::string BigInt::toString() const {
    if (isZero()) return "0";
    char buf[16];
    std::string s;
    snprintf(buf, sizeof(buf), "%u", d.back());
    s = buf;
    for (size_t i = d.size() - 1; i-- > 0;) {
        snprintf(buf, sizeof(buf), "%09u", d[i]);
        s += buf;
    }
    if (neg) s = "-" + s;
    return s;
}

double BigInt::toDouble() const {
    if (isZero()) return 0.0;
    double v = 0.0;
    for (size_t i = d.size(); i-- > 0;) v = v * (double)BASE + (double)d[i];
    return neg ? -v : v;
}

long long BigInt::numDigits() const {
    if (isZero()) return 1;
    long long n = (long long)(d.size() - 1) * 9;
    uint32_t top = d.back();
    while (top) { n++; top /= 10; }
    return n;
}
