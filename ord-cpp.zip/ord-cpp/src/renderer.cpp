#include "renderer.h"
#include <glad/glad.h>
#include <cmath>
#include <cstddef>
#include <cstdio>

static const char* VERT_SRC = R"(#version 330 core
layout(location=0) in vec2 aPos;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aColor;
uniform mat4 uProj;
out vec2 vUV;
out vec4 vColor;
void main(){
    vUV = aUV;
    vColor = aColor;
    gl_Position = uProj * vec4(aPos, 0.0, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 330 core
in vec2 vUV;
in vec4 vColor;
uniform sampler2D uTex;
out vec4 FragColor;
void main(){
    FragColor = texture(uTex, vUV) * vColor;
}
)";

static unsigned compile(unsigned type, const char* src) {
    unsigned s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        fprintf(stderr, "Shader compile error: %s\n", log);
    }
    return s;
}

static void ortho(float m[16], float l, float r, float b, float t) {
    for (int i = 0; i < 16; i++) m[i] = 0;
    m[0] = 2.0f / (r - l);
    m[5] = 2.0f / (t - b);
    m[10] = -1.0f;
    m[12] = -(r + l) / (r - l);
    m[13] = -(t + b) / (t - b);
    m[15] = 1.0f;
}

bool Renderer::init() {
    unsigned vs = compile(GL_VERTEX_SHADER, VERT_SRC);
    unsigned fs = compile(GL_FRAGMENT_SHADER, FRAG_SRC);
    prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetProgramInfoLog(prog, sizeof(log), nullptr, log);
        fprintf(stderr, "Program link error: %s\n", log);
        return false;
    }
    glDeleteShader(vs);
    glDeleteShader(fs);

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vert), (void*)offsetof(Vert, x));
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vert), (void*)offsetof(Vert, u));
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, sizeof(Vert), (void*)offsetof(Vert, r));
    glBindVertexArray(0);

    // 1x1 white texture
    glGenTextures(1, &whiteTexId);
    glBindTexture(GL_TEXTURE_2D, whiteTexId);
    unsigned char white[4] = { 255, 255, 255, 255 };
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    return true;
}

void Renderer::shutdown() {
    if (prog) glDeleteProgram(prog);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (vao) glDeleteVertexArrays(1, &vao);
    if (whiteTexId) glDeleteTextures(1, &whiteTexId);
    prog = 0; vbo = 0; vao = 0; whiteTexId = 0;
}

void Renderer::resize(int w, int h) { W = w; H = h; }

void Renderer::begin(float bgR, float bgG, float bgB, float bgA) {
    glViewport(0, 0, W, H);
    glClearColor(bgR, bgG, bgB, bgA);
    glClear(GL_COLOR_BUFFER_BIT);
    batches.clear();
}

void Renderer::pushVert(unsigned tex, float x, float y, float u, float v, const Color& c) {
    batches[tex].push_back({ x, y, u, v, c.r, c.g, c.b, c.a });
}

void Renderer::pushQuad(float x, float y, float w, float h, const Color& c) {
    unsigned t = whiteTexId;
    pushVert(t, x, y, 0, 0, c);
    pushVert(t, x + w, y, 0, 0, c);
    pushVert(t, x + w, y + h, 0, 0, c);
    pushVert(t, x, y, 0, 0, c);
    pushVert(t, x + w, y + h, 0, 0, c);
    pushVert(t, x, y + h, 0, 0, c);
}

void Renderer::pushLine(float x1, float y1, float x2, float y2, const Color& c, float width) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = std::sqrt(dx * dx + dy * dy);
    if (len < 1e-6f) return;
    float nx = -dy / len * (width * 0.5f);
    float ny = dx / len * (width * 0.5f);
    unsigned t = whiteTexId;
    pushVert(t, x1 + nx, y1 + ny, 0, 0, c);
    pushVert(t, x1 - nx, y1 - ny, 0, 0, c);
    pushVert(t, x2 - nx, y2 - ny, 0, 0, c);
    pushVert(t, x1 + nx, y1 + ny, 0, 0, c);
    pushVert(t, x2 - nx, y2 - ny, 0, 0, c);
    pushVert(t, x2 + nx, y2 + ny, 0, 0, c);
}

void Renderer::pushTexQuad(float x, float y, float w, float h, const Color& c,
                           float u0, float v0, float u1, float v1, unsigned texId,
                           float rotDeg, float ox, float oy) {
    float pts[4][2] = { { x, y }, { x + w, y }, { x + w, y + h }, { x, y + h } };
    float uvs[4][2] = { { u0, v0 }, { u1, v0 }, { u1, v1 }, { u0, v1 } };
    float cosA = 1, sinA = 0;
    if (rotDeg != 0) {
        float a = rotDeg * 3.14159265358979f / 180.0f;
        cosA = std::cos(a); sinA = std::sin(a);
        for (int i = 0; i < 4; i++) {
            float px = pts[i][0] - ox, py = pts[i][1] - oy;
            pts[i][0] = ox + px * cosA - py * sinA;
            pts[i][1] = oy + px * sinA + py * cosA;
        }
    }
    int idx[6] = { 0, 1, 2, 0, 2, 3 };
    for (int i = 0; i < 6; i++) {
        int k = idx[i];
        pushVert(texId, pts[k][0], pts[k][1], uvs[k][0], uvs[k][1], c);
    }
}

void Renderer::flush() {
    if (batches.empty()) return;
    glUseProgram(prog);
    float m[16];
    // Screen coords: y down. Map (0,0)..(W,H) to NDC.
    ortho(m, 0.0f, (float)W, (float)H, 0.0f);
    glUniformMatrix4fv(glGetUniformLocation(prog, "uProj"), 1, GL_FALSE, m);
    glUniform1i(glGetUniformLocation(prog, "uTex"), 0);
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);

    for (auto& kv : batches) {
        if (kv.second.empty()) continue;
        glBindTexture(GL_TEXTURE_2D, kv.first);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(kv.second.size() * sizeof(Vert)), kv.second.data(), GL_STREAM_DRAW);
        glDrawArrays(GL_TRIANGLES, 0, (GLsizei)kv.second.size());
    }
    glBindVertexArray(0);
    glBindTexture(GL_TEXTURE_2D, 0);
    glUseProgram(0);
}
