// Core engine: C++ port of plot.js state/math + ui.js viewport/finder logic.
#pragma once
#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "bigint.h"
#include "config.h"
#include "notation.h"

struct TickEntry {
    bool valid = false;
    std::string color; // hex from classifyOrdinal
    Ord ord;
    double importance = 0;
};

struct LabelEntry {
    double x = 0;
    Ord ord;
    double impor = 0;
};

struct HudItem {
    std::string text;
    std::string color; // css-like color string
};

struct SelectionBox {
    bool active = false;
    double startX = 0, currentX = 0, startY = 0, currentY = 0;
};

struct FindResult {
    bool found = false;
    BigInt x, width, scale;
};

// Parses "#rrggbb" / "#rgb" / "rgba(r,g,b,a)" / "rgb(r,g,b)" into 0..1 floats.
bool parseColorString(const std::string& s, float out[4]);

std::string toFixed(double v, int digits);

class Engine {
public:
    Config config;
    std::shared_ptr<Notation> notation;
    BigInt PRECISION_SCALE = BigInt::pow10(10);

    int W = 0, H = 0; // canvas size in pixels

    BigInt x0{0}, x1{0};
    std::vector<std::pair<BigInt, BigInt>> history;

    // per-render computed state
    double tHeight = 0, ilxw = 0;
    std::vector<TickEntry> ticks;
    std::vector<double> impor;
    std::vector<LabelEntry> labelsToDraw;

    // sampler output
    double samplerBd = 1e20;
    Ord samplerOrd;
    std::vector<std::string> sampleLines;
    std::string sampleColor = "#ffffff";
    bool sampleValid = false;

    // HUD text output
    std::string zoomText, posText;

    // input state
    struct MouseState {
        bool isDown = false;
        double x = 0, y = 0, lastX = 0, lastY = 0;
    } mouse;
    std::set<std::string> activeKeys;      // lowercase JS-style key names
    std::map<std::string, bool> toggleHeldKeys;
    SelectionBox selection;
    bool settingsOpen = false; // window.isSettingsOpen

    double fps = 0;
    bool dirty = true; // needs re-render (computeTree etc.)

    // --- BigInt helpers (plot.js) ---
    BigInt toBigInt(double num) const;
    double toNum(const BigInt& b) const;
    BigInt converge1BigInt(const BigInt& a, const BigInt& b, double rescale = 1.0) const;
    void updateAdaptivePrecisionScale();

    // --- Tree computation (plot.js) ---
    using SegCallback = std::function<void(double, double, const Ord&, double)>;
    void initTicks(double width);
    void importanceSeg(double x0, double x1, double width);
    void tickmark(double x0, double x1, const Ord& o0, double width);
    void tickmarkLabel(double x0, double x1, const Ord& o0, double width);
    void segmentBigInt(const BigInt& bx0, const BigInt& bx1, const Ord& o0, const Ord& o1,
                       const BigInt& epsBI, const BigInt& xminBI, const BigInt& xmaxBI,
                       long long depth, long long lefts, const SegCallback& callback, double widthNum);
    void computeTree(double width);

    // --- Frame (plot.js render(), minus drawing) ---
    void frame();          // recompute tree/labels/sample/stats if dirty
    void markDirty() { dirty = true; }
    void sampleHighPrecision(double x, double width);
    void updateCameraStats();
    std::vector<HudItem> hudItems() const;
    bool divisionLineVisible() const;
    std::vector<std::pair<std::string, std::string>> legendEntries() const; // ordinalTypes
    std::string aliasFor(const Ord& ord) const;                             // last matching alias name

    // --- Formatting (plot.js) ---
    static std::string formatBigIntZoom(const BigInt& currentWidthBI, const BigInt& canvasWidthBI);
    static std::string formatBigIntFraction(const BigInt& numerator, const BigInt& denominator, int decimals);

    // --- Tooltip (plot.js) ---
    int getOrdinalDepth(const Ord& a, const Ord& limitOrd) const;
    std::string buildTooltip(double px, double py) const; // empty = hidden

    // --- Viewport (plot.js) ---
    void resetViewport();
    void resize(int newW, int newH);
    void init();
    void clampViewportBounds();
    void applySelectionZoom();
    bool undoViewport();

    // --- Input actions (plot.js handlers) ---
    void pointerDown(double x, double y);
    void pointerMove(double clientX, double clientY); // computes movement from lastX/lastY
    void pointerUp();
    void wheel(double deltaY, double clientX);
    void stepKeyboard(double dtSeconds); // updateKeyboardInput fixed-step loop

    // --- ui.js viewport/finder ---
    static BigInt parseToBigIntScaled(const std::string& str, const BigInt& scale); // throws std::runtime_error
    bool triggerViewportZoom(const std::string& posStr, const std::string& zoomStr, std::string& err);
    FindResult findOrdinalPathBigInt(const Ord& targetOrd, int precisionDigits) const;
    bool findAndZoomToOrdinal(const std::string& inputStr, int precisionDigits, std::string& err);

    // --- Notation switching ---
    void setNotation(const std::shared_ptr<Notation>& n); // resetNotationsForSystem + init

private:
    void samplerCallback(double x0, double x1, const Ord& o0, double xmax);
};
