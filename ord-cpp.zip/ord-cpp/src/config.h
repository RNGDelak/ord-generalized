// Config struct: direct port of the `config` object from plot.js, with JSON
// serialization for the config editor and save slots (ui.js).
#pragma once
#include "json.h"
#include <string>
#include <vector>

struct ModeSpec {
    int mode = 0;
    std::string target = "both"; // "both" | "line" | "sample"
};

struct Config {
    // --- Canvas & Layout ---
    double aspectratio = 0.66;
    double maxAllowedWidthFactor = 0.1;
    double panFenceOverlap = 0.1;

    // --- Controls & Navigation ---
    double panSpeedBaseFactor = 0.5;
    double zoomSpeedBase = 10.0;
    double zoomDragFactor = 0.01;
    double wheelZoomIn = 1.5;
    double wheelZoomOut = 2.0 / 3.0;
    double shiftMultiplier = 3.0;
    double ctrlMultiplier = 0.25;
    bool ZoomIntoMouse = false;

    // --- Interactive & Rendering Modes ---
    std::vector<ModeSpec> modes = { { 0, "both" } };
    bool LockScreen = false;
    bool MathstickMode = false;
    bool MathStick_UseLogarithmLength = false;
    double MathStick_LogarithmBase = 2;
    bool DiagonalTickArrangement = true;
    bool HarmonicInvtervalSpacing = false;
    bool MultipleNotationOnSample = false;
    bool EnableOrdinalFinder = false;
    bool EnableSetViewPort = false;
    bool SlowMode = false;
    bool ZoomOutFencing = true;
    bool PanOutFencing = true;

    // --- UI & HUD Visibility ---
    bool ShowHUD = true;
    bool ShowLegends = true;
    bool ShowTitle = true;
    bool ShowFPS = true;
    bool ShowDepthAdjustGui = true;
    bool ShowOrdinalNotationConfigGui = true;
    bool AlwaysShowDivisionOnIdle = false;
    bool AlwaysShowDivisionOnInteraction = true;
    bool ShowMiddleNumberLineDivision = false;

    // --- Element Toggles ---
    bool ShowTick = true;
    bool Rendernumberline = true;
    bool ShowSample = true;
    bool ShowLabel = true;
    bool ShowTimelineLabel = true;
    bool ShowCurrentPositionState = true;

    // --- Element Coloring Toggles ---
    bool ColorTick = true;
    bool ColorSample = false;
    bool ColorLabel = false;
    bool ColorTimelineLabel = false;
    bool EnableTickColorBlending = true;

    // --- Color Palette ---
    std::string BackgroundColor = "#000000";
    std::string DefaultTickColor = "#a0a0a0";
    std::string DefaultTimelineLabelColor = "#808080";
    std::string DefaultSampleColor = "#ffffff";
    std::string DefaultLabelColor = "#ffffff";
    std::string ScreenDivisionLineColor = "#0000ff";
    std::string FPSLabelColor = "#9083ff";
    std::string DepthAdjustGuiColor = "#ffffff";
    std::string TitleColor = "#ffffff";
    std::string AddNotationBtnColor = "#0098ff";
    std::string RemoveNotationBtnColor = "#ff4444";
    std::string SelectNotationBoxColor = "#ffffff";
    std::string ChangeNotationDisplayLocationBtnColor = "#00ffcc";
    std::string MiddleNumberLineDivisionColor = "rgba(255,0,0,0.5)";
    std::string ZoomSelectionFillColor = "rgba(0, 150, 255, 0.2)";
    std::string RevertBtnColor = "#0098ff";
    std::string ResetBtnColor = "#ff0000";
    std::string ConfigMenuBtnColor = "#ffffff";
    std::string CurrentPositionStateTextColor = "#ffffff";

    // --- Ticks Properties ---
    double TickSpacing = 1;
    double Tickheight = 0.05;
    double TickWidth = 2;
    double TickAnchorPoint = 0.5;
    double TickSlopeArrangement = 1;
    double TickColorMaxBrightness = 255;
    double TickColorBoostStart = 256;
    double TickColorMaxBoost = 0x80;
    double TickColorMaxChannel = 255;

    // --- Labels & Spacing ---
    double labelscount = 8;
    double LabelBetweenTimelineSpacing = 30;
    double LabelBetweenTickSpacing = 5;
    double LabelBetweenLabelSpacing = 25;
    double TickBetweenLabelXoffest = -5;
    double LabelBetweenLabelXoffest = 0;
    double LabelBetweenTimelineXoffest = 0;
    double LabelRotation = 0;
    double TimelineRotation = 0;
    int sampleFontSize = 30;
    double sampleLeftSpacingPct = 10;   // "10%"
    double sampleTopSpacingPct = 83.5;  // "83.5%"
    double sampleMaxWidthPct = 80;      // "80%"
    double sampleTranslateYPct = -80;   // transform: translateY(-80%)
    std::string sampleTextAlign = "left";
    bool ShowCursorTooltip = false;

    // --- Computation & Performance Limits ---
    int fpsPrecision = 1;
    int MaxIntervalsDivision = -1;
    int MaxIntervalDepth = -1;
    int BigIntPrecisionMantissa = 8;
    int tooltipfsterms = 3;

    Json toJson() const;
    void mergeFrom(const Json& j); // config = { ...config, ...parsed }
};
