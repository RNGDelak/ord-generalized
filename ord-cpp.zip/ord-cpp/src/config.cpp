#include "config.h"

#define J_NUM(k) o.obj[#k] = Json::mkNum(k)
#define J_BOOL(k) o.obj[#k] = Json::mkBool(k)
#define J_STR(k) o.obj[#k] = Json::mkStr(k)
#define G_NUM(k) if (const Json* v = j.find(#k)) k = v->numOr(k)
#define G_BOOL(k) if (const Json* v = j.find(#k)) k = v->boolOr(k)
#define G_STR(k) if (const Json* v = j.find(#k)) k = v->strOr(k)

Json Config::toJson() const {
    Json o = Json::mkObj();

    J_NUM(aspectratio); J_NUM(maxAllowedWidthFactor); J_NUM(panFenceOverlap);
    J_NUM(panSpeedBaseFactor); J_NUM(zoomSpeedBase); J_NUM(zoomDragFactor);
    J_NUM(wheelZoomIn); J_NUM(wheelZoomOut); J_NUM(shiftMultiplier); J_NUM(ctrlMultiplier);
    J_BOOL(ZoomIntoMouse);

    Json mArr = Json::mkArr();
    for (auto& m : modes) {
        Json mo = Json::mkObj();
        mo.obj["mode"] = Json::mkNum(m.mode);
        mo.obj["target"] = Json::mkStr(m.target);
        mArr.arr.push_back(mo);
    }
    o.obj["modes"] = mArr;

    J_BOOL(LockScreen); J_BOOL(MathstickMode); J_BOOL(MathStick_UseLogarithmLength);
    J_NUM(MathStick_LogarithmBase); J_BOOL(DiagonalTickArrangement); J_BOOL(HarmonicInvtervalSpacing);
    J_BOOL(MultipleNotationOnSample); J_BOOL(EnableOrdinalFinder); J_BOOL(EnableSetViewPort);
    J_BOOL(SlowMode); J_BOOL(ZoomOutFencing); J_BOOL(PanOutFencing);

    J_BOOL(ShowHUD); J_BOOL(ShowLegends); J_BOOL(ShowTitle); J_BOOL(ShowFPS);
    J_BOOL(ShowDepthAdjustGui); J_BOOL(ShowOrdinalNotationConfigGui);
    J_BOOL(AlwaysShowDivisionOnIdle); J_BOOL(AlwaysShowDivisionOnInteraction);
    J_BOOL(ShowMiddleNumberLineDivision);

    J_BOOL(ShowTick); J_BOOL(Rendernumberline); J_BOOL(ShowSample); J_BOOL(ShowLabel);
    J_BOOL(ShowTimelineLabel); J_BOOL(ShowCurrentPositionState);

    J_BOOL(ColorTick); J_BOOL(ColorSample); J_BOOL(ColorLabel); J_BOOL(ColorTimelineLabel);
    J_BOOL(EnableTickColorBlending);

    J_STR(BackgroundColor); J_STR(DefaultTickColor); J_STR(DefaultTimelineLabelColor);
    J_STR(DefaultSampleColor); J_STR(DefaultLabelColor); J_STR(ScreenDivisionLineColor);
    J_STR(FPSLabelColor); J_STR(DepthAdjustGuiColor); J_STR(TitleColor);
    J_STR(AddNotationBtnColor); J_STR(RemoveNotationBtnColor); J_STR(SelectNotationBoxColor);
    J_STR(ChangeNotationDisplayLocationBtnColor); J_STR(MiddleNumberLineDivisionColor);
    J_STR(ZoomSelectionFillColor); J_STR(RevertBtnColor); J_STR(ResetBtnColor);
    J_STR(ConfigMenuBtnColor); J_STR(CurrentPositionStateTextColor);

    J_NUM(TickSpacing); J_NUM(Tickheight); J_NUM(TickWidth); J_NUM(TickAnchorPoint);
    J_NUM(TickSlopeArrangement); J_NUM(TickColorMaxBrightness); J_NUM(TickColorBoostStart);
    J_NUM(TickColorMaxBoost); J_NUM(TickColorMaxChannel);

    J_NUM(labelscount); J_NUM(LabelBetweenTimelineSpacing); J_NUM(LabelBetweenTickSpacing);
    J_NUM(LabelBetweenLabelSpacing); J_NUM(TickBetweenLabelXoffest); J_NUM(LabelBetweenLabelXoffest);
    J_NUM(LabelBetweenTimelineXoffest); J_NUM(LabelRotation); J_NUM(TimelineRotation);
    J_NUM(sampleFontSize); J_NUM(sampleLeftSpacingPct); J_NUM(sampleTopSpacingPct);
    J_NUM(sampleMaxWidthPct); J_NUM(sampleTranslateYPct); J_STR(sampleTextAlign);
    J_BOOL(ShowCursorTooltip);

    J_NUM(fpsPrecision); J_NUM(MaxIntervalsDivision); J_NUM(MaxIntervalDepth);
    J_NUM(BigIntPrecisionMantissa); J_NUM(tooltipfsterms);

    return o;
}

void Config::mergeFrom(const Json& j) {
    if (!j.isObj()) return;

    G_NUM(aspectratio); G_NUM(maxAllowedWidthFactor); G_NUM(panFenceOverlap);
    G_NUM(panSpeedBaseFactor); G_NUM(zoomSpeedBase); G_NUM(zoomDragFactor);
    G_NUM(wheelZoomIn); G_NUM(wheelZoomOut); G_NUM(shiftMultiplier); G_NUM(ctrlMultiplier);
    G_BOOL(ZoomIntoMouse);

    if (const Json* v = j.find("modes")) {
        if (v->isArr() && !v->arr.empty()) {
            modes.clear();
            for (auto& mo : v->arr) {
                ModeSpec m;
                if (mo.isNum()) { m.mode = (int)mo.num; m.target = "both"; }
                else if (mo.isObj()) {
                    if (const Json* mv = mo.find("mode")) m.mode = (int)mv->numOr(0);
                    if (const Json* tv = mo.find("target")) m.target = tv->strOr("both");
                }
                modes.push_back(m);
            }
        }
    }

    G_BOOL(LockScreen); G_BOOL(MathstickMode); G_BOOL(MathStick_UseLogarithmLength);
    G_NUM(MathStick_LogarithmBase); G_BOOL(DiagonalTickArrangement); G_BOOL(HarmonicInvtervalSpacing);
    G_BOOL(MultipleNotationOnSample); G_BOOL(EnableOrdinalFinder); G_BOOL(EnableSetViewPort);
    G_BOOL(SlowMode); G_BOOL(ZoomOutFencing); G_BOOL(PanOutFencing);

    G_BOOL(ShowHUD); G_BOOL(ShowLegends); G_BOOL(ShowTitle); G_BOOL(ShowFPS);
    G_BOOL(ShowDepthAdjustGui); G_BOOL(ShowOrdinalNotationConfigGui);
    G_BOOL(AlwaysShowDivisionOnIdle); G_BOOL(AlwaysShowDivisionOnInteraction);
    G_BOOL(ShowMiddleNumberLineDivision);

    G_BOOL(ShowTick); G_BOOL(Rendernumberline); G_BOOL(ShowSample); G_BOOL(ShowLabel);
    G_BOOL(ShowTimelineLabel); G_BOOL(ShowCurrentPositionState);

    G_BOOL(ColorTick); G_BOOL(ColorSample); G_BOOL(ColorLabel); G_BOOL(ColorTimelineLabel);
    G_BOOL(EnableTickColorBlending);

    G_STR(BackgroundColor); G_STR(DefaultTickColor); G_STR(DefaultTimelineLabelColor);
    G_STR(DefaultSampleColor); G_STR(DefaultLabelColor); G_STR(ScreenDivisionLineColor);
    G_STR(FPSLabelColor); G_STR(DepthAdjustGuiColor); G_STR(TitleColor);
    G_STR(AddNotationBtnColor); G_STR(RemoveNotationBtnColor); G_STR(SelectNotationBoxColor);
    G_STR(ChangeNotationDisplayLocationBtnColor); G_STR(MiddleNumberLineDivisionColor);
    G_STR(ZoomSelectionFillColor); G_STR(RevertBtnColor); G_STR(ResetBtnColor);
    G_STR(ConfigMenuBtnColor); G_STR(CurrentPositionStateTextColor);

    G_NUM(TickSpacing); G_NUM(Tickheight); G_NUM(TickWidth); G_NUM(TickAnchorPoint);
    G_NUM(TickSlopeArrangement); G_NUM(TickColorMaxBrightness); G_NUM(TickColorBoostStart);
    G_NUM(TickColorMaxBoost); G_NUM(TickColorMaxChannel);

    G_NUM(labelscount); G_NUM(LabelBetweenTimelineSpacing); G_NUM(LabelBetweenTickSpacing);
    G_NUM(LabelBetweenLabelSpacing); G_NUM(TickBetweenLabelXoffest); G_NUM(LabelBetweenLabelXoffest);
    G_NUM(LabelBetweenTimelineXoffest); G_NUM(LabelRotation); G_NUM(TimelineRotation);
    G_NUM(sampleFontSize); G_NUM(sampleLeftSpacingPct); G_NUM(sampleTopSpacingPct);
    G_NUM(sampleMaxWidthPct); G_NUM(sampleTranslateYPct); G_STR(sampleTextAlign);
    G_BOOL(ShowCursorTooltip);

    G_NUM(fpsPrecision); G_NUM(MaxIntervalsDivision); G_NUM(MaxIntervalDepth);
    G_NUM(BigIntPrecisionMantissa); G_NUM(tooltipfsterms);

    if (modes.empty()) modes.push_back({ 0, "both" });
}

#undef J_NUM
#undef J_BOOL
#undef J_STR
#undef G_NUM
#undef G_BOOL
#undef G_STR
