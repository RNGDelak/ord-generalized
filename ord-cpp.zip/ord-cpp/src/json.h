// Minimal JSON value with parse/serialize (for config editor & save slots).
#pragma once
#include <map>
#include <memory>
#include <string>
#include <vector>

struct Json {
    enum Type { Null, Bool, Num, Str, Arr, Obj } type = Null;
    bool b = false;
    double num = 0;
    std::string str;
    std::vector<Json> arr;
    std::map<std::string, Json> obj;

    Json() {}
    static Json mkNull() { return Json(); }
    static Json mkBool(bool v) { Json j; j.type = Bool; j.b = v; return j; }
    static Json mkNum(double v) { Json j; j.type = Num; j.num = v; return j; }
    static Json mkStr(const std::string& v) { Json j; j.type = Str; j.str = v; return j; }
    static Json mkArr() { Json j; j.type = Arr; return j; }
    static Json mkObj() { Json j; j.type = Obj; return j; }

    bool isNum() const { return type == Num; }
    bool isBool() const { return type == Bool; }
    bool isStr() const { return type == Str; }
    bool isArr() const { return type == Arr; }
    bool isObj() const { return type == Obj; }

    const Json* find(const std::string& key) const {
        if (type != Obj) return nullptr;
        auto it = obj.find(key);
        return it == obj.end() ? nullptr : &it->second;
    }
    double numOr(double def) const { return type == Num ? num : def; }
    bool boolOr(bool def) const { return type == Bool ? b : def; }
    std::string strOr(const std::string& def) const { return type == Str ? str : def; }

    std::string dump(int indent = 4, int cur = 0) const;
    static bool parse(const std::string& text, Json& out, std::string& err);
};
