// Pointer LPrSS notation — port of Libs/PLPrSS.js
// Ordinal representation: flat vector<int> (parent-pointer sequence).
// Display "CNF" converts to Veblen normal form via an intermediate
// Veblen object tree (Zero | Array | AP-pair).
#include "notation.h"
#include <algorithm>
#include <cctype>
#include <functional>
#include <sstream>

namespace {

// ---------- Veblen object tree ----------
struct VNode;
using VP = std::shared_ptr<VNode>;

struct VNode {
    enum Kind { Arr, AP } kind; // nullptr VP means Zero
    std::vector<VP> arr;        // Arr
    VP a, b;                    // AP
};

bool isZero(const VP& p) { return !p; }
bool isArr(const VP& p) { return p && p->kind == VNode::Arr; }
bool isAP(const VP& p) { return p && p->kind == VNode::AP; }

VP mkArr(std::vector<VP> v = {}) { auto p = std::make_shared<VNode>(); p->kind = VNode::Arr; p->arr = std::move(v); return p; }
VP mkAP(VP a, VP b) { auto p = std::make_shared<VNode>(); p->kind = VNode::AP; p->a = a; p->b = b; return p; }
VP nat1() { return mkAP(nullptr, nullptr); } // {0:0, 1:0} = ordinal 1

VP cloneV(const VP& s) {
    if (isZero(s)) return nullptr;
    if (isArr(s)) {
        std::vector<VP> v;
        for (auto& e : s->arr) v.push_back(cloneV(e));
        return mkArr(v);
    }
    return mkAP(cloneV(s->a), cloneV(s->b));
}

VP buildVeblenObjectStr(const std::string& s); // fwd

bool equalStandard(const VP& x, const VP& y) {
    if (isZero(x)) return isZero(y);
    if (isArr(x)) {
        if (!isArr(y) || x->arr.size() != y->arr.size()) return false;
        for (size_t i = 0; i < x->arr.size(); i++)
            if (!equalStandard(x->arr[i], y->arr[i])) return false;
        return true;
    }
    if (isAP(x)) return isAP(y) && equalStandard(x->a, y->a) && equalStandard(x->b, y->b);
    return false;
}

bool lessThanStandard(const VP& x0, const VP& y0) {
    VP x = x0, y = y0;
    if (isZero(x)) return !isZero(y);
    if (isZero(y)) return false;
    bool xt = isArr(x), yt = isArr(y);
    if (!xt && !yt) {
        // both AP
        if (equalStandard(x->a, y->a)) return lessThanStandard(x->b, y->b);
        return lessThanStandard(x->a, y->a) ? lessThanStandard(x->b, y) : lessThanStandard(x, y->b);
    }
    if (xt && !yt) return lessThanStandard(x->arr[0], y);
    if (!xt && yt) return equalStandard(x, y->arr[0]) || lessThanStandard(x, y->arr[0]);
    // both arrays
    size_t l = std::min(x->arr.size(), y->arr.size());
    for (size_t i = 0; i < l; i++)
        if (!equalStandard(x->arr[i], y->arr[i])) return lessThanStandard(x->arr[i], y->arr[i]);
    return x->arr.size() < y->arr.size();
}

std::string infixVeblen(const VP& s) {
    if (isZero(s)) return "0";
    if (isArr(s)) {
        std::string out;
        for (size_t i = 0; i < s->arr.size(); i++) {
            if (i) out += "+";
            out += infixVeblen(s->arr[i]);
        }
        return out;
    }
    return "(" + infixVeblen(s->a) + "," + infixVeblen(s->b) + ")";
}

VP flattenArraysVeblen(const VP& s) {
    if (isZero(s)) return nullptr;
    if (isArr(s)) {
        std::vector<VP> r;
        for (auto& e : s->arr) {
            VP f = flattenArraysVeblen(e);
            if (isArr(f)) for (auto& g : f->arr) r.push_back(g);
            else r.push_back(f);
        }
        return r.size() == 1 ? r[0] : mkArr(r);
    }
    if (isAP(s)) return mkAP(flattenArraysVeblen(s->a), flattenArraysVeblen(s->b));
    return nullptr;
}

VP standardizeVeblen(const VP& s) {
    if (isZero(s)) return nullptr;
    if (isArr(s)) {
        std::vector<VP> r;
        for (auto& e : s->arr) {
            VP std_e = standardizeVeblen(e);
            if (isArr(std_e)) for (auto& g : std_e->arr) r.push_back(g);
            else r.push_back(std_e);
        }
        // JS: for (i = r.length; i >= 0; i--) if (r[i]===0 || (r[i+1] && lt(r[i], r[i+1]))) splice(i,1)
        for (long long i = (long long)r.size(); i >= 0; i--) {
            if ((size_t)i >= r.size()) continue; // r[length] is undefined in JS: no-op
            bool drop = isZero(r[i]) ||
                        ((i + 1 < (long long)r.size()) && lessThanStandard(r[i], r[i + 1]));
            if (drop) r.erase(r.begin() + i);
        }
        if (r.size() == 1) return r[0];
        return mkArr(r);
    }
    if (isAP(s)) {
        VP a = standardizeVeblen(s->a);
        VP b = standardizeVeblen(s->b);
        if (isAP(b) && lessThanStandard(a, b->a)) return b;
        return mkAP(a, b);
    }
    return nullptr;
}

bool isNatV(const VP& s) {
    if (isZero(s)) return true; // JS isNat(0) -> number 0 path: isFinite&integer&>=0 -> true
    if (isArr(s)) {
        for (auto& e : s->arr)
            if (!equalStandard(e, nat1())) return false;
        return true;
    }
    if (isAP(s)) return equalStandard(s, nat1());
    return false;
}

VP buildVeblenNat(long long n) {
    if (n == 0) return nullptr;
    if (n == 1) return nat1();
    std::vector<VP> r;
    for (long long i = 0; i < n; i++) r.push_back(nat1());
    return mkArr(r);
}

long long numerifyNatVeblen(const VP& n) {
    if (isZero(n)) return 0;
    if (isArr(n)) return (long long)n->arr.size();
    if (isAP(n)) return 1;
    return 0;
}

// normalizeVeblen: replace each decimal run n>0 by n copies of "(0,0)" joined
// with "+", and 0 by "0".
std::string normalizeVeblen(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size();) {
        if (isdigit((unsigned char)s[i])) {
            size_t j = i;
            while (j < s.size() && isdigit((unsigned char)s[j])) j++;
            long long n = atoll(s.substr(i, j - i).c_str());
            if (n == 0) out += "0";
            else {
                for (long long k = 0; k < n; k++) {
                    if (k) out += "+";
                    out += "(0,0)";
                }
            }
            i = j;
        } else {
            out += s[i++];
        }
    }
    return out;
}

VP buildVeblenObjectStr(const std::string& sIn) {
    if (!sIn.empty() && (sIn[0] == 'p' || sIn[0] == '+')) {
        long long l = (long long)sIn.size();
        long long p = 0;
        long long i = 1;
        for (; i < l; i++) {
            if (sIn[i] == 'p' || sIn[i] == '+') ++p;
            else --p;
            if (p < 0) break;
        }
        if (i == l) throw std::runtime_error("Unexpected end of input");
        std::string left = sIn.substr(1, (size_t)(i + 1) - 1);
        std::string right = sIn.substr((size_t)i + 1);
        if ((left[0] == '0' && left.size() > 1) || (!right.empty() && right[0] == '0' && right.size() > 1))
            throw std::runtime_error("Unexpected 0");
        if (sIn[0] == 'p') return mkAP(buildVeblenObjectStr(left), buildVeblenObjectStr(right));
        return flattenArraysVeblen(mkArr({ buildVeblenObjectStr(left), buildVeblenObjectStr(right) }));
    }

    std::string s = normalizeVeblen(sIn);
    long long l = (long long)s.size();
    if (s.empty() || s == "0") return nullptr;
    long long p = 0;
    std::vector<std::string> plussep;
    long long lastsep = -1;
    for (long long i = 0; i < l; i++) {
        if (s[i] == '(') ++p;
        if (s[i] == ')') --p;
        if (p == 0 && i + 1 < l && s[i + 1] != '+') throw std::runtime_error("Expected a plus sign " + s);
        if (p == 0) { plussep.push_back(s.substr((size_t)lastsep + 1, (size_t)(i - lastsep))); lastsep = i; }
        if (p < 0) throw std::runtime_error("Unmatched parenthesis");
    }
    if (p > 0) throw std::runtime_error("Unmatched parenthesis");
    if (plussep.size() == 1) {
        long long i = 1;
        p = 0;
        for (; i < l; i++) {
            if (s[i] == '(') ++p;
            if (s[i] == ')') --p;
            if (p <= 0 && s[i] != '+' && i + 1 < l && s[i + 1] != '+') break;
        }
        if (p != 0 || (size_t)i + 1 >= s.size() || s[i + 1] != ',') throw std::runtime_error("Expected a comma " + s);
        return mkAP(buildVeblenObjectStr(s.substr(1, (size_t)i)), buildVeblenObjectStr(s.substr((size_t)i + 2, s.size() - (size_t)i - 3)));
    }
    std::vector<VP> v;
    for (auto& t : plussep) v.push_back(buildVeblenObjectStr(t));
    return mkArr(v);
}

// ---------- abbreviateVeblen ----------
std::string abbreviateVeblen(std::string s) {
    // replace runs of "(0,0)(+ (0,0))*" by their count
    {
        std::string out;
        size_t i = 0;
        const std::string unit = "(0,0)";
        while (i < s.size()) {
            if (s.compare(i, unit.size(), unit) == 0) {
                long long count = 1;
                size_t j = i + unit.size();
                while (j < s.size() && s[j] == '+' && s.compare(j + 1, unit.size(), unit) == 0) {
                    count++;
                    j += 1 + unit.size();
                }
                out += std::to_string(count);
                i = j;
            } else {
                out += s[i++];
            }
        }
        s = out;
    }

    size_t i = 0;
    std::function<std::string()> parseExpr;
    std::function<std::string()> parseTerm = [&]() -> std::string {
        if (i >= s.size()) throw std::runtime_error("unexpected end");
        if (s[i] != '(') {
            size_t start = i;
            while (i < s.size() && s[i] != ',' && s[i] != '(' && s[i] != ')' && s[i] != '+') i++;
            return s.substr(start, i - start);
        }
        i++; // '('
        std::string left = parseExpr();
        if (i >= s.size() || s[i] != ',') throw std::runtime_error("Expected ','");
        i++;
        std::string right = parseExpr();
        if (i >= s.size() || s[i] != ')') throw std::runtime_error("Expected ')'");
        i++;
        if (left == "0") {
            if (right == "0") return "1";
            if (right == "1") return "&omega;";
            return "&omega;<sup>" + right + "</sup>";
        }
        if (left == "1") return "&epsilon;<sub>" + right + "</sub>";
        if (left == "2") return "&zeta;<sub>" + right + "</sub>";
        if (left == "3") return "&eta;<sub>" + right + "</sub>";
        return "&phi;<sub>" + left + "</sub>(" + right + ")";
    };
    parseExpr = [&]() -> std::string {
        std::vector<std::string> terms;
        terms.push_back(parseTerm());
        while (i < s.size() && s[i] == '+') {
            i++;
            terms.push_back(parseTerm());
        }
        std::vector<std::string> out;
        for (size_t j = 0; j < terms.size();) {
            size_t k = j + 1;
            while (k < terms.size() && terms[k] == terms[j]) k++;
            long long count = (long long)(k - j);
            if (terms[j] == "1") out.push_back(std::to_string(count));
            else if (count == 1) out.push_back(terms[j]);
            else out.push_back(terms[j] + "\xE2\x8B\x85" + std::to_string(count)); // ⋅
            j = k;
        }
        std::string r;
        for (size_t j = 0; j < out.size(); j++) {
            if (j) r += "+";
            r += out[j];
        }
        return r;
    };
    return parseExpr();
}

// ---------- SPrSS -> Veblen ----------
VP SPtoV(const std::vector<int>& sv) {
    size_t l = sv.size();
    VP r;
    if (l == 0) {
        r = nullptr;
    } else if (l == 1) {
        r = nat1();
    } else {
        // split on zeros
        std::vector<std::vector<int>> zerosplit;
        size_t i = 0;
        while (i < l) {
            size_t last = i;
            i++;
            while (i < l && sv[i] != 0) i++;
            zerosplit.push_back(std::vector<int>(sv.begin() + last, sv.begin() + i));
            // JS: i = s.indexOf(0, i+1); if -1 -> l
            if (i < l && sv[i] == 0) { /* next chunk starts here */ }
            else i = l;
        }
        if (zerosplit.size() == 1) {
            const std::vector<int>& s = sv;
            std::vector<std::vector<int>> phisplit;
            size_t last = 1;
            int lastnum = s[1];
            for (size_t k = 2; k < l; k++) {
                if (s[k] <= lastnum) {
                    phisplit.push_back(std::vector<int>(s.begin() + last, s.begin() + k));
                    last = k;
                    lastnum = s[k];
                }
            }
            phisplit.push_back(std::vector<int>(s.begin() + last, s.begin() + l));
            r = nullptr;
            for (size_t k = 0; k < phisplit.size(); k++) {
                int first = phisplit[k][0];
                VP sub = buildVeblenNat(first - 1);
                std::vector<int> innerseq;
                for (int v : phisplit[k]) innerseq.push_back(v - first);
                VP inner = SPtoV(innerseq);
                if (k > 0 && phisplit[k - 1][0] == first) {
                    if (isArr(r->b)) r->b->arr.push_back(inner);
                    else r->b = mkArr({ r->b, inner });
                } else if (isZero(r)) {
                    if (!isZero(sub)) {
                        if (isArr(inner) && !inner->arr.empty() && equalStandard(inner->arr[0], nat1())) {
                            // JS: inner.unshift() — no-op
                        } else if (isAP(inner) && equalStandard(inner, nat1())) {
                            inner = nullptr;
                        }
                    }
                    r = mkAP(sub, inner);
                } else {
                    r = mkAP(sub, mkArr({ r, inner }));
                }
            }
        } else {
            std::vector<VP> parts;
            for (auto& e : zerosplit) parts.push_back(SPtoV(e));
            r = mkArr(parts);
        }
    }
    return standardizeVeblen(r);
}

// ---------- PLPrSS ordinal ----------
struct PlOrd {
    bool isLimit = false;
    std::vector<int> seq;
};
using P = std::shared_ptr<PlOrd>;
P mkP() { return std::make_shared<PlOrd>(); }
P castP(const Ord& o) { return std::static_pointer_cast<PlOrd>(o); }

std::vector<int> getParents(const std::vector<int>& ord) {
    std::vector<int> Par(ord.size());
    for (size_t i = 0; i < ord.size(); i++) {
        long long p = (long long)i - 1;
        while (p >= 0 && ord[p] >= ord[i]) p = Par[p];
        Par[i] = (int)p;
    }
    return Par;
}

class PlPrssNotation : public Notation {
public:
    std::string title() const override { return "pointer LPrSS transfinite number line"; }

    Ord zero() const override { return mkP(); }
    Ord limit() const override { P p = mkP(); p->isLimit = true; return p; }

    int cmp(const Ord& a, const Ord& b) const override {
        P x = castP(a), y = castP(b);
        if (x->isLimit && y->isLimit) return 0;
        if (x->isLimit) return 1;
        if (y->isLimit) return -1;
        size_t n = std::min(x->seq.size(), y->seq.size());
        for (size_t i = 0; i < n; i++)
            if (x->seq[i] != y->seq[i]) return x->seq[i] < y->seq[i] ? -1 : 1;
        if (x->seq.size() < y->seq.size()) return -1;
        if (x->seq.size() > y->seq.size()) return 1;
        return 0;
    }

    bool isSuccessor(const Ord& a) const override {
        P x = castP(a);
        return !x->isLimit && (x->seq.empty() || x->seq.back() == 0);
    }

    Ord fs(const Ord& a, long long n) const override {
        P x = castP(a);
        if (x->isLimit) { P r = mkP(); r->seq = { 0, (int)n + 1 }; return r; }
        if (x->seq.empty()) return mkP();

        size_t len = x->seq.size();
        std::vector<int> Par = getParents(x->seq);
        size_t lastIdx = len - 1;
        int head = x->seq[lastIdx];

        if (head == 0) { P r = mkP(); r->seq.assign(x->seq.begin(), x->seq.begin() + lastIdx); return r; }

        int root = Par[lastIdx];
        if (root < 0) { P r = mkP(); r->seq.assign(x->seq.begin(), x->seq.begin() + lastIdx); return r; }

        P r = mkP();
        r->seq.assign(x->seq.begin(), x->seq.begin() + lastIdx);
        std::vector<int> part(r->seq.begin() + root, r->seq.end());
        int offset = head - x->seq[root] - 1;
        for (long long i = 1; i <= n; i++) {
            int curOffset = offset * (int)i;
            for (size_t j = 0; j < part.size(); j++) r->seq.push_back(part[j] + curOffset);
        }
        return r;
    }

    bool lastEntryIsZero(const Ord& a) const override {
        P x = castP(a);
        return !x->isLimit && !x->seq.empty() && x->seq.back() == 0;
    }

    std::vector<std::string> displayNames() const override { return { "normal", "CNF" }; }

    std::string display(const Ord& a, const std::string& mode) const override {
        P x = castP(a);
        if (x->isLimit) return "Limit";
        if (x->seq.empty()) return "0";
        if (mode == "normal") {
            std::string s = "(";
            for (size_t i = 0; i < x->seq.size(); i++) {
                if (i) s += ",";
                s += std::to_string(x->seq[i]);
            }
            return s + ")";
        }
        // CNF
        try {
            VP v = SPtoV(x->seq);
            return abbreviateVeblen(infixVeblen(v));
        } catch (...) {
            return "?";
        }
    }

    std::string classifyOrdinal(const Ord& a) const override {
        P x = castP(a);
        if (x->isLimit) return "#808080";
        if (x->seq.empty()) return "#808080";
        if (isSuccessor(a)) return "#a00000";

        bool tower = true;
        for (size_t i = 0; i < x->seq.size(); i++)
            if (x->seq[i] != (int)i) { tower = false; break; }
        if (tower) return "#ffffff";

        int zeroCount = 0;
        long long zeroIndex = -1;
        for (size_t i = 0; i < x->seq.size(); i++)
            if (x->seq[i] == 0) { zeroCount++; zeroIndex = (long long)i; }

        if (zeroCount >= 2) return "#ffA000";
        if (zeroCount == 1) {
            std::vector<int> Par = getParents(x->seq);
            int lastChild = -1;
            for (size_t i = (size_t)zeroIndex + 1; i < x->seq.size(); i++)
                if (Par[i] == zeroIndex) lastChild = x->seq[i];
            if (lastChild == 1) return "#ffff00";
            if (lastChild == 2) return "#0fff00";
            if (lastChild >= 3) return "#00fff0";
        }
        return "#ffA000";
    }

    bool hasParser() const override { return true; }

    Ord parse(const std::string& str) const override {
        std::string s = str;
        auto a = s.find_first_not_of(" \t\r\n");
        auto b = s.find_last_not_of(" \t\r\n");
        s = (a == std::string::npos) ? "" : s.substr(a, b - a + 1);
        if (s.empty() || s == "0") return mkP();
        std::string cleaned;
        for (char c : s) if (c != '(' && c != ')') cleaned += c;
        P r = mkP();
        std::stringstream ss(cleaned);
        std::string tok;
        while (std::getline(ss, tok, ',')) {
            auto t = tok.find_first_not_of(" \t");
            if (t == std::string::npos) { r->seq.push_back(0); continue; }
            r->seq.push_back(atoi(tok.c_str() + t));
        }
        return r;
    }

    std::vector<std::pair<std::string, std::string>> ordinalTypes() const override {
        return {
            { "Zero", "#808080" },
            { "Successor Ordinal", "#a00000" },
            { "Limit Ordinal", "#ffA000" },
            { "Power of \xCF\x89", "#ffff00" },
            { "Tower of \xCF\x89", "#ffffff" },
            { "\xCE\xB5 Ordinal", "#0fff00" },
            { "Veblen Ordinal", "#00fff0" },
        };
    }

    std::vector<std::pair<std::string, Ord>> aliases() const override {
        P p1 = mkP(); p1->seq = { 0, 2 };
        P lim = mkP(); lim->isLimit = true;
        return {
            { "Small Cantor Ordinal", p1 },
            { "\xCF\x86(0,\xCF\x89)", lim },
        };
    }

    std::vector<ModeSpec> initialModes() const override { return { { 1, "both" } }; }
};

} // namespace

std::shared_ptr<Notation> createPlPrssNotation() { return std::make_shared<PlPrssNotation>(); }
