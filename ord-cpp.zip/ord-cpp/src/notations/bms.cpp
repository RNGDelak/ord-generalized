// Bashicu Matrix System (BMS) — port of Libs/BMS.js
// Ordinal representation: matrix = vector of columns (vector<int>).
#include "notation.h"
#include <algorithm>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>

namespace {

using Col = std::vector<int>;
using Mat = std::vector<Col>;

struct BmsOrd {
    bool isLimit = false;
    Mat m;
};
using B = std::shared_ptr<BmsOrd>;
B mkB() { return std::make_shared<BmsOrd>(); }
B castB(const Ord& o) { return std::static_pointer_cast<BmsOrd>(o); }

// ---------- cmp ----------
int seqCompare(const Col& a, const Col& b) {
    size_t n = std::min(a.size(), b.size());
    for (size_t i = 0; i < n; i++) {
        if (a[i] < b[i]) return -1;
        if (a[i] > b[i]) return 1;
    }
    if (a.size() < b.size()) return -1;
    if (a.size() > b.size()) return 1;
    return 0;
}

int cmpMat(const Mat& m1, const Mat& m2) {
    size_t n = std::min(m1.size(), m2.size());
    for (size_t i = 0; i < n; i++) {
        Col c1 = m1[i], c2 = m2[i];
        if (c1.size() < c2.size()) c1.resize(c2.size(), 0);
        else if (c2.size() < c1.size()) c2.resize(c1.size(), 0);
        int c = seqCompare(c1, c2);
        if (c) return c;
    }
    if (m1.size() < m2.size()) return -1;
    if (m1.size() > m2.size()) return 1;
    return 0;
}

int cmpB(const B& a, const B& b) {
    if (a->isLimit && b->isLimit) return 0;
    if (a->isLimit) return 1;
    if (b->isLimit) return -1;
    return cmpMat(a->m, b->m);
}

// ---------- helpers ----------
Mat processMatrix(const Mat& M, size_t minW) {
    size_t width = minW;
    for (auto& col : M) width = std::max(width, col.size());
    Mat r;
    for (auto& col : M) {
        Col c = col;
        c.resize(width, 0);
        r.push_back(c);
    }
    return r;
}

int lastPositiveRow(const Col& column) {
    for (size_t i = column.size(); i-- > 0;)
        if (column[i] > 0) return (int)i + 1;
    return 0;
}

Col incrementPrefix(const Col& column, int count) {
    if (count < 0 || (size_t)count > column.size()) throw std::runtime_error("Illegal prefix length");
    Col r = column;
    for (int i = 0; i < count; i++) r[i] += 1;
    return r;
}

Col incrementRow(const Col& column, int row) {
    if (row < 1 || (size_t)row > column.size()) throw std::runtime_error("Illegal actual row number");
    Col r = column;
    r[row - 1] += 1;
    return r;
}

Col firstRowColumn(int value, size_t n) {
    Col c(n, 0);
    c[0] = value;
    return c;
}

int compareArrays(const Col& a, const Col& b) {
    size_t len = std::min(a.size(), b.size());
    for (size_t i = 0; i < len; i++) {
        if (a[i] < b[i]) return -1;
        if (a[i] > b[i]) return 1;
    }
    if (a.size() < b.size()) return -1;
    if (a.size() > b.size()) return 1;
    return 0;
}

int compareColumnSequences(const Mat& a, const Mat& b) {
    size_t len = std::min(a.size(), b.size());
    for (size_t i = 0; i < len; i++) {
        int c = compareArrays(a[i], b[i]);
        if (c != 0) return c;
    }
    if (a.size() < b.size()) return -1;
    if (a.size() > b.size()) return 1;
    return 0;
}

// ---------- ancestor index (for DBMS) ----------
struct AncestorIndex {
    size_t n; // rows per column
    std::vector<std::vector<long long>> parents;        // [r][c], -1 = null
    std::vector<std::vector<std::set<int>>> ancestors;  // [r][c]

    explicit AncestorIndex(const Mat& columns) {
        if (columns.empty()) throw std::runtime_error("Cannot build ancestor relation for empty matrix");
        n = columns[0].size();
        size_t colCount = columns.size();
        parents.assign(n + 1, std::vector<long long>(colCount, -1));
        ancestors.assign(n + 1, std::vector<std::set<int>>(colCount));

        for (size_t c = 0; c < colCount; c++) {
            parents[0][c] = (c > 0) ? (long long)c - 1 : -1;
            for (size_t i = 0; i < c; i++) ancestors[0][c].insert((int)i);
        }
        for (size_t r = 1; r <= n; r++) {
            size_t rowIdx = r - 1;
            for (size_t c = 0; c < colCount; c++) {
                std::vector<int> cand(ancestors[r - 1][c].begin(), ancestors[r - 1][c].end());
                std::sort(cand.begin(), cand.end(), [](int a, int b) { return a > b; });
                long long parent = -1;
                for (int cd : cand) {
                    if (columns[cd][rowIdx] < columns[c][rowIdx]) { parent = cd; break; }
                }
                parents[r][c] = parent;
                if (parent >= 0) {
                    ancestors[r][c] = ancestors[r][(size_t)parent];
                    ancestors[r][c].insert((int)parent);
                }
            }
        }
    }

    bool hasAncestorColumn(size_t elementColumn, size_t row, size_t ancestorColumn) const {
        return ancestors[row][elementColumn].count((int)ancestorColumn) > 0;
    }
    bool parentIsColumn(size_t elementColumn, size_t row, long long parentColumn) const {
        return parents[row][elementColumn] == parentColumn;
    }
};

Mat normalizeMatrix(const Mat& matrix) {
    if (matrix.empty()) throw std::runtime_error("Matrix cannot be empty");
    size_t maxLen = 2;
    for (auto& col : matrix) maxLen = std::max(maxLen, col.size());
    Mat result;
    for (auto& col : matrix) {
        Col c = col;
        for (int v : c) if (v < 0) throw std::runtime_error("Columns must contain only non-negative integers");
        c.resize(maxLen, 0);
        result.push_back(c);
    }
    return result;
}

Mat bmsToDbms(const Mat& matrixIn, int stepLimit = 100000) {
    Mat columns = normalizeMatrix(matrixIn);
    size_t n = columns[0].size();
    size_t index = 0;
    long long steps = 0;

    while (index < columns.size()) {
        if (++steps > stepLimit) throw std::runtime_error("Step limit exceeded");

        const Col& x = columns[index];
        int k = lastPositiveRow(x);
        if ((size_t)k >= n - 1) { index++; continue; }

        Col y = incrementPrefix(x, k + 1);
        Col z = incrementRow(y, k + 2);

        size_t xStart = index + 1;
        if (xStart >= columns.size() || compareArrays(columns[xStart], z) < 0) { index++; continue; }

        size_t xEnd = xStart;
        while (xEnd < columns.size() && compareArrays(columns[xEnd], z) >= 0) xEnd++;

        AncestorIndex anc(columns);
        Mat xPrime;

        for (size_t cursor = xStart; cursor < xEnd; cursor++) {
            const Col& t = columns[cursor];
            long long l = -1;
            for (long long row = 0; row <= k + 1; row++)
                if (anc.hasAncestorColumn(cursor, (size_t)row, index)) l = row;
            if (l < 0) throw std::runtime_error("Cannot find largest l");
            bool isLast = (cursor == xEnd - 1);
            if (isLast) {
                if ((size_t)l >= n) throw std::runtime_error("Cannot read t[l+1]");
                if (anc.parentIsColumn(cursor, (size_t)l, (long long)index) && t[l] == 0) l--;
            }
            if (l < 0) throw std::runtime_error("last column adjustment made l negative");
            xPrime.push_back(incrementPrefix(t, (int)l));
        }

        Mat remainder(columns.begin() + xEnd, columns.end());
        Mat compMatrix;
        compMatrix.push_back(y);
        for (auto& xp : xPrime) compMatrix.push_back(xp);
        compMatrix.push_back(firstRowColumn(y[0] + 1, n));

        columns.erase(columns.begin() + xStart, columns.begin() + xEnd);

        if (compareColumnSequences(compMatrix, remainder) > 0) {
            Mat toInsert;
            toInsert.push_back(y);
            for (auto& xp : xPrime) toInsert.push_back(xp);
            columns.insert(columns.begin() + xStart, toInsert.begin(), toInsert.end());
        }
        index++;
    }
    return columns;
}

Mat trimTrailingZeros(const Mat& matrix) {
    Mat r;
    for (auto& row : matrix) {
        long long last = -1;
        for (size_t i = 0; i < row.size(); i++) if (row[i] != 0) last = (long long)i;
        size_t keep = std::max((size_t)1, (size_t)(last + 1));
        r.push_back(Col(row.begin(), row.begin() + keep));
    }
    return r;
}

// ---------- display converters ----------
std::string matToStr(const Mat& m) {
    std::string s;
    for (auto& col : m) {
        s += "(";
        for (size_t i = 0; i < col.size(); i++) {
            if (i) s += ",";
            s += std::to_string(col[i]);
        }
        s += ")";
    }
    return s;
}

Mat BMStoPMS(const Mat& matrix) {
    Mat out;
    if (matrix.empty()) return out;
    size_t cols = matrix[0].size();
    std::vector<std::map<int, int>> lastAtDepth(cols);
    for (size_t i = 0; i < matrix.size(); i++) {
        Col newRow(cols, 0);
        for (size_t j = 0; j < cols; j++) {
            int depth = j < matrix[i].size() ? matrix[i][j] : 0;
            if (depth == 0) {
                newRow[j] = 0;
            } else {
                auto it = lastAtDepth[j].find(depth - 1);
                if (it == lastAtDepth[j].end()) throw std::runtime_error("Invalid BMS matrix");
                newRow[j] = (int)(i + 1) - it->second;
            }
            lastAtDepth[j][depth] = (int)(i + 1);
        }
        out.push_back(newRow);
    }
    return out;
}

Mat PMStoAMS(const Mat& matrix) {
    Mat out;
    for (size_t i = 0; i < matrix.size(); i++) {
        Col row;
        for (int v : matrix[i]) row.push_back(v == 0 ? 0 : (int)(i + 1) - v);
        out.push_back(row);
    }
    return out;
}

std::string PMStoVZ(const Mat& matrix) {
    std::vector<int> sequence;
    for (size_t i = 0; i < matrix.size(); i++) {
        std::vector<int> row;
        for (size_t j = 0; j < matrix[i].size(); j++) {
            int height = -1;
            long long index = (long long)i + 1;
            while (index > 0) {
                height++;
                int val = ((size_t)(index - 1) < matrix.size() && j < matrix[index - 1].size())
                              ? matrix[index - 1][j] : 0;
                index -= (val != 0 ? val : index);
            }
            row.push_back(height);
        }
        while (row.size() > 1 && row.back() == 0) row.pop_back();
        int v = row[0] + 1;
        sequence.push_back(v);
        for (size_t j = 1; j < row.size(); j++) sequence.push_back(v + row[j] + 1);
    }
    std::string s;
    for (size_t i = 0; i < sequence.size(); i++) {
        if (i) s += ",";
        s += std::to_string(sequence[i]);
    }
    return s;
}

std::string BMS_to_0Y(const Mat& matrixIn) {
    if (matrixIn.empty() || matrixIn[0].empty()) return "";
    Mat matrix = matrixIn;
    size_t X = matrix.size();
    size_t Y = 0;
    for (auto& col : matrix) Y = std::max(Y, col.size());
    for (auto& col : matrix) col.resize(Y, 0);

    std::vector<std::vector<long long>> parentMatrix(X);
    for (size_t y = 0; y < Y; y++) {
        for (size_t x = 0; x < X; x++) {
            long long p;
            if (y == 0) {
                for (p = (long long)x; p >= 0; p--)
                    if (matrix[p][y] < matrix[x][y]) break;
            } else {
                for (p = (long long)x; p >= 0; p = parentMatrix[p][y - 1])
                    if (matrix[p][y] < matrix[x][y]) break;
            }
            if (y == 0) parentMatrix[x].clear();
            parentMatrix[x].push_back(p);
        }
    }

    std::vector<long long> a(X, 1);
    for (size_t y = Y; y-- > 0;) {
        for (size_t x = 0; x < X; x++) {
            if (matrix[x][y] == 0) a[x] = 1;
            else {
                long long par = parentMatrix[x][y];
                a[x] = (par >= 0) ? a[x] + a[par] : a[x]; // NaN case -> keep (invalid input)
            }
        }
    }
    std::string s;
    for (size_t x = 0; x < X; x++) {
        if (x) s += ",";
        s += std::to_string(a[x]);
    }
    return s;
}

// ---------- Conv_BMS_OCF: string-based ordinal arithmetic engine ----------
namespace ocf {

using S = std::string;
using SS = std::pair<S, S>;

SS splitOcf(const S& a, const S& x); // fwd

long long paren(const S& x, long long n) {
    int q = x[n] == '(' ? 1 : -1;
    long long i = n, t = 0;
    while (true) {
        t += (x[i] == '(' ? 1 : x[i] == ')' ? -1 : 0);
        if (!t) break;
        i += q;
    }
    return i;
}

SS firstTerm(const S& x) {
    long long m = paren(x, 1);
    S rest = (m + 2 < (long long)x.size()) ? x.substr(m + 2) : S();
    return { x.substr(0, m + 1), rest.empty() ? S("0") : rest };
}

SS lastTerm(const S& x) {
    long long m = paren(x, (long long)x.size() - 1);
    S first = (m - 2 > 0) ? x.substr(0, m - 2) : S();
    return { first.empty() ? S("0") : first, x.substr(m - 1) };
}

S arg(const S& x) {
    S t = firstTerm(x).first;
    return t.substr(2, t.size() - 3);
}

bool lt(const S& x, const S& y) {
    if (y == "0") return false;
    if (x == "0") return true;
    if (x[0] == 'p' && y[0] == 'P') return true;
    if (x[0] == 'P' && y[0] == 'p') return false;
    S ax = arg(x), ay = arg(y);
    if (ax != ay) return lt(ax, ay);
    return lt(firstTerm(x).second, firstTerm(y).second);
}

bool gt(const S& x, const S& y) { return !(x == y || lt(x, y)); }

S add(const S& x, const S& y) {
    if (x == "0") return y;
    if (y == "0") return x;
    SS fx = firstTerm(x), fy = firstTerm(y);
    if (lt(fx.first, fy.first)) return y;
    S w = add(fx.second, y);
    return w != "0" ? fx.first + "+" + w : fx.first;
}

S sub(const S& x, const S& y) {
    if (x == "0") return "0";
    if (y == "0") return x;
    if (lt(firstTerm(y).first, firstTerm(x).first)) return x;
    return sub(firstTerm(x).second, firstTerm(y).second);
}

SS sua(const S& x) { return splitOcf(x, "P(0)"); }

S expOcf(const S& a) {
    if (a[0] == 'P') return "P(" + sub(a, "P(0)") + ")";
    if (lt(a, "p(p(P(0)))")) return "p(" + a + ")";
    SS s = sua(arg(a));
    S p = splitOcf(s.second, "p(" + add(s.first, "P(0)") + ")").first;
    return "p(" + add(s.first, add(p, sub(a, "p(" + add(s.first, p) + ")"))) + ")";
}

S logOcf(const S& a) {
    if (a == "0") return "0";
    if (a[0] == 'P') return add("P(0)", arg(a));
    SS s = sua(arg(a));
    SS pq = splitOcf(s.second, "p(" + add(s.first, "P(0)") + ")");
    if (s.first == "0" && pq.first == "0") return pq.second;
    return add("p(" + add(s.first, pq.first) + ")", pq.second);
}

S divOcf(const S& a, const S& b) {
    if (lt(a, b)) return "0";
    return add(expOcf(sub(logOcf(a), logOcf(b))), divOcf(firstTerm(a).second, b));
}

S mulOcf(const S& a, const S& b) {
    if (b == "0") return "0";
    return add(expOcf(add(logOcf(a), logOcf(b))), mulOcf(a, firstTerm(b).second));
}

SS splitOcf(const S& a, const S& x) {
    if (a == "0") return { "0", "0" };
    if (lt(a, x)) return { "0", a };
    SS f = firstTerm(a);
    if (lt(f.first, x)) return { "0", a };
    SS r = splitOcf(f.second, x);
    return { add(f.first, r.first), r.second };
}

bool opOcf(const S& x) {
    if (lt(x, "p(p(0))")) return false;
    S f = (x[0] == 'p') ? "p(" + sua(arg(x)).first + ")" : "P(0)";
    S g, h;
    if (f == "p(0)") { f = "p(p(0))"; g = logOcf(x); h = expOcf(g); }
    else { g = divOcf(logOcf(x), f); h = expOcf(mulOcf(f, g)); }
    S d = sub(x, mulOcf(h, divOcf(x, h)));
    return d != "0";
}

bool isNatOmega(const S& x) {
    // /^(p\(0\)\+)*p\(0\)$/
    if (x.size() % 5 != 4) return false;
    for (size_t i = 0; i < x.size(); i += 5) {
        if (x.compare(i, 4, "p(0)") != 0) return false;
        if (i + 4 < x.size() && x[i + 4] != '+') return false;
    }
    return true;
}

std::string displayOCF(const S& x);

std::string replaceFirstX(const std::string& s, const std::string& v) {
    size_t p = s.find('x');
    if (p == std::string::npos) return s;
    return s.substr(0, p) + v + s.substr(p + 1);
}

std::string displayOCF(const S& x) {
    if (x == "0") return "0";
    if (isNatOmega(x)) return std::to_string((x.size() + 1) / 5);
    S f = (x[0] == 'p') ? "p(" + sua(arg(x)).first + ")" : "P(0)";
    S g, h;
    if (f == "p(0)") { f = "p(p(0))"; g = logOcf(x); h = firstTerm(x).first; }
    else { g = divOcf(logOcf(x), f); h = std::string(f == "P(0)" ? "P" : "p") + "(" + splitOcf(arg(x), f).first + ")"; }
    S c = divOcf(x, h);
    S d = sub(x, mulOcf(h, divOcf(x, h)));
    if (c == "p(0)" && d == "0") {
        if (expOcf(x) != x) {
            if (x == "p(p(0))") return "\xCF\x89"; // ω
            if (lt(x, "p(P(0))")) return "\xCF\x89<sup>" + displayOCF(logOcf(x)) + "</sup>";
            return displayOCF(f) + "<sup>" + displayOCF(g) + "</sup>";
        }
        if (x == "P(0)") return "T";
        S ax = arg(x);
        S ltx1 = lastTerm(ax).second;
        S m = divOcf(logOcf(ltx1), "P(0)");
        S k0 = expOcf(mulOcf("P(0)", divOcf(logOcf(ltx1), "P(0)")));
        k0 = divOcf(ax, k0);
        SS k = sua(k0);
        S l;
        if (k.first == "0") l = "0";
        else l = "p(" + mulOcf(expOcf(mulOcf("P(0)", m)), k.first) + ")";
        S r = "p(" + mulOcf(expOcf(mulOcf("P(0)", m)), add(k.first, "P(0)")) + ")";
        SS ab = splitOcf(k.second, r);
        S a = "p(" + mulOcf(expOcf(mulOcf("P(0)", m)), ab.first) + ")";
        if (a == "p(0)") a = "0";
        l = add(l, add(a, ab.second));
        S s;
        if (!lastTerm(ax).second.empty() && lastTerm(ax).second[0] == 'P' && ab.second != "0") {
            if (m == "p(0)") s = "\xCE\xA9"; // Ω
            else if (m == "p(0)+p(0)") s = "I";
            else if (lt(m, "p(P(P(p(P(P(P(0)))))))")) s = "I(" + displayOCF(sub(m, "p(0)+p(0)")) + ",x)";
            else if (m == "P(0)") s = "M";
            if (s.empty()) return "\xCF\x88(" + displayOCF(ax) + ")"; // ψ
            if (l == "p(0)") return replaceFirstX(s, "0");
            if (s.find('x') != std::string::npos) return replaceFirstX(s, displayOCF(sub(l, "p(0)")));
            return s + "<sub>" + displayOCF(l) + "</sub>";
        }
        return "\xCF\x88(" + displayOCF(ax) + ")";
    }
    std::string a = displayOCF(h);
    if (c != "p(0)") {
        if (!opOcf(c)) a += displayOCF(c);
        else a += "&sdot;(" + displayOCF(c) + ")";
    }
    if (d != "0") a += "+" + displayOCF(d);
    return a;
}

// ---------- matrix -> OCF string ----------
long long P_func(const Mat& M, long long r, long long n) {
    if (r == -1) return n - 1;
    long long q = P_func(M, r - 1, n);
    while (q > -1 && M[q][r] >= M[n][r]) q = P_func(M, r - 1, q);
    return q;
}

std::vector<long long> C(const Mat& M, long long n) {
    std::vector<long long> X;
    for (size_t i = 0; i < M.size(); i++)
        if (P_func(M, 0, (long long)i) == n) X.push_back((long long)i);
    return X;
}

std::vector<long long> CR(const Mat& M, long long n) {
    std::vector<long long> X;
    for (size_t i = 0; i < M.size(); i++) {
        if (P_func(M, 0, (long long)i) == n) {
            X.push_back((long long)i);
            if (M[i][2]) {
                auto sub = CR(M, (long long)i);
                X.insert(X.end(), sub.begin(), sub.end());
            }
        }
    }
    return X;
}

bool eqVec(const Col& a, const Col& b) {
    size_t n = a.size() == 2 ? 2 : a.size();
    if (b.size() < n) return false;
    for (size_t i = 0; i < n; i++) if (a[i] != b[i]) return false;
    return true;
}

struct UResult { int tag; long long idx; }; // idx -1 = null

UResult U(const Mat& M, long long n) {
    if (M[n][1] == 0 || M[n][2] == 1 || (size_t)n + 1 == M.size()) return { 0, -1 };
    long long m = P_func(M, 1, n);
    Col L = { M[m][0] + 1, M[n][1], M[m][2] + 1 };
    if (P_func(M, 1, n) == P_func(M, 1, n + 1) && eqVec(M[n + 1], L)) return { 1, n + 1 };
    long long q = n, p = n;
    while (q != -1) {
        q = P_func(M, 0, q);
        if (q >= 0 && P_func(M, 1, n) == P_func(M, 1, q) && eqVec(M[q], L) && M[n + 1][0] > M[q][0]) {
            if (M[p][2] == 1) return { 2, q };
            return { 1, q };
        }
        p = q;
    }
    return { 0, -1 };
}

S mv(const Mat& M, long long n, long long k);
S ov(const Mat& M, long long n, long long k);
S v(const Mat& M, long long n, long long k);
S o(const Mat& M, long long n, long long k);

bool breakCond(long long i, long long k) { return k > 0 && i > k; }

S mv(const Mat& M, long long n, long long k) {
    if (k != 0) { // `if (k)`; undefined -> -1 handled by callers
        std::vector<long long> A = { k };
        while (A.back() != n) {
            long long nx = P_func(M, 0, A.back());
            if (nx < 0) break; // defensive (JS would throw)
            A.push_back(nx);
            if (!M[A.back()][0]) break;
        }
        bool includesN = std::find(A.begin(), A.end(), n) != A.end();
        if (includesN) {
            for (size_t i = A.size(); i-- > 0;) {
                if (M[A[i]][2] == 0) { k = A[i]; break; }
            }
        }
    }
    S Sv = "0";
    for (long long i : C(M, n)) {
        if (breakCond(i, k)) break;
        if (M[i][2] != 1) continue;
        S q = "0";
        for (long long j : C(M, i)) {
            if (breakCond(j, k)) break;
            q = add(q, ov(M, j, k));
        }
        Sv = add(Sv, expOcf(q));
    }
    std::vector<long long> X;
    for (long long x : C(M, n))
        if (M[x][2] && !C(M, x).empty()) X.push_back(x);
    long long p;
    if (X.empty()) p = 1;
    else {
        auto cr = CR(M, X.back());
        p = M[cr.back()][2];
    }
    if (lt(sua(Sv).second, "p(p(0))") && p && k <= 0) Sv = add(Sv, "p(0)");
    return expOcf(Sv);
}

S ov(const Mat& M, long long n, long long k) {
    if (n == k) return "P(0)";
    if (M[n][2] == 0) return o(M, n, k);
    S Sv = "0";
    for (long long i : C(M, n)) {
        if (breakCond(i, k)) break;
        Sv = add(Sv, ov(M, i, k));
    }
    return "P(" + Sv + ")";
}

S v(const Mat& M, long long n, long long k) {
    if (M[n][1] == 0) return "0";
    if (M[n][2] == 0) {
        UResult u = U(M, n);
        S uu = u.tag ? mv(M, u.idx, n * (u.tag == 2 ? 1 : 0)) : S("p(0)");
        return add(v(M, P_func(M, 1, n), k), uu);
    }
    return add(v(M, P_func(M, 2, n), k), mv(M, n, k));
}

std::vector<long long> skipped(const Mat& M, long long n);

S o(const Mat& M, long long n, long long k) {
    S Sv = "0";
    auto sk = skipped(M, n);
    for (long long i : C(M, n)) {
        if (breakCond(i, k)) break;
        if (std::find(sk.begin(), sk.end(), i) != sk.end()) continue;
        Sv = add(Sv, o(M, i, k));
    }
    return "p(" + add(mulOcf("P(0)", v(M, n, k)), Sv) + ")";
}

std::vector<long long> skipped(const Mat& M, long long n) {
    std::vector<long long> Sv;
    std::vector<long long> u(M.size(), -2); // -2 = null
    for (size_t x = 0; x < M.size(); x++) {
        UResult r = U(M, (long long)x);
        u[x] = (r.tag == 1) ? r.idx : -2;
    }
    for (long long i : C(M, n)) {
        auto sub = skipped(M, i);
        Sv.insert(Sv.end(), sub.begin(), sub.end());
        if (M[i][2] && M[n][2]) { Sv.push_back(i); continue; }
        bool uHas = std::find(u.begin(), u.end(), i) != u.end();
        if (uHas) {
            auto c = C(M, i);
            if (!c.empty()) {
                long long j = c.back();
                if (eqVec(M[j], Col{ M[i][0] + 1, M[i][1], 1 })) { Sv.push_back(i); }
                else if (j - 1 >= 0 && U(M, j - 1).tag == 2 && U(M, j - 1).idx == i &&
                         eqVec(M[j], Col{ M[i][0] + 1, 0, 0 }) && C(M, j).empty()) { Sv.push_back(i); }
            } else { Sv.push_back(i); continue; }
        }
        UResult up = (i - 1 >= 0) ? U(M, i - 1) : UResult{ 0, -1 };
        if (eqVec(M[i], Col{ M[n][0] + 1, 0, 0 }) && up.tag == 2 && up.idx == n && C(M, i).empty()) {
            Sv.push_back(i);
            continue;
        }
    }
    return Sv;
}

S ttc(const S& a, const S& b) {
    if (a == "0") return "0";
    S rest = firstTerm(a).second;
    S t1 = firstTerm(a).first;
    if (ttc(rest, b) == "0" && lt(t1, "p(" + b + ")")) return "0";
    return add(t1, ttc(rest, b));
}

S sp(const S& a, const S& b, const S& c) {
    if (c == "0") return "p(" + add(a, b) + ")";
    S c1 = firstTerm(c).second;
    S c01 = firstTerm(c).first;
    if (lt(b, sua(arg(c)).second) && gt(c, "p(" + a + ")")) {
        S t = ttc(sua(arg(c)).second, add(sua(arg(c)).first, "P(0)"));
        return sp(a, add(t, sub(c01, "p(" + add(sua(arg(c)).first, t) + ")")), c1);
    }
    return sp(a, add(b, c01), c1);
}

S sf(const S& a) {
    if (a == "0") return "0";
    if (a[0] == 'P') return add("P(" + sf(arg(a)) + ")", sf(firstTerm(a).second));
    SS s = sua(a);
    return add(sp(sf(s.first), "0", sf(s.second)), sf(firstTerm(a).second));
}

S Conv_BMS_OCF(const Mat& matrix) {
    Mat M = processMatrix(matrix, 3);
    S Sv = "0";
    for (size_t i = 0; i < M.size(); i++) {
        if (M[i].size() >= 3 && M[i][0] == 0 && M[i][1] == 0 && M[i][2] == 0)
            Sv = add(Sv, o(M, (long long)i, -1));
    }
    return displayOCF(sf(Sv));
}

} // namespace ocf

// ---------- classify ----------
std::string classifyMat(const Mat& M, const B& self) {
    if (M.empty()) return "#808080";
    long long j = -1;
    for (size_t i = 0; i < M.size(); i++) if (M[i].empty() || M[i][0] == 0) j = (long long)i;
    if (j != 0) {
        if (j == (long long)M.size() - 1) return "#A00000";
        return "#ffA000";
    }
    if (M.size() == 1) return "#a00000";

    long long j2 = -1;
    for (size_t i = 0; i < M.size(); i++) if (!M[i].empty() && M[i][0] == 1) j2 = (long long)i;
    Mat N(M.begin() + std::max(0LL, j2), M.end());

    if (cmpMat(N, Mat{ { 1, 1, 1 } }) >= 0) return "#3f3f3f";
    if (cmpMat(N, Mat{ { 1, 1 }, { 2, 2 } }) >= 0) return "#000fff";
    if (cmpMat(N, Mat{ { 1, 1 }, { 2, 1 }, { 3, 1 } }) >= 0) return "#f00fff";
    if (cmpMat(N, Mat{ { 1, 1 }, { 2, 1 } }) >= 0) return "#00FFF0";
    if (cmpMat(N, Mat{ { 1, 1 } }) >= 0) return "#00FF00";
    if (!M.back().empty() && M.back()[0] == (int)M.size() - 1) return "#ffffff";
    return "#ffff00";
    (void)self;
}

class BmsNotation : public Notation {
public:
    std::string title() const override { return "BMS transfinite number line"; }

    Ord zero() const override { return mkB(); }
    Ord limit() const override { B b = mkB(); b->isLimit = true; return b; }

    int cmp(const Ord& a, const Ord& b) const override { return cmpB(castB(a), castB(b)); }

    bool isSuccessor(const Ord& a) const override {
        B x = castB(a);
        if (x->isLimit) return false;
        if (x->m.empty()) return true;
        const Col& last = x->m.back();
        for (int v : last) if (v != 0) return false;
        return true;
    }

    Ord fs(const Ord& a, long long FSterm) const override {
        B x = castB(a);
        if (x->isLimit) {
            B r = mkB();
            r->m.push_back(Col((size_t)FSterm + 1, 0));
            r->m.push_back(Col((size_t)FSterm + 1, 1));
            return r;
        }
        const Mat& m = x->m;
        if (m.empty()) return mkB();

        std::map<std::pair<long long, long long>, long long> parentCache;
        std::map<std::tuple<long long, long long, long long>, bool> ascCache;

        std::function<long long(long long, long long)> parent = [&](long long px, long long py) -> long long {
            auto key = std::make_pair(px, py);
            auto it = parentCache.find(key);
            if (it != parentCache.end()) return it->second;
            long long p = px;
            while ((p = py ? parent(p, py - 1) : p - 1) >= 0) {
                if (m[p][py] < m[px][py]) break;
            }
            parentCache[key] = p;
            return p;
        };
        std::function<bool(long long, long long, long long)> ascending =
            [&](long long r, long long px, long long py) -> bool {
            auto key = std::make_tuple(r, px, py);
            auto it = ascCache.find(key);
            if (it != ascCache.end()) return it->second;
            bool v = r <= px && (r == px || ascending(r, parent(px, py), py));
            ascCache[key] = v;
            return v;
        };

        long long endcol = (long long)m.size() - 1;
        B r = mkB();
        for (long long i = 0; i < endcol; i++) r->m.push_back(m[i]);

        const Col& child = m[endcol];
        long long ymax = (long long)child.size() - 1;
        long long LNZ = -1;
        for (long long i = ymax; i >= 0; --i)
            if (child[i] > 0) { LNZ = i; break; }
        if (LNZ < 0) return r;

        long long BR = parent(endcol, LNZ);
        if (BR < 0) return r; // defensive
        const Col& BRcolumn = m[BR];

        Col offset(child.size(), 0);
        for (size_t y = 0; y < child.size(); y++) {
            int bv = (y < BRcolumn.size()) ? BRcolumn[y] : 0;
            offset[y] = ((long long)y < LNZ) ? child[y] - bv : 0;
        }

        std::vector<Col> offsetAsc((size_t)endcol);
        for (long long xi = BR; xi < endcol; xi++) {
            Col row((size_t)ymax + 1, 0);
            for (long long y = 0; y <= ymax; y++)
                row[y] = ascending(BR, xi, y) ? offset[y] : 0;
            offsetAsc[xi] = row;
        }

        for (long long n = 1; n <= FSterm; n++) {
            for (long long col = BR; col < endcol; col++) {
                Col nc(m[col].size(), 0);
                for (size_t y = 0; y < m[col].size(); y++) {
                    int off = (y < offsetAsc[col].size()) ? offsetAsc[col][y] : 0;
                    nc[y] = m[col][y] + off * (int)n;
                }
                r->m.push_back(nc);
            }
        }

        if (ymax > 0) {
            bool allZero = true;
            for (auto& column : r->m) {
                if ((long long)column.size() <= ymax || column[ymax] != 0) { allZero = false; break; }
            }
            if (allZero)
                for (auto& column : r->m) column.resize((size_t)ymax);
        }
        return r;
    }

    std::vector<std::string> displayNames() const override {
        return { "BMS", "DBMS", "AMS", "PMS", "Vulcaniz", "0Y", "2 shifted-OCF" };
    }

    std::string display(const Ord& a, const std::string& mode) const override {
        B x = castB(a);
        if (x->m.empty() && !x->isLimit) return "0";
        if (x->isLimit) return "Lim(BMS)";
        try {
            Mat threshold{ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 2, 0 } };
            if (mode == "2 shifted-OCF" && cmpMat(x->m, threshold) < 0)
                return ocf::Conv_BMS_OCF(x->m);
            if (mode == "BMS") return matToStr(x->m);
            if (mode == "DBMS") return matToStr(trimTrailingZeros(bmsToDbms(x->m)));
            if (mode == "PMS") return matToStr(BMStoPMS(x->m));
            if (mode == "AMS") return matToStr(PMStoAMS(BMStoPMS(x->m)));
            if (mode == "Vulcaniz") return PMStoVZ(PMStoAMS(BMStoPMS(x->m)));
            if (mode == "0Y") return BMS_to_0Y(x->m);
        } catch (...) {
            // fall through to plain BMS format
        }
        return matToStr(x->m);
    }

    std::string classifyOrdinal(const Ord& a) const override {
        B x = castB(a);
        if (x->isLimit) return "#808080";
        return classifyMat(x->m, x);
    }

    bool hasParser() const override { return true; }

    Ord parse(const std::string& str) const override {
        Mat matrix;
        size_t i = 0;
        while (i < str.size()) {
            if (str[i] == '(') {
                size_t j = str.find(')', i);
                if (j == std::string::npos) break;
                std::string inner = str.substr(i + 1, j - i - 1);
                // inner has no parens (regex [^()]*)
                Col col;
                std::stringstream ss(inner);
                std::string tok;
                if (inner.empty()) {
                    col.push_back(0); // Number("") === 0
                } else {
                    while (std::getline(ss, tok, ',')) col.push_back(atoi(tok.c_str()));
                }
                matrix.push_back(col);
                i = j + 1;
            } else {
                i++;
            }
        }
        B r = mkB();
        r->m = processMatrix(matrix, 0);
        return r;
    }

    std::vector<std::pair<std::string, std::string>> ordinalTypes() const override {
        return {
            { "Zero", "#808080" },
            { "Successor Ordinal", "#a00000" },
            { "Limit Ordinal", "#ffA000" },
            { "Power of \xCF\x89", "#ffff00" },
            { "Tower of \xCF\x89", "#ffffff" },
            { "\xCE\xB5 Ordinal", "#00FF00" },
            { "Veblen Ordinal", "#00FFF0" },
            { "Feferman\xE2\x80\x93Sch\xC3\xBctte Ordinal", "#ff00ff" },
            { "Bachmann\xE2\x80\x93Howard Ordinal", "#000fff" },
            { "Buchholz Ordinal", "#404040" },
        };
    }

    std::vector<std::pair<std::string, Ord>> aliases() const override {
        auto mkOrd = [](Mat m) { B b = mkB(); b->m = m; return std::static_pointer_cast<void>(b); };
        B lim = mkB(); lim->isLimit = true;

        // "First 67 Ordinal" = fs([[0],[1]], 66)
        B base = mkB();
        base->m = { { 0 }, { 1 } };
        Ord first67 = fs(std::static_pointer_cast<void>(base), 66);

        return {
            { "First 67 Ordinal", first67 },
            { "First Transfinite Ordinal", mkOrd({ { 0 }, { 1 } }) },
            { "Small Cantor Ordinal", mkOrd({ { 0, 0 }, { 1, 1 } }) },
            { "Veblen Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 0 } }) },
            { "Feferman\xE2\x80\x93Sch\xC3\xBctte Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 } }) },
            { "First \xCE\x93 fixed point", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 2, 1 } }) },
            { "Ackermann Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 3, 1 } }) },
            { "Small Veblen Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 0 } }) },
            { "Large Veblen Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 4, 1 } }) },
            { "Bachmann\xE2\x80\x93Howard Ordinal", mkOrd({ { 0, 0 }, { 1, 1 }, { 2, 2 } }) },
            { "Buchholz's Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 } }) },
            { "Takeuti-Feferman-Buchholz Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 0 }, { 3, 2, 0 } }) },
            { "Bird's Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 0 } }) },
            { "Extended Buchholz Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 0 }, { 2, 0, 0 } }) },
            { "Multivariable Buchholz Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 1 }, { 3, 0, 0 } }) },
            { "Transfinitary Buchholz Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 1 }, { 3, 1, 0 }, { 2, 0, 0 } }) },
            { "Dimensional Buchholz Ordinal / Small Rathjen Ordinal / PTO(KPM)", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 1 }, { 3, 1, 0 }, { 4, 2, 0 } }) },
            { "Large Rathjen Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 1, 1 }, { 3, 1, 1 }, { 4, 1, 0 }, { 5, 2, 0 } }) },
            { "Small Stergent Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 2, 0 } }) },
            { "Small Dropping Ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 2, 1 }, { 3, 0, 0 } }) },
            { "2nd Back Gear ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 2, 1 }, { 3, 3, 0 } }) },
            { "Omega Back ordinal / Small Bashicu ordinal", mkOrd({ { 0, 0, 0 }, { 1, 1, 1 }, { 2, 2, 2 } }) },
            { "Lim(TSS)", mkOrd({ { 0, 0, 0, 0 }, { 1, 1, 1, 1 } }) },
            { "Lim(QSS)", mkOrd({ { 0, 0, 0, 0, 0 }, { 1, 1, 1, 1, 1 } }) },
            { "Lim(BMS) / \xCF\x89-Y(1,3)", std::static_pointer_cast<void>(lim) },
        };
    }
};

} // namespace

std::shared_ptr<Notation> createBmsNotation() { return std::make_shared<BmsNotation>(); }
