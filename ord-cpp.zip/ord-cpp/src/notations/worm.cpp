// Worm (Ackermann Worm) notation — port of Libs/Worm.js
// Ordinal representation: vector of [exp, coef] Cantor-normal-form terms.
#include "notation.h"
#include <algorithm>
#include <cctype>
#include <map>
#include <sstream>

namespace {

struct WormOrd {
    bool isLimit = false;
    std::vector<std::pair<int, int>> terms; // [exp, coef], exp descending
};

using W = std::shared_ptr<WormOrd>;

W mk() { return std::make_shared<WormOrd>(); }
W cast(const Ord& o) { return std::static_pointer_cast<WormOrd>(o); }

std::string pretty(const W& ord) {
    if (ord->isLimit) return "Limit";
    if (ord->terms.empty()) return "0";
    std::string out;
    for (size_t i = 0; i < ord->terms.size(); i++) {
        int exp = ord->terms[i].first, coef = ord->terms[i].second;
        if (i) out += "+";
        if (exp == 0) { out += std::to_string(coef); continue; }
        std::string base = (exp == 1) ? "&omega;" : ("&omega;<sup>" + std::to_string(exp) + "</sup>");
        out += coef > 1 ? (base + "&middot;" + std::to_string(coef)) : base;
    }
    return out;
}

std::string raw(const W& ord) {
    if (ord->isLimit) return "\"Limit\"";
    std::string out = "[";
    for (size_t i = 0; i < ord->terms.size(); i++) {
        if (i) out += ",";
        out += "[" + std::to_string(ord->terms[i].first) + "," + std::to_string(ord->terms[i].second) + "]";
    }
    return out + "]";
}

class WormNotation : public Notation {
public:
    std::string title() const override { return "Worm transfinite number line"; }

    Ord zero() const override { return mk(); }
    Ord limit() const override { auto w = mk(); w->isLimit = true; return w; }

    int cmp(const Ord& a, const Ord& b) const override {
        W x = cast(a), y = cast(b);
        if (x->isLimit && y->isLimit) return 0;
        if (x->isLimit) return 1;
        if (y->isLimit) return -1;
        size_t n = std::min(x->terms.size(), y->terms.size());
        for (size_t i = 0; i < n; i++) {
            if (x->terms[i].first != y->terms[i].first) return x->terms[i].first < y->terms[i].first ? -1 : 1;
            if (x->terms[i].second != y->terms[i].second) return x->terms[i].second < y->terms[i].second ? -1 : 1;
        }
        if (x->terms.size() < y->terms.size()) return -1;
        if (x->terms.size() > y->terms.size()) return 1;
        return 0;
    }

    bool isSuccessor(const Ord& a) const override {
        W x = cast(a);
        return !x->isLimit && !x->terms.empty() && x->terms.back().first == 0;
    }

    Ord fs(const Ord& a, long long n) const override {
        W x = cast(a);
        if (x->isLimit) {
            W r = mk();
            r->terms.push_back({ (int)n, 1 });
            return r;
        }
        if (x->terms.empty()) return mk();

        W res = mk();
        res->terms = x->terms;
        auto last = res->terms.back();
        if (last.second > 1) res->terms.back().second--;
        else res->terms.pop_back();

        if (last.first > 0 && n > 0) {
            int newExp = last.first - 1;
            if (!res->terms.empty() && res->terms.back().first == newExp)
                res->terms.back().second += (int)n;
            else
                res->terms.push_back({ newExp, (int)n });
        }
        return res;
    }

    std::vector<std::string> displayNames() const override { return { "raw", "pretty" }; }

    std::string display(const Ord& a, const std::string& mode) const override {
        W x = cast(a);
        if (x->isLimit) return "Limit";
        if (x->terms.empty()) return "0";
        if (mode == "raw") return raw(x);
        return pretty(x);
    }

    std::string classifyOrdinal(const Ord& a) const override {
        W x = cast(a);
        if (x->isLimit) return "#ffffff";
        if (x->terms.empty()) return "#808080";
        if (isSuccessor(a)) return "#a00000";
        if (x->terms.size() == 1 && x->terms[0].second == 1 && x->terms[0].first > 0) return "#ffff00";
        return "#ffa000";
    }

    bool hasParser() const override { return true; }

    Ord parse(const std::string& str) const override {
        std::string s = str;
        // trim
        auto trimEnd = s.find_last_not_of(" \t\r\n");
        s = (trimEnd == std::string::npos) ? "" : s.substr(0, trimEnd + 1);
        auto trimStart = s.find_first_not_of(" \t\r\n");
        s = (trimStart == std::string::npos) ? "" : s.substr(trimStart);

        W zero = mk();
        if (s.empty() || s == "0") return zero;
        std::string lower = s;
        for (auto& c : lower) c = (char)tolower((unsigned char)c);
        if (lower == "limit" || s == "\xCF\x89^\xCF\x89" /* ω^ω */ || lower == "w^w") {
            W r = mk(); r->isLimit = true; return r;
        }

        std::map<int, int> terms;
        auto addTerm = [&](int exp, int coef) {
            if (coef <= 0) return;
            terms[exp] += coef;
        };

        // 1. Nested pair notation e.g. [[5,1],[3,2]] or [(5,1),(3,2)]
        std::vector<std::pair<int, int>> pairs;
        for (size_t i = 0; i + 1 < s.size(); i++) {
            if (s[i] == '(' || s[i] == '[' || s[i] == '{') {
                size_t j = i + 1;
                while (j < s.size() && isspace((unsigned char)s[j])) j++;
                size_t n1 = j;
                while (j < s.size() && isdigit((unsigned char)s[j])) j++;
                if (j == n1) continue;
                int e = atoi(s.substr(n1, j - n1).c_str());
                while (j < s.size() && isspace((unsigned char)s[j])) j++;
                if (j >= s.size() || s[j] != ',') continue;
                j++;
                while (j < s.size() && isspace((unsigned char)s[j])) j++;
                size_t n2 = j;
                while (j < s.size() && isdigit((unsigned char)s[j])) j++;
                if (j == n2) continue;
                int c = atoi(s.substr(n2, j - n2).c_str());
                while (j < s.size() && isspace((unsigned char)s[j])) j++;
                if (j < s.size() && (s[j] == ')' || s[j] == ']' || s[j] == '}')) {
                    pairs.push_back({ e, c });
                    i = j;
                }
            }
        }

        if (!pairs.empty()) {
            for (auto& p : pairs) addTerm(p.first, p.second);
        } else if (s.find('(') != std::string::npos || s.find('[') != std::string::npos || s.find(',') != std::string::npos) {
            // 2. Flat exponent array notation e.g. (5, 3, 3, 1, 0)
            std::string cleaned;
            for (char c : s) if (c != '(' && c != ')' && c != '[' && c != ']' && c != '{' && c != '}') cleaned += c;
            std::stringstream ss(cleaned);
            std::string tok;
            while (std::getline(ss, tok, ',')) {
                auto t = tok.find_first_not_of(" \t");
                if (t == std::string::npos) continue;
                auto e2 = tok.find_last_not_of(" \t");
                tok = tok.substr(t, e2 - t + 1);
                bool ok = !tok.empty();
                for (char c : tok) if (!isdigit((unsigned char)c) && c != '-') ok = false;
                if (ok) addTerm(atoi(tok.c_str()), 1);
            }
        } else {
            // 3. Transfinite text notation e.g. "w^2*3 + w + 5"
            std::string t = lower;
            // replace ω (UTF-8 CE BF) with w
            std::string cleaned;
            for (size_t i = 0; i < t.size(); i++) {
                if (i + 1 < t.size() && (unsigned char)t[i] == 0xCE && (unsigned char)t[i + 1] == 0xBF) { cleaned += 'w'; i++; }
                else cleaned += t[i];
            }
            t = cleaned;
            for (auto& c : t) if (c == '*') c = '*';
            std::stringstream ss(t);
            std::string term;
            while (std::getline(ss, term, '+')) {
                auto a = term.find_first_not_of(" \t");
                if (a == std::string::npos) continue;
                auto b = term.find_last_not_of(" \t");
                term = term.substr(a, b - a + 1);
                if (term.empty()) continue;

                int exp = 0, coef = 1;
                if (term.find('w') != std::string::npos) {
                    size_t caretp = term.find('^');
                    if (caretp != std::string::npos) {
                        size_t st = caretp + 1;
                        size_t en = term.find('*', st);
                        exp = atoi(term.substr(st, (en == std::string::npos ? term.size() : en) - st).c_str());
                    } else {
                        exp = 1;
                    }
                    size_t star = term.find('*');
                    if (star != std::string::npos) coef = atoi(term.substr(star + 1).c_str());
                } else {
                    exp = 0;
                    coef = atoi(term.c_str());
                }
                addTerm(exp, coef);
            }
        }

        W r = mk();
        for (auto it = terms.rbegin(); it != terms.rend(); ++it)
            r->terms.push_back({ it->first, it->second });
        return r;
    }

    std::vector<std::pair<std::string, std::string>> ordinalTypes() const override {
        return {
            { "Zero", "#808080" },
            { "Successor Ordinal", "#a00000" },
            { "Limit Ordinal", "#ffa000" },
            { "Power of \xCF\x89", "#ffff00" },
        };
    }

    std::vector<std::pair<std::string, Ord>> aliases() const override {
        auto mkOrd = [](std::vector<std::pair<int, int>> terms) {
            W w = mk(); w->terms = terms; return std::static_pointer_cast<void>(w);
        };
        W lim = mk(); lim->isLimit = true;
        return {
            { "0", mkOrd({}) },
            { "1", mkOrd({ { 0, 1 } }) },
            { "\xCF\x89", mkOrd({ { 1, 1 } }) },
            { "\xCF\x89\xC2\xB2", mkOrd({ { 2, 1 } }) },
            { "\xCF\x89^\xCF\x89", std::static_pointer_cast<void>(lim) },
        };
    }

    std::vector<ModeSpec> initialModes() const override { return { { 1, "both" } }; }
};

} // namespace

std::shared_ptr<Notation> createWormNotation() { return std::make_shared<WormNotation>(); }
