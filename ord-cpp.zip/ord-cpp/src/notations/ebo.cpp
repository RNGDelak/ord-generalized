// Extended Buchholz OCF — port of Libs/EBO.js
// Ordinal representation: array of terms { c: uint32, f: Ord, x: Ord } meaning
// sum of psi_f(x) * c; c == 0 is the apply-variable; c == 0xFFFFFFFF is I.
#include "notation.h"
#include <algorithm>
#include <cstdint>
#include <sstream>

namespace {

struct EboOrd;
using EO = std::shared_ptr<EboOrd>;

struct EboTerm {
    uint32_t c = 0;
    EO f, x;
};

struct EboOrd {
    bool isLimit = false;
    std::vector<EboTerm> terms;
};

using E = std::shared_ptr<EboOrd>;

E mkE() { return std::make_shared<EboOrd>(); }
E castE(const Ord& o) { return std::static_pointer_cast<EboOrd>(o); }

const uint32_t INF_CARD = 0xFFFFFFFFu;

bool Ord_iszero(const EO& o) { return !o || o->terms.empty(); }

EO Ord_zero() { return mkE(); }

EO Ord_copy(const EO& o) {
    // Deep-copy term structs; sub-ords are immutable and can be shared.
    E r = mkE();
    if (!o) return r;
    r->isLimit = o->isLimit;
    r->terms = o->terms;
    return r;
}

EO Ord_number(uint32_t n) {
    E r = mkE();
    if (n == 0) return r;
    r->terms.push_back({ n, Ord_zero(), Ord_zero() });
    return r;
}

EO Ord_psi(EO a, EO b, uint32_t coeff = 1) {
    if (coeff == 0) return Ord_zero();
    E r = mkE();
    r->terms.push_back({ coeff, a ? a : Ord_zero(), b ? b : Ord_zero() });
    return r;
}

EO Ord_psi0(EO b, uint32_t coeff = 1) { return Ord_psi(Ord_zero(), b, coeff); }

EO Ord_inaccessible() {
    E r = mkE();
    r->terms.push_back({ INF_CARD, Ord_number(INF_CARD), Ord_zero() });
    return r;
}

bool Ord_isnumber(const EO& o, uint32_t n) {
    if (Ord_iszero(o)) return n == 0;
    if (o->terms.size() == 1 && Ord_iszero(o->terms[0].f) && Ord_iszero(o->terms[0].x))
        return n == o->terms[0].c;
    return false;
}

bool Ord_isfinite(const EO& o) {
    return Ord_iszero(o) || (o->terms.size() == 1 && Ord_iszero(o->terms[0].f) && Ord_iszero(o->terms[0].x));
}

bool Ord_islimit(const EO& o) {
    if (Ord_iszero(o)) return false;
    const EboTerm& t = o->terms.back();
    return !Ord_iszero(t.f) || !Ord_iszero(t.x);
}

bool Ord_ismonic(const EO& o) { return o && o->terms.size() == 1 && o->terms[0].c == 1; }

bool Ord_isomegatower(const EO& o) {
    if (Ord_iszero(o)) return true;
    return o->terms.size() == 1 && o->terms[0].c == 1 && Ord_iszero(o->terms[0].f) && Ord_isomegatower(o->terms[0].x);
}

EO Ord_lasttermcardinality(const EO& o) {
    if (Ord_iszero(o)) return Ord_zero();
    return o->terms.back().f;
}

EO Ord_someterms(const EO& o, size_t n0, size_t n1) {
    E r = mkE();
    for (size_t i = n0; i < n1 && i < o->terms.size(); i++) r->terms.push_back(o->terms[i]);
    return r;
}

EO Ord_firstterms(const EO& o) { return Ord_someterms(o, 0, o->terms.size() - 1); }

EO Ord_lastterm(const EO& o) {
    const EboTerm& t = o->terms.back();
    return Ord_psi(t.f, t.x, t.c);
}

EO Ord_successor(const EO& o) {
    E r = Ord_copy(o);
    if (!r->terms.empty() && Ord_iszero(r->terms.back().f) && Ord_iszero(r->terms.back().x)) {
        r->terms.back().c++;
    } else {
        r->terms.push_back({ 1, Ord_zero(), Ord_zero() });
    }
    return r;
}

EO Ord_predecessor(const EO& o) {
    if (Ord_iszero(o)) return Ord_zero();
    if (Ord_islimit(o)) return Ord_copy(o);
    E r = Ord_copy(o);
    if (r->terms.back().c > 1) { r->terms.back().c--; return r; }
    return Ord_firstterms(o);
}

class EboNotation;

struct EboCore {
    // cmp needs recursion; shared helpers
    static int cmpEO(const EO& a, const EO& b) {
        bool alim = a && a->isLimit, blim = b && b->isLimit;
        if (alim && blim) return 0;
        if (alim) return 1;
        if (blim) return -1;
        if (Ord_iszero(a) && Ord_iszero(b)) return 0;
        if (Ord_iszero(a)) return -1;
        if (Ord_iszero(b)) return 1;
        for (size_t n = 0;; n++) {
            if (n >= a->terms.size() && n < b->terms.size()) return -1;
            if (n < a->terms.size() && n >= b->terms.size()) return 1;
            if (n >= a->terms.size() && n >= b->terms.size()) return 0;
            int i = cmpEO(a->terms[n].f, b->terms[n].f);
            if (i != 0) return i;
            i = cmpEO(a->terms[n].x, b->terms[n].x);
            if (i != 0) return i;
            if (a->terms[n].c < b->terms[n].c) return -1;
            if (a->terms[n].c > b->terms[n].c) return 1;
        }
    }
};

EO Ord_add(const EO& a, const EO& b) {
    E r = mkE();
    if (a) for (auto& t : a->terms) r->terms.push_back(t);
    if (b) for (auto& t : b->terms) r->terms.push_back(t);
    return r;
}

bool Ord_equal(const EO& a, const EO& b) { return EboCore::cmpEO(a, b) == 0; }
bool Ord_lt(const EO& a, const EO& b) { return EboCore::cmpEO(a, b) < 0; }
bool Ord_gt(const EO& a, const EO& b) { return EboCore::cmpEO(a, b) > 0; }
bool Ord_lte(const EO& a, const EO& b) { return EboCore::cmpEO(a, b) <= 0; }

EO Ord_addproper(const EO& a, const EO& b) {
    if (Ord_iszero(a)) return Ord_copy(b);
    if (Ord_iszero(b)) return Ord_copy(a);
    size_t am;
    int eq = 0;
    for (am = a->terms.size(); am > 0; am--) {
        int j = EboCore::cmpEO(a->terms[am - 1].f, b->terms[0].f);
        if (j > 0) break;
        if (j == 0) {
            int i = EboCore::cmpEO(a->terms[am - 1].x, b->terms[0].x);
            if (i > 0) break;
            if (i == 0) { eq = 1; break; }
        }
    }
    E ret = mkE();
    size_t keep = eq ? am - 1 : am;
    for (size_t k = 0; k < keep; k++) ret->terms.push_back(a->terms[k]);
    if (eq) {
        ret->terms.push_back({ (uint32_t)(a->terms[am - 1].c + b->terms[0].c), b->terms[0].f, b->terms[0].x });
        for (size_t k = 1; k < b->terms.size(); k++) ret->terms.push_back(b->terms[k]);
    } else {
        for (size_t k = 0; k < b->terms.size(); k++) ret->terms.push_back(b->terms[k]);
    }
    return ret;
}

EboTerm OrdTerm_simplifyfixedpoint(const EboTerm& t) {
    if (!Ord_ismonic(t.x)) return t;
    EboTerm u{ t.c, t.x->terms[0].f, t.x->terms[0].x };
    if (!Ord_equal(t.f, u.f)) return t;
    if (Ord_gt(Ord_lasttermcardinality(u.x), t.f)) return u;
    return t;
}

EO Ord_apply(const EO& f, const EO& x) {
    E ret = mkE();
    if (!f) return ret;
    for (auto& t : f->terms) {
        if (t.c) {
            ret->terms.push_back({ t.c, Ord_apply(t.f, x), Ord_apply(t.x, x) });
        } else {
            if (x) for (auto& xt : x->terms) ret->terms.push_back(xt);
        }
    }
    return ret;
}

EO Ord_makeimpredfn(const EO& o) {
    const EboTerm& l = o->terms.back();
    size_t extra = l.c > 1 ? 1 : 0;
    E ret = mkE();
    ret->terms.resize(o->terms.size() + extra);
    for (long long n = (long long)ret->terms.size() - 2; n >= 0; n--) {
        ret->terms[n] = o->terms[n];
    }
    if (l.c > 1) ret->terms[ret->terms.size() - 2].c--;
    EboTerm& last = ret->terms.back();
    if (Ord_islimit(l.x)) {
        last.c = 1;
        last.f = l.f;
        last.x = Ord_makeimpredfn(l.x);
    } else if (Ord_iszero(l.x)) {
        if (Ord_islimit(l.f)) {
            last.c = 1;
            last.f = Ord_makeimpredfn(l.f);
            last.x = l.x;
        } else {
            last.c = 0;
            last.f = Ord_zero();
            last.x = Ord_zero();
        }
    }
    return ret;
}

class EboNotation : public Notation {
public:
    std::string title() const override { return "Extended Buchholz OCF transfinite number line"; }

    Ord zero() const override { return mkE(); }
    Ord limit() const override { E e = mkE(); e->isLimit = true; return e; }

    int cmp(const Ord& a, const Ord& b) const override { return EboCore::cmpEO(castE(a), castE(b)); }

    bool isSuccessor(const Ord& a) const override {
        E x = castE(a);
        if (x->isLimit) return false;
        if (Ord_iszero(x)) return false;
        return !Ord_islimit(x);
    }

    Ord fs(const Ord& a, long long n) const override {
        E x = castE(a);
        EO ord = x->isLimit ? Ord_psi0(Ord_inaccessible()) : x;
        if (Ord_iszero(ord) || !Ord_islimit(ord)) return a;
        cs.clear();
        std::vector<EO> seq = Ord_fundseq(ord, n + 1);
        return seq[(size_t)n];
    }

    std::vector<std::string> displayNames() const override { return { "pretty", "raw" }; }

    std::string display(const Ord& a, const std::string& mode) const override {
        E x = castE(a);
        if (x->isLimit) return "Limit";
        if (Ord_iszero(x)) return "0";
        if (mode == "raw") return rawJson(x);
        return Ord_printbf(x);
    }

    std::string classifyOrdinal(const Ord& a) const override {
        E o = castE(a);
        if (o->isLimit) return "#404040";
        if (Ord_iszero(o)) return "#808080";
        if (!Ord_islimit(o)) return "#A00000";

        if (Ord_ismonic(o)) {
            EO arg = o->terms[0].x;
            if (Ord_iszero(arg)) {
                if (Ord_isomegatower(o)) return "#FFFFFF";
                return "#FFFF00";
            }
            const EboTerm& lastTerm = arg->terms.back();
            EO lastf = lastTerm.f;
            EO lastx = lastTerm.x;
            if (Ord_iszero(lastf)) {
                if (Ord_isomegatower(o)) return "#FFFFFF";
                return "#FFFF00";
            } else if (Ord_isnumber(lastf, 1)) {
                EO last = Ord_psi(lastf, lastx);
                EO phi1 = Ord_psi(Ord_number(1), Ord_zero());
                EO phi11 = Ord_psi(Ord_number(1), phi1);
                EO phi111 = Ord_psi(Ord_number(1), phi11);
                if (Ord_lt(last, phi11)) return "#00FF00";
                if (Ord_lt(last, phi111)) return "#00FFFF";
                return "#FF00FF";
            } else if (Ord_isfinite(lastf)) {
                return "#0000FF";
            } else {
                return "#404040";
            }
        }
        return "#FFA000";
    }

    std::vector<std::pair<std::string, std::string>> ordinalTypes() const override {
        return {
            { "Zero", "#808080" },
            { "Successor Ordinal", "#A00000" },
            { "Limit Ordinal", "#FFA000" },
            { "Power of \xCF\x89", "#FFFF00" },
            { "Tower of \xCF\x89", "#FFFFFF" },
            { "\xCE\xB5 Ordinal", "#00FF00" },
            { "Veblen Ordinal", "#00FFFF" },
            { "Feferman\xE2\x80\x93Sch\xC3\xBctte Ordinal", "#FF00FF" },
            { "Bachmann\xE2\x80\x93Howard Ordinal", "#0000FF" },
            { "Buchholz Ordinal", "#404040" },
        };
    }

    std::vector<std::pair<std::string, Ord>> aliases() const override {
        E lim = mkE(); lim->isLimit = true;
        return { { "Extended Buchholz Ordinal", lim } };
    }

    // NOTE: EBO.js defines parse() but does not export it, so the ordinal
    // finder stays disabled for this notation, same as the JS app.
    bool hasParser() const override { return false; }

private:
    mutable std::vector<EO> cs; // Ord_fundseq context stack (JS module-level `cs`)

    std::vector<EO> Ord_fundseq(const EO& o, long long m) const {
        std::vector<EO> seq;
        cs.push_back(o);

        if (!o->terms.empty() && o->terms[0].c == INF_CARD) {
            seq.resize((size_t)m);
            seq[0] = Ord_number(1);
            for (long long n = 1; n < m; n++) seq[n] = Ord_psi(seq[n - 1], Ord_zero());
            return seq;
        }
        if (o->terms.size() > 1) {
            EO first = Ord_firstterms(o), last = Ord_lastterm(o);
            seq = Ord_fundseq(last, m);
            for (long long n = 0; n < m; n++) seq[n] = Ord_add(first, seq[n]);
            return seq;
        }
        EO f = o->terms[0].f, x = o->terms[0].x;
        if (o->terms[0].c > 1) {
            EO monic = Ord_psi(f, x), rest = Ord_psi(f, x, o->terms[0].c - 1);
            seq = Ord_fundseq(monic, m);
            for (long long n = 0; n < m; n++) seq[n] = Ord_add(rest, seq[n]);
            return seq;
        }
        if (Ord_islimit(x)) {
            seq = Ord_fundseq(x, m);
            for (long long n = 0; n < m; n++) seq[n] = Ord_psi(f, seq[n]);
            return seq;
        } else if (Ord_iszero(x)) {
            if (Ord_islimit(f)) {
                seq = Ord_fundseq(f, m);
                for (long long n = 0; n < m; n++) seq[n] = Ord_psi(seq[n], Ord_zero());
                return seq;
            } else {
                long long caIndex = -1;
                for (long long n = (long long)cs.size() - 1; n >= 0; n--) {
                    if (Ord_ismonic(cs[n]) && Ord_lt(cs[n]->terms[0].f, f)) { caIndex = n; break; }
                }
                EO cf = Ord_makeimpredfn(cs[(size_t)caIndex + 1]);
                EO beta = Ord_predecessor(f);
                seq.resize((size_t)m);
                seq[0] = Ord_zero();
                for (long long n = 1; n < m; n++) {
                    EO ff = Ord_apply(cf, seq[n - 1]);
                    seq[n] = Ord_psi(beta, ff);
                }
                return seq;
            }
        } else {
            EO beta = Ord_predecessor(x);
            seq.resize((size_t)m);
            for (long long n = 0; n < m; n++) seq[n] = Ord_psi(f, beta, (uint32_t)n);
            return seq;
        }
    }

    static std::string rawJson(const EO& o) {
        if (!o || o->terms.empty()) return "[]";
        std::string s = "[";
        for (size_t i = 0; i < o->terms.size(); i++) {
            if (i) s += ",";
            s += "{\"c\":" + std::to_string(o->terms[i].c) +
                 ",\"f\":" + rawJson(o->terms[i].f) +
                 ",\"x\":" + rawJson(o->terms[i].x) + "}";
        }
        return s + "]";
    }

    std::string Ord_printbf(const EO& o) const {
        if (Ord_iszero(o)) return "0";
        std::string ret;
        for (size_t n = 0; n < o->terms.size(); n++) {
            uint32_t c = o->terms[n].c;
            EO f = o->terms[n].f;
            EO x = o->terms[n].x;
            if (n > 0) ret += "+";
            if (c == 0) { ret += "x"; continue; }
            if (c == INF_CARD) { ret += "I"; continue; }

            if (Ord_iszero(f) && Ord_iszero(x)) {
                ret += std::to_string(c);
                continue;
            }

            if (Ord_iszero(x) && !Ord_iszero(f)) {
                if (Ord_isnumber(f, 1)) ret += "&Omega;";
                else ret += "&Omega;<sub>" + Ord_printbf(f) + "</sub>";
            } else if (!Ord_iszero(x) && Ord_lte(Ord_lasttermcardinality(x), f)) {
                size_t cidx;
                for (cidx = 0; cidx < x->terms.size() && Ord_gt(x->terms[cidx].f, f); cidx++);
                EO pref, xbig;
                if (cidx == 0) {
                    pref = Ord_iszero(f) ? Ord_zero() : Ord_psi(f, Ord_zero());
                } else {
                    xbig = Ord_someterms(x, 0, cidx);
                    pref = Ord_psi(f, xbig);
                }
                EO xsmall = Ord_someterms(x, cidx, x->terms.size());
                EO sum = Ord_addproper(pref, xsmall);
                if (Ord_isnumber(sum, 1)) ret += "&omega;";
                else ret += "&omega;<sup>" + Ord_printbf(sum) + "</sup>";
            } else {
                bool done = false;
                EO fsOrd = Ord_successor(f);
                if (!x->terms.empty() && Ord_equal(x->terms.back().f, fsOrd)) {
                    EO omfs = Ord_psi(fsOrd, Ord_zero());
                    EO psifsfs = Ord_psi(fsOrd, omfs);
                    if (Ord_lt(x->terms.back().x, omfs)) {
                        size_t cidx;
                        for (cidx = x->terms.size() - 1;
                             cidx > 0 && Ord_equal(x->terms[cidx - 1].f, fsOrd) && Ord_lt(x->terms[cidx - 1].x, omfs);
                             cidx--);
                        EO pref, xbig;
                        if (cidx == 0) {
                            pref = Ord_iszero(f) ? Ord_zero() : Ord_psi(f, Ord_zero());
                        } else {
                            xbig = Ord_someterms(x, 0, cidx);
                            pref = Ord_psi(f, xbig);
                        }
                        EO xeps = Ord_someterms(x, cidx, x->terms.size());
                        for (size_t i = xeps->terms.size(); i-- > 0;) {
                            xeps->terms[i].f = Ord_zero();
                            xeps->terms[i] = OrdTerm_simplifyfixedpoint(xeps->terms[i]);
                        }
                        EO sum;
                        if (Ord_iszero(pref) && Ord_isfinite(xeps)) {
                            EO xepsp = Ord_predecessor(xeps);
                            sum = Ord_addproper(pref, xepsp);
                        } else {
                            sum = Ord_addproper(pref, xeps);
                        }
                        ret += "&epsilon;<sub>" + Ord_printbf(sum) + "</sub>";
                        done = true;
                    } else if (Ord_lt(x->terms.back().x, psifsfs)) {
                        EO lastx = x->terms.back().x;
                        long long nm = 0;
                        for (size_t i = lastx->terms.size(); i-- > 0;)
                            if (Ord_equal(lastx->terms[i].f, fsOrd)) nm++;
                        E nveb = mkE();
                        nveb->terms.resize((size_t)nm);
                        for (size_t i = 0, k = 0; i < lastx->terms.size(); i++)
                            if (Ord_equal(lastx->terms[i].f, fsOrd)) {
                                nveb->terms[k] = { lastx->terms[i].c, Ord_zero(), lastx->terms[i].x };
                                nveb->terms[k] = OrdTerm_simplifyfixedpoint(nveb->terms[k]);
                                k++;
                            }
                        if (Ord_isfinite(nveb) && !nveb->terms.empty()) nveb->terms[0].c++;
                        EO next = Ord_addproper(lastx, omfs);
                        size_t cidx;
                        for (cidx = x->terms.size() - 1;
                             cidx > 0 && Ord_equal(x->terms[cidx - 1].f, fsOrd) && Ord_lt(x->terms[cidx - 1].x, next);
                             cidx--);
                        EO pref, xbig;
                        if (cidx == 0) {
                            pref = Ord_iszero(f) ? Ord_zero() : Ord_psi(f, Ord_zero());
                        } else {
                            xbig = Ord_someterms(x, 0, cidx);
                            pref = Ord_psi(f, xbig);
                        }
                        std::vector<EboTerm> xveb;
                        for (size_t i = cidx; i < x->terms.size(); i++) {
                            EboTerm termI{ x->terms[i].c, Ord_zero(), Ord_zero() };
                            size_t j = x->terms[i].x->terms.size();
                            while (j > 0 && Ord_iszero(x->terms[i].x->terms[j - 1].f)) j--;
                            EO sub = Ord_someterms(x->terms[i].x, j, x->terms[i].x->terms.size());
                            termI.x = sub;
                            xveb.push_back(OrdTerm_simplifyfixedpoint(termI));
                        }
                        E xvebO = mkE();
                        xvebO->terms = xveb;
                        EO sum;
                        if (Ord_iszero(pref) && Ord_isfinite(xvebO)) {
                            EO xvebp = Ord_predecessor(xvebO);
                            sum = Ord_addproper(pref, xvebp);
                        } else {
                            sum = Ord_addproper(pref, xvebO);
                        }
                        ret += "&phi;<sub>" + Ord_printbf(nveb) + "</sub>(" + Ord_printbf(sum) + ")";
                        done = true;
                    }
                }
                if (!done) {
                    ret += "&psi;<sub>" + Ord_printbf(f) + "</sub>(" + Ord_printbf(x) + ")";
                }
            }
            if (c > 1) ret += "&middot;" + std::to_string(c);
        }
        return ret;
    }
};

} // namespace

std::shared_ptr<Notation> createEboNotation() { return std::make_shared<EboNotation>(); }
