#include "../notation.h"

std::shared_ptr<Notation> createBmsNotation();
std::shared_ptr<Notation> createWormNotation();
std::shared_ptr<Notation> createPlPrssNotation();
std::shared_ptr<Notation> createEboNotation();

std::vector<std::pair<std::string, std::shared_ptr<Notation>>> availableNotations() {
    std::vector<std::pair<std::string, std::shared_ptr<Notation>>> v;
    auto bms = createBmsNotation();
    auto worm = createWormNotation();
    auto plprss = createPlPrssNotation();
    auto ebo = createEboNotation();
    v.push_back({"BMS", bms});
    v.push_back({"Worm", worm});
    v.push_back({"PLPrSS", plprss});
    v.push_back({"EBO", ebo});
    return v;
}
