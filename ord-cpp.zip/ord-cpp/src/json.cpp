#include "json.h"
#include <cmath>
#include <cstdio>
#include <sstream>

namespace {

struct Parser {
    const std::string& s;
    size_t i = 0;
    std::string err;

    explicit Parser(const std::string& t) : s(t) {}

    void ws() { while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++; }

    bool fail(const std::string& m) { if (err.empty()) err = m + " at pos " + std::to_string(i); return false; }

    bool value(Json& out) {
        ws();
        if (i >= s.size()) return fail("unexpected end");
        char c = s[i];
        if (c == '{') return object(out);
        if (c == '[') return array(out);
        if (c == '"') { std::string v; if (!string(v)) return false; out = Json::mkStr(v); return true; }
        if (c == 't') { if (s.compare(i, 4, "true") == 0) { i += 4; out = Json::mkBool(true); return true; } return fail("bad literal"); }
        if (c == 'f') { if (s.compare(i, 5, "false") == 0) { i += 5; out = Json::mkBool(false); return true; } return fail("bad literal"); }
        if (c == 'n') { if (s.compare(i, 4, "null") == 0) { i += 4; out = Json::mkNull(); return true; } return fail("bad literal"); }
        return number(out);
    }

    bool number(Json& out) {
        size_t start = i;
        if (i < s.size() && (s[i] == '-' || s[i] == '+')) i++;
        while (i < s.size() && (isdigit((unsigned char)s[i]) || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || ((s[i] == '-' || s[i] == '+') && (s[i - 1] == 'e' || s[i - 1] == 'E')))) i++;
        if (start == i) return fail("bad number");
        try {
            out = Json::mkNum(std::stod(s.substr(start, i - start)));
        } catch (...) { return fail("bad number"); }
        return true;
    }

    bool string(std::string& out) {
        if (s[i] != '"') return fail("expected string");
        i++;
        out.clear();
        while (i < s.size() && s[i] != '"') {
            if (s[i] == '\\') {
                i++;
                if (i >= s.size()) return fail("bad escape");
                char e = s[i++];
                switch (e) {
                    case '"': out += '"'; break;
                    case '\\': out += '\\'; break;
                    case '/': out += '/'; break;
                    case 'b': out += '\b'; break;
                    case 'f': out += '\f'; break;
                    case 'n': out += '\n'; break;
                    case 'r': out += '\r'; break;
                    case 't': out += '\t'; break;
                    case 'u': {
                        if (i + 4 > s.size()) return fail("bad unicode escape");
                        unsigned cp = (unsigned)std::stoul(s.substr(i, 4), nullptr, 16);
                        i += 4;
                        // encode UTF-8 (BMP only; surrogate pairs rare in this app)
                        if (cp < 0x80) out += (char)cp;
                        else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
                        else { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
                        break;
                    }
                    default: return fail("bad escape");
                }
            } else {
                out += s[i++];
            }
        }
        if (i >= s.size()) return fail("unterminated string");
        i++; // closing quote
        return true;
    }

    bool array(Json& out) {
        out = Json::mkArr();
        i++; // '['
        ws();
        if (i < s.size() && s[i] == ']') { i++; return true; }
        while (true) {
            Json v;
            if (!value(v)) return false;
            out.arr.push_back(v);
            ws();
            if (i < s.size() && s[i] == ',') { i++; continue; }
            if (i < s.size() && s[i] == ']') { i++; return true; }
            return fail("expected , or ]");
        }
    }

    bool object(Json& out) {
        out = Json::mkObj();
        i++; // '{'
        ws();
        if (i < s.size() && s[i] == '}') { i++; return true; }
        while (true) {
            ws();
            std::string key;
            if (i >= s.size() || s[i] != '"') return fail("expected key");
            if (!string(key)) return false;
            ws();
            if (i >= s.size() || s[i] != ':') return fail("expected :");
            i++;
            Json v;
            if (!value(v)) return false;
            out.obj[key] = v;
            ws();
            if (i < s.size() && s[i] == ',') { i++; continue; }
            if (i < s.size() && s[i] == '}') { i++; return true; }
            return fail("expected , or }");
        }
    }
};

void dumpString(const std::string& in, std::ostringstream& o) {
    o << '"';
    for (char c : in) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) { char buf[8]; snprintf(buf, sizeof(buf), "\\u%04x", c); o << buf; }
                else o << c;
        }
    }
    o << '"';
}

std::string formatNum(double v) {
    if (std::isnan(v)) return "null";
    if (std::isinf(v)) return v > 0 ? "1e999" : "-1e999";
    if (v == (double)(long long)v && std::fabs(v) < 1e15) {
        return std::to_string((long long)v);
    }
    char buf[64];
    snprintf(buf, sizeof(buf), "%g", v);
    return buf;
}

void dumpImpl(const Json& j, int indent, int cur, std::ostringstream& o) {
    std::string pad(cur * indent, ' ');
    std::string padIn((cur + 1) * indent, ' ');
    switch (j.type) {
        case Json::Null: o << "null"; break;
        case Json::Bool: o << (j.b ? "true" : "false"); break;
        case Json::Num: o << formatNum(j.num); break;
        case Json::Str: dumpString(j.str, o); break;
        case Json::Arr: {
            if (j.arr.empty()) { o << "[]"; break; }
            o << "[\n";
            for (size_t k = 0; k < j.arr.size(); k++) {
                o << padIn;
                dumpImpl(j.arr[k], indent, cur + 1, o);
                if (k + 1 < j.arr.size()) o << ",";
                o << "\n";
            }
            o << pad << "]";
            break;
        }
        case Json::Obj: {
            if (j.obj.empty()) { o << "{}"; break; }
            o << "{\n";
            size_t k = 0;
            for (auto& kv : j.obj) {
                o << padIn;
                dumpString(kv.first, o);
                o << ": ";
                dumpImpl(kv.second, indent, cur + 1, o);
                if (++k < j.obj.size()) o << ",";
                o << "\n";
            }
            o << pad << "}";
            break;
        }
    }
}

} // namespace

std::string Json::dump(int indent, int cur) const {
    std::ostringstream o;
    dumpImpl(*this, indent, cur, o);
    return o.str();
}

bool Json::parse(const std::string& text, Json& out, std::string& err) {
    Parser p(text);
    if (!p.value(out)) { err = p.err; return false; }
    return true;
}
