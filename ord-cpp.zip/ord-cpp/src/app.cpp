#include "app.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <misc/cpp/imgui_stdlib.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace {
double nowMs() {
    using namespace std::chrono;
    return duration_cast<duration<double, std::milli>>(steady_clock::now().time_since_epoch()).count();
}
App* g_app = nullptr;

void cbResize(GLFWwindow*, int w, int h) { if (g_app) g_app->onResize(w, h); }
void cbMouseButton(GLFWwindow*, int b, int a, int m) { if (g_app) g_app->onMouseButton(b, a, m); }
void cbCursorPos(GLFWwindow*, double x, double y) { if (g_app) g_app->onCursorPos(x, y); }
void cbCursorEnter(GLFWwindow*, int entered) { if (g_app) g_app->onCursorEnter(entered != 0); }
void cbScroll(GLFWwindow*, double x, double y) { if (g_app) g_app->onScroll(x, y); }
void cbKey(GLFWwindow*, int k, int sc, int a, int m) { if (g_app) g_app->onKey(k, sc, a, m); }
} // namespace

Color App::cfgColor(const std::string& s) const {
    float f[4];
    if (parseColorString(s, f)) return Color(f[0], f[1], f[2], f[3]);
    return Color(1, 1, 1, 1);
}

void App::toast(const std::string& msg, double seconds) {
    toastMsg = msg;
    toastUntil = nowMs() + seconds * 1000.0;
}

void App::switchNotation(int idx) {
    if (idx < 0 || idx >= (int)notations.size()) return;
    currentNotation = idx;
    // JS executeCustomScript: config = initialConfigBackup, then merge notation.config
    engine.config = initialBackup;
    engine.setNotation(notations[(size_t)idx].second);
    jsonBuffer = engine.config.toJson().dump(4);
    engine.markDirty();
}

void App::adjustDepth(int amount) {
    if (settingsOpen) return;
    if (amount < 0) {
        engine.config.MaxIntervalDepth = std::max(-1, engine.config.MaxIntervalDepth - 1);
    } else {
        engine.config.MaxIntervalDepth = engine.config.MaxIntervalDepth == -1 ? 0 : engine.config.MaxIntervalDepth + 1;
    }
    engine.markDirty();
}

// ------------------------------------------------------------ GLFW events --

void App::onResize(int w, int h) {
    if (w <= 0 || h <= 0) return;
    renderer.resize(w, h);
    engine.resize(w, h);
}

void App::onMouseButton(int button, int action, int mods) {
    (void)mods;
    ImGuiIO& io = ImGui::GetIO();
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        if (action == GLFW_PRESS) {
            if (!io.WantCaptureMouse) engine.pointerDown(cursorX, cursorY);
        } else if (action == GLFW_RELEASE) {
            engine.pointerUp();
        }
    }
}

void App::onCursorPos(double x, double y) {
    cursorX = x;
    cursorY = y;
    cursorActive = true;
    engine.pointerMove(x, y);
}

void App::onCursorEnter(bool entered) { cursorActive = entered; }

void App::onScroll(double, double yoff) {
    ImGuiIO& io = ImGui::GetIO();
    if (io.WantCaptureMouse) return;
    engine.wheel(-yoff, cursorX); // GLFW up = positive; JS deltaY down = positive
}

static std::string keyName(int key) {
    switch (key) {
    case GLFW_KEY_LEFT: return "arrowleft";
    case GLFW_KEY_RIGHT: return "arrowright";
    case GLFW_KEY_UP: return "arrowup";
    case GLFW_KEY_DOWN: return "arrowdown";
    case GLFW_KEY_LEFT_SHIFT: case GLFW_KEY_RIGHT_SHIFT: return "shift";
    case GLFW_KEY_LEFT_CONTROL: case GLFW_KEY_RIGHT_CONTROL: return "control";
    case GLFW_KEY_SPACE: return " ";
    default:
        if (key >= GLFW_KEY_A && key <= GLFW_KEY_Z) return std::string(1, (char)('a' + (key - GLFW_KEY_A)));
        if (key >= GLFW_KEY_0 && key <= GLFW_KEY_9) return std::string(1, (char)('0' + (key - GLFW_KEY_0)));
        return "";
    }
}

void App::onKey(int key, int scancode, int action, int mods) {
    (void)scancode;
    ImGuiIO& io = ImGui::GetIO();
    std::string k = keyName(key);
    if (k.empty()) return;

    bool ctrl = (mods & GLFW_MOD_CONTROL) != 0;
    bool shift = (mods & GLFW_MOD_SHIFT) != 0;

    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        engine.activeKeys.insert(k);

        if (io.WantCaptureKeyboard || io.WantTextInput || settingsOpen) return;

        // Space + arrow: toggle auto-hold
        if (engine.activeKeys.count(" ") && k.rfind("arrow", 0) == 0) {
            engine.toggleHeldKeys[k] = !engine.toggleHeldKeys[k];
            return;
        }

        bool acted = false;
        if (k == "z" && ctrl) {
            engine.undoViewport();
            acted = true;
        } else if (k == "a" && !ctrl) {
            engine.config.MaxIntervalDepth = std::max(-1, engine.config.MaxIntervalDepth - 1);
            acted = true;
        } else if (k == "s" && !shift && !ctrl) {
            engine.config.MaxIntervalDepth = engine.config.MaxIntervalDepth == -1 ? 0 : engine.config.MaxIntervalDepth + 1;
            acted = true;
        } else if (k == "s" && shift) {
            engine.config.SlowMode = !engine.config.SlowMode;
            toast(std::string(engine.config.SlowMode ? "Enabled" : "Disabled") + " Slow Mode");
            acted = true;
        } else if (k == "f" && !ctrl) {
            engine.config.EnableOrdinalFinder = !engine.config.EnableOrdinalFinder;
        } else if (k == "g" && !ctrl) {
            engine.config.EnableSetViewPort = !engine.config.EnableSetViewPort;
        } else if (k == "i" && !ctrl) {
            engine.config.ShowCurrentPositionState = !engine.config.ShowCurrentPositionState;
            acted = true;
        } else if (k == "m" && !ctrl) {
            engine.config.MathstickMode = !engine.config.MathstickMode;
            engine.config.TickBetweenLabelXoffest = engine.config.MathstickMode ? 5 : -5;
            engine.config.Tickheight = engine.config.MathstickMode ? 0.0035 : 0.05;
            acted = true;
        } else if (k == "h" && !ctrl) {
            engine.config.HarmonicInvtervalSpacing = !engine.config.HarmonicInvtervalSpacing;
            acted = true;
        } else if (k == "l" && !ctrl) {
            engine.config.LockScreen = !engine.config.LockScreen;
            acted = true;
        } else if (k == "d" && !ctrl) {
            engine.config.DiagonalTickArrangement = !engine.config.DiagonalTickArrangement;
            acted = true;
        } else if (k == "z" && !ctrl) {
            engine.config.ZoomIntoMouse = !engine.config.ZoomIntoMouse;
            acted = true;
        } else if (k == "r" && !ctrl) {
            engine.resetViewport();
            acted = true;
        } else if (k == "1" && !ctrl) {
            toast("Pointer lock is not available in the native port.");
        } else if (k == "2" && !ctrl) {
            engine.config.sampleTextAlign =
                engine.config.sampleTextAlign == "left" ? "center" :
                engine.config.sampleTextAlign == "center" ? "right" : "left";
            acted = true;
        }
        if (acted) engine.markDirty();
    } else if (action == GLFW_RELEASE) {
        // JS keyup: arrows with toggle-hold stay active
        if (k.rfind("arrow", 0) == 0) {
            auto it = engine.toggleHeldKeys.find(k);
            if (it != engine.toggleHeldKeys.end() && it->second) return;
        }
        engine.activeKeys.erase(k);
    }
}

// ------------------------------------------------------------ scene drawing --

static Color blendColorWithBrightness(const Config& cfg, const std::string& hexColor, double b) {
    float f[4];
    if (!parseColorString(hexColor, f)) return Color(1, 1, 1, 1);
    if (!cfg.EnableTickColorBlending) return Color(f[0], f[1], f[2], f[3]);
    int r = (int)(f[0] * 255.0f);
    int g = (int)(f[1] * 255.0f);
    int bc = (int)(f[2] * 255.0f);
    if (b <= cfg.TickColorMaxBrightness) {
        double scale = b / cfg.TickColorMaxBrightness;
        r = (int)std::floor(r * scale);
        g = (int)std::floor(g * scale);
        bc = (int)std::floor(bc * scale);
    } else {
        double boost = std::min(cfg.TickColorMaxBoost, b - cfg.TickColorBoostStart);
        r = (int)std::min(cfg.TickColorMaxChannel, r + boost);
        g = (int)std::min(cfg.TickColorMaxChannel, g + boost);
        bc = (int)std::min(cfg.TickColorMaxChannel, bc + boost);
    }
    return Color(r / 255.0f, g / 255.0f, bc / 255.0f, 1.0f);
}

void App::drawDivisionLine() {
    if (!engine.divisionLineVisible()) return;
    double slope = engine.config.DiagonalTickArrangement ? engine.config.TickSlopeArrangement : 0;
    double y0 = (engine.H / 2.0) - (slope * engine.H * 0.5);
    double y1 = (engine.H / 2.0) + (slope * engine.H * 0.5);
    Color c = cfgColor(engine.config.ScreenDivisionLineColor);
    // JS line is 2px wide centered at 50% via CSS; the drawLine version is diagonal
    renderer.pushLine(0, (float)y0, (float)engine.W, (float)y1, c, 2.0f);
}

void App::drawTicks() {
    if (!engine.config.ShowTick) return;
    double slope = engine.config.DiagonalTickArrangement ? engine.config.TickSlopeArrangement : 0;
    double MAX_SAFE_HEIGHT = engine.H * 2.0;

    for (size_t n = 0; n < engine.ticks.size(); n++) {
        const TickEntry& t = engine.ticks[n];
        if (!t.valid) continue;
        double x = (double)n;
        double y = (engine.H / 2.0) + (slope * engine.H * ((double)n / (double)engine.W - 0.5));

        double b = 128.0 + 256.0 * std::log(1.0 + engine.impor[n]) * engine.ilxw;
        if (!std::isfinite(b)) b = 255;
        b = std::max(0.0, std::min(b, 255.0));

        Color c = engine.config.ColorTick
                      ? blendColorWithBrightness(engine.config, t.color, b)
                      : blendColorWithBrightness(engine.config, engine.config.DefaultTickColor, b);

        double currentTickHeight = engine.config.MathstickMode
                                       ? engine.tHeight * (engine.config.MathStick_UseLogarithmLength
                                                               ? std::log(engine.impor[n] + 1) / std::log(engine.config.MathStick_LogarithmBase)
                                                               : engine.impor[n])
                                       : engine.tHeight;
        if (!std::isfinite(currentTickHeight)) currentTickHeight = MAX_SAFE_HEIGHT;
        currentTickHeight = std::min(currentTickHeight, MAX_SAFE_HEIGHT);

        renderer.pushLine((float)x, (float)(y - currentTickHeight * (1 - engine.config.TickAnchorPoint)),
                          (float)x, (float)(y + currentTickHeight * engine.config.TickAnchorPoint),
                          c, (float)engine.config.TickWidth);
    }
}

void App::drawTimelineLabels() {
    double slope = engine.config.DiagonalTickArrangement ? engine.config.TickSlopeArrangement : 0;

    std::vector<ModeSpec> lineModes;
    for (const auto& m : engine.config.modes)
        if (m.target == "both" || m.target == "line") lineModes.push_back(m);

    auto names = engine.notation->displayNames();

    for (const LabelEntry& lbl : engine.labelsToDraw) {
        double px = lbl.x;
        double tH = engine.config.MathstickMode
                        ? engine.tHeight * (engine.config.MathStick_UseLogarithmLength
                                                ? std::log(lbl.impor + 1) / std::log(engine.config.MathStick_LogarithmBase)
                                                : lbl.impor)
                        : engine.tHeight;

        double py = (engine.H / 2.0) + (slope * engine.H * (px / (double)engine.W - 0.5)) -
                    tH * (1 - engine.config.TickAnchorPoint) - engine.config.LabelBetweenTickSpacing;

        int totalModes = (int)lineModes.size();
        std::string aliasName = engine.aliasFor(lbl.ord);

        double modeStackHeight = (engine.config.ShowLabel && totalModes > 0)
                                     ? (totalModes - 1) * engine.config.LabelBetweenLabelSpacing
                                     : 0;
        double spacingBelowAlias = (engine.config.ShowLabel && engine.config.ShowTimelineLabel && !aliasName.empty())
                                       ? engine.config.LabelBetweenTimelineSpacing
                                       : 0;
        double topLimit = modeStackHeight + spacingBelowAlias + 22;
        if (py < topLimit && engine.config.MathstickMode) py = topLimit;

        if (engine.config.ShowLabel) {
            for (int i = 0; i < totalModes; i++) {
                int mi = lineModes[(size_t)i].mode;
                if (mi < 0 || (size_t)mi >= names.size()) continue;
                std::string labelString = engine.notation->display(lbl.ord, names[(size_t)mi]);
                Color color = engine.config.ColorLabel ? cfgColor(engine.notation->classifyOrdinal(lbl.ord))
                                                       : cfgColor(engine.config.DefaultLabelColor);
                double currentY = py - ((totalModes - 1 - i) * engine.config.LabelBetweenLabelSpacing);
                double labelX = px + engine.config.TickBetweenLabelXoffest +
                                (engine.config.LabelBetweenLabelXoffest * (totalModes - 1 - i));
                text.draw(labelString, (float)labelX, (float)currentY, 22.0f, color,
                          "left", "bottom", (float)engine.config.LabelRotation);
            }
        }

        if (engine.config.ShowTimelineLabel && !aliasName.empty()) {
            double aliasY = py - modeStackHeight - spacingBelowAlias;
            double modeSteps = (engine.config.ShowLabel && totalModes > 0) ? (totalModes - 1) : 0;
            double aliasX = px + engine.config.TickBetweenLabelXoffest +
                            (modeSteps * engine.config.LabelBetweenLabelXoffest) +
                            engine.config.LabelBetweenTimelineXoffest;
            text.draw(aliasName, (float)aliasX, (float)aliasY, 20.0f,
                      cfgColor(engine.config.DefaultTimelineLabelColor),
                      "left", "bottom", (float)engine.config.TimelineRotation);
        }
    }
}

void App::drawSample() {
    if (!engine.config.ShowSample || !engine.sampleValid || engine.sampleLines.empty()) return;
    std::string joined;
    for (size_t i = 0; i < engine.sampleLines.size(); i++) {
        if (i) joined += "\n";
        joined += engine.sampleLines[i];
    }

    float sizePx = (float)engine.config.sampleFontSize;
    float blockW, blockH;
    text.measure(joined, sizePx, blockW, blockH);

    double left = engine.W * engine.config.sampleLeftSpacingPct / 100.0;
    double elemW = std::min((double)engine.W, engine.W * engine.config.sampleMaxWidthPct / 100.0);
    double top = engine.H * engine.config.sampleTopSpacingPct / 100.0 + blockH * engine.config.sampleTranslateYPct / 100.0;

    float x;
    std::string align;
    if (engine.config.sampleTextAlign == "center") { x = (float)(left + elemW * 0.5); align = "center"; }
    else if (engine.config.sampleTextAlign == "right") { x = (float)(left + elemW); align = "right"; }
    else { x = (float)left; align = "left"; }

    text.draw(joined, x, (float)top, sizePx, cfgColor(engine.sampleColor), align, "top");
}

void App::drawHUD() {
    double py = 0;
    double px = engine.W - 7;
    if (engine.config.ShowTitle) {
        text.draw(engine.notation->title(), (float)px, 0, 30.0f, cfgColor(engine.config.TitleColor), "right", "top");
        py = 30;
    }
    if (engine.config.ShowLegends) {
        for (const auto& [name, color] : engine.notation->ordinalTypes()) {
            text.draw(name, (float)px, (float)py, 26.0f, cfgColor(color), "right", "top");
            py += 26;
        }
    }
    if (engine.config.ShowHUD) {
        auto items = engine.hudItems();
        for (size_t i = 0; i < items.size(); i++) {
            text.draw(items[i].text, 0, (float)(i * 20.0), 20.0f, cfgColor(items[i].color), "left", "top");
        }
    }
}

void App::drawHudStats() {
    if (!engine.config.ShowCurrentPositionState) return;
    std::string combined;
    if (!engine.posText.empty()) combined += engine.posText;
    if (!engine.zoomText.empty()) {
        if (!combined.empty()) combined += "\n";
        combined += engine.zoomText;
    }
    if (combined.empty()) return;
    text.draw(combined, 135.0f, (float)(engine.H - 7), 16.0f,
              cfgColor(engine.config.CurrentPositionStateTextColor), "left", "bottom");
}

void App::drawFps() {
    if (!engine.config.ShowFPS) return;
    std::string s = toFixed(engine.fps, engine.config.fpsPrecision) + "fps";
    text.draw(s, 5.0f, (float)(engine.H - 5), 14.0f, cfgColor(engine.config.FPSLabelColor), "left", "bottom");
}

void App::drawSelectionBox() {
    if (!engine.config.SlowMode || !engine.selection.active) return;
    float x = (float)std::min(engine.selection.startX, engine.selection.currentX);
    float y = (float)std::min(engine.selection.startY, engine.selection.currentY);
    float w = (float)std::fabs(engine.selection.currentX - engine.selection.startX);
    float h = (float)std::fabs(engine.selection.currentY - engine.selection.startY);
    renderer.pushQuad(x, y, w, h, cfgColor(engine.config.ZoomSelectionFillColor));
    Color border(0.0f, 150 / 255.0f, 1.0f, 0.8f);
    renderer.pushLine(x, y, x + w, y, border, 1);
    renderer.pushLine(x + w, y, x + w, y + h, border, 1);
    renderer.pushLine(x + w, y + h, x, y + h, border, 1);
    renderer.pushLine(x, y + h, x, y, border, 1);
}

void App::drawTooltip() {
    if (!cursorActive || settingsOpen) return;
    std::string tip = engine.buildTooltip(cursorX, cursorY);
    if (tip.empty()) return;

    float w, h;
    text.measure(tip, 13.0f, w, h);
    float padX = 12, padY = 8;
    float boxW = w + padX * 2, boxH = h + padY * 2;

    float tx = (float)cursorX + 15;
    float ty = (float)cursorY + 15;
    if (tx + boxW > engine.W - 10) tx = (float)cursorX - boxW - 15;
    if (ty + boxH > engine.H - 10) ty = (float)cursorY - boxH - 15;
    tx = std::max(10.0f, std::min(tx, (float)engine.W - boxW - 10));
    ty = std::max(10.0f, std::min(ty, (float)engine.H - boxH - 10));

    renderer.pushQuad(tx, ty, boxW, boxH, Color(15 / 255.0f, 15 / 255.0f, 15 / 255.0f, 0.92f));
    Color border(0x55 / 255.0f, 0x55 / 255.0f, 0x55 / 255.0f, 1.0f);
    renderer.pushLine(tx, ty, tx + boxW, ty, border, 1);
    renderer.pushLine(tx + boxW, ty, tx + boxW, ty + boxH, border, 1);
    renderer.pushLine(tx + boxW, ty + boxH, tx, ty + boxH, border, 1);
    renderer.pushLine(tx, ty + boxH, tx, ty, border, 1);
    renderer.flush();
    text.draw(tip, tx + padX, ty + padY, 13.0f, Color(1, 1, 1, 1), "left", "top");
}

void App::drawScene() {
    float bg[4];
    parseColorString(engine.config.BackgroundColor, bg);
    renderer.begin(bg[0], bg[1], bg[2], bg[3]);

    drawDivisionLine();
    drawTicks();
    drawSelectionBox();
    renderer.flush();

    drawTimelineLabels();
    drawSample();
    drawHUD();
    drawHudStats();
    drawFps();
    drawTooltip(); // flushes scene layer internally before drawing its text
    renderer.flush();
}

// ------------------------------------------------------------- overlay UI --

static void overlayWindowFlags() {
    ImGui::SetNextWindowBgAlpha(0.0f);
}

static const ImGuiWindowFlags kOverlayFlags =
    ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
    ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus;

void App::buildFloatingGuis() {
    float W = (float)engine.W, H = (float)engine.H;

    // --- Right-bottom buttons: Reset / Revert / Config Menu ---
    {
        ImGui::SetNextWindowPos(ImVec2(W - 15, H - 15), ImGuiCond_Always, ImVec2(1, 1));
        overlayWindowFlags();
        ImGui::Begin("##rbtns", nullptr, kOverlayFlags);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 4));
        if (ImGui::Button("Reset")) engine.resetViewport();
        ImGui::SameLine();
        if (ImGui::Button("Revert")) {
            if (engine.undoViewport()) engine.markDirty();
        }
        ImGui::SameLine();
        if (ImGui::Button("Config Menu")) {
            settingsOpen = !settingsOpen;
            engine.settingsOpen = settingsOpen;
            if (settingsOpen) jsonBuffer = engine.config.toJson().dump(4);
        }
        ImGui::PopStyleVar();
        ImGui::End();
    }

    // --- Depth controls (bottom center) ---
    if (engine.config.ShowDepthAdjustGui) {
        ImGui::SetNextWindowPos(ImVec2(W * 0.5f, H - 5), ImGuiCond_Always, ImVec2(0.5f, 1));
        overlayWindowFlags();
        ImGui::Begin("##depth", nullptr, kOverlayFlags);
        if (ImGui::Button("-##depth")) adjustDepth(-1);
        ImGui::SameLine();
        std::string dtext = engine.config.MaxIntervalDepth == -1
                                ? "Depth: Infinite"
                                : "Depth: " + std::to_string(engine.config.MaxIntervalDepth);
        ImGui::TextUnformatted(dtext.c_str());
        ImGui::SameLine();
        if (ImGui::Button("+##depth")) adjustDepth(1);
        ImGui::End();
    }

    // --- Notation controls (bottom-left) ---
    if (engine.config.ShowOrdinalNotationConfigGui) {
        ImGui::SetNextWindowPos(ImVec2(10, H - 40), ImGuiCond_Always, ImVec2(0, 1));
        overlayWindowFlags();
        ImGui::Begin("##notationctl", nullptr, kOverlayFlags);
        auto names = engine.notation->displayNames();
        int removeIdx = -1;
        for (size_t i = 0; i < engine.config.modes.size(); i++) {
            ImGui::PushID((int)i);
            int cur = engine.config.modes[i].mode;
            std::string preview = (cur >= 0 && (size_t)cur < names.size()) ? names[(size_t)cur] : "?";
            ImGui::SetNextItemWidth(140);
            if (ImGui::BeginCombo("##sel", preview.c_str())) {
                for (size_t j = 0; j < names.size(); j++) {
                    if (ImGui::Selectable(names[j].c_str(), (int)j == cur)) {
                        engine.config.modes[i].mode = (int)j;
                        engine.markDirty();
                    }
                }
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            if (ImGui::Button("Remove notation")) removeIdx = (int)i;
            ImGui::SameLine();
            const char* targetLabels[3] = { "Display: both", "Display: number line", "Display: sample" };
            const char* targetCycle[3] = { "line", "sample", "both" };
            std::string t = engine.config.modes[i].target;
            int ti = t == "line" ? 1 : (t == "sample" ? 2 : 0);
            if (ImGui::Button(targetLabels[ti])) {
                if (!settingsOpen) {
                    engine.config.modes[i].target = targetCycle[ti];
                    engine.markDirty();
                }
            }
            ImGui::PopID();
        }
        if (removeIdx >= 0 && engine.config.modes.size() > 1 && !settingsOpen) {
            engine.config.modes.erase(engine.config.modes.begin() + removeIdx);
            engine.markDirty();
        }
        if (ImGui::Button("+ Add notation")) {
            if (!settingsOpen) {
                int nextMode = 0;
                if (!engine.config.modes.empty() && !names.empty()) {
                    nextMode = (engine.config.modes[0].mode + 1) % (int)names.size();
                }
                engine.config.modes.insert(engine.config.modes.begin(), ModeSpec{ nextMode, "both" });
                engine.markDirty();
            }
        }
        ImGui::End();
    }

    // --- Viewport setter (top center) ---
    if (engine.config.EnableSetViewPort) {
        ImGui::SetNextWindowPos(ImVec2(W * 0.5f, 15), ImGuiCond_Always, ImVec2(0.5f, 0));
        ImGui::SetNextWindowSize(ImVec2(420, 0));
        ImGui::Begin("##viewportset", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        ImGui::TextUnformatted("Position:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(90);
        ImGui::InputText("##vppos", vpPos, sizeof(vpPos));
        ImGui::SameLine();
        ImGui::TextUnformatted("Zoom:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(90);
        ImGui::InputText("##vpzoom", vpZoom, sizeof(vpZoom));
        ImGui::SameLine();
        if (ImGui::Button("Apply##vp")) {
            std::string err;
            if (!engine.triggerViewportZoom(vpPos, vpZoom, err)) toast(err);
        }
        ImGui::End();
    }

    // --- Ordinal finder ---
    if (engine.config.EnableOrdinalFinder && engine.notation->hasParser()) {
        float topY = engine.config.EnableSetViewPort ? 65.0f : 15.0f;
        ImGui::SetNextWindowPos(ImVec2(W * 0.5f, topY), ImGuiCond_Always, ImVec2(0.5f, 0));
        ImGui::SetNextWindowSize(ImVec2(460, 0));
        ImGui::Begin("##finder", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        ImGui::TextUnformatted("Ordinal:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(180);
        ImGui::InputTextWithHint("##ordinput", "Enter ordinal...", finderInput, sizeof(finderInput));
        ImGui::SameLine();
        ImGui::TextUnformatted("Depth:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(60);
        ImGui::InputInt("##prec", &finderPrecision, 0, 0);
        ImGui::SameLine();
        if (ImGui::Button("Find")) {
            std::string err;
            if (!engine.findAndZoomToOrdinal(finderInput, finderPrecision, err)) {
                if (!err.empty()) toast(err, 5.0);
            }
        }
        ImGui::End();
    }

    // --- hudStats click-to-copy invisible button ---
    if (engine.config.ShowCurrentPositionState) {
        ImGui::SetNextWindowPos(ImVec2(135, H - 7), ImGuiCond_Always, ImVec2(0, 1));
        overlayWindowFlags();
        ImGui::Begin("##hudstats", nullptr, kOverlayFlags | ImGuiWindowFlags_NoInputs);
        ImGui::End();
        // clickable region
        ImGui::SetNextWindowPos(ImVec2(135, H - 45), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(std::min(0.3f * W, 320.0f), 42));
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.0f);
        ImGui::Begin("##hudcopy", nullptr, kOverlayFlags);
        if (ImGui::InvisibleButton("##copybtn", ImVec2(std::min(0.3f * W, 320.0f), 42))) {
            std::string formatted = "Notation: " + engine.notation->title() + "\n" +
                                    engine.posText + "\n" + engine.zoomText + "\n" +
                                    "Aspect ratio: " + std::to_string(engine.config.aspectratio) + "\n" +
                                    "Harmonic spacing: " + (engine.config.HarmonicInvtervalSpacing ? "Enabled" : "Disabled");
            glfwSetClipboardString(window, formatted.c_str());
            toast("Copied to clipboard!");
        }
        ImGui::End();
        ImGui::PopStyleVar();
    }

    // --- Hint dialog ---
    if (showHint) {
        ImGui::SetNextWindowPos(ImVec2(W * 0.5f, H * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(560, 0));
        ImGui::Begin("Welcome", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        ImGui::TextUnformatted(
            "- Arrow keys / mouse drag & wheel to control\n"
            "- A/S to adjust rendering depth\n"
            "- M to toggle Mathstick Mode\n"
            "- Z to toggle Zoom into Mouse\n"
            "- D to toggle diagonal tick arrangement\n"
            "- H to toggle harmonic interval spacing (lag fixes)\n"
            "- F to toggle ordinal finder (for some notation with a parser)\n"
            "- G to toggle set viewport state\n"
            "- I to show viewport state\n"
            "- L to lock screen (disable interactions)\n"
            "- 2 to change sample text alignment\n"
            "- R to Reset Viewport\n"
            "\n"
            "- Ctrl/Shift to adjust sensitivity of arrow key controls\n"
            "- Shift+S to Enter/Exit Slow Mode\n"
            "- Space+Arrow Key to Toggle Auto hold for that arrow key\n"
            "- Open Config Menu for further configurations\n"
            "\n"
            "Notation modules are compiled in: switch via Config Menu presets.\n"
            "(JS code injection & link sharing are browser-only features.)");
        if (ImGui::Button("I understand", ImVec2(-1, 0))) showHint = false;
        ImGui::End();
    }

    // --- Toast ---
    if (!toastMsg.empty() && nowMs() < toastUntil) {
        ImGui::SetNextWindowPos(ImVec2(W * 0.5f, H * 0.18f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        overlayWindowFlags();
        ImGui::Begin("##toast", nullptr, kOverlayFlags | ImGuiWindowFlags_NoInputs);
        ImGui::TextColored(ImVec4(1, 1, 0.6f, 1), "%s", toastMsg.c_str());
        ImGui::End();
    }
}

void App::saveConfigToSlot() {
    std::string dir = "slots";
    std::error_code ec;
    std::filesystem::create_directory(dir, ec);
    std::string path = dir + "/slot" + std::to_string(slotSelect) + ".json";
    std::ofstream f(path);
    if (!f) {
        toast("Failed to save config slot");
        return;
    }
    f << engine.config.toJson().dump(4);
    toast("Configuration saved to Slot " + std::to_string(slotSelect));
}

void App::loadConfigFromSlot() {
    std::string path = "slots/slot" + std::to_string(slotSelect) + ".json";
    std::ifstream f(path);
    if (!f) {
        toast("Slot " + std::to_string(slotSelect) + " is empty!");
        return;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    Json j;
    std::string err;
    if (!Json::parse(ss.str(), j, err)) {
        toast("Failed to load config: " + err);
        return;
    }
    engine.config.mergeFrom(j);
    if (engine.config.modes.empty()) engine.config.modes = { { 0, "both" } };
    jsonBuffer = engine.config.toJson().dump(4);
    engine.markDirty();
    toast("Configuration loaded from Slot " + std::to_string(slotSelect));
}

void App::buildSettingsMenu() {
    if (!settingsOpen) return;
    float W = (float)engine.W, H = (float)engine.H;
    ImGui::SetNextWindowPos(ImVec2(W - 20, 20), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(430, std::min(640.0f, H - 40)), ImGuiCond_FirstUseEver);

    bool open = true;
    ImGui::Begin("Config Menu", &open, ImGuiWindowFlags_NoCollapse);
    if (!open) settingsOpen = false;
    engine.settingsOpen = settingsOpen;
    if (!settingsOpen) {
        ImGui::End();
        return;
    }

    // --- Notation presets ---
    ImGui::TextUnformatted("Notation System (compiled-in presets)");
    std::vector<const char*> presetNames;
    for (const auto& [name, n] : notations) presetNames.push_back(name.c_str());
    ImGui::SetNextItemWidth(-1);
    if (ImGui::Combo("##preset", &presetSelect, presetNames.data(), (int)presetNames.size())) {
        switchNotation(presetSelect);
    }
    ImGui::Separator();

    // --- Environment Configurations ---
    ImGui::TextUnformatted("Environment Configurations");
    ImGui::SameLine(ImGui::GetWindowWidth() - 140);
    if (ImGui::SmallButton(useJsonEditor ? "Use Sliders Editor" : "Use JSON Editor")) {
        useJsonEditor = !useJsonEditor;
        if (useJsonEditor) jsonBuffer = engine.config.toJson().dump(4);
    }

    // Slots
    if (ImGui::Button("Save")) saveConfigToSlot();
    ImGui::SameLine();
    if (ImGui::Button("Load")) loadConfigFromSlot();
    ImGui::SameLine();
    ImGui::SetNextItemWidth(90);
    const char* slotNames[] = { "Slot 1", "Slot 2", "Slot 3", "Slot 4", "Slot 5" };
    ImGui::Combo("##slot", &slotSelect, slotNames, 5);

    ImGui::Separator();

    Config& c = engine.config;
    bool changed = false;

    if (!useJsonEditor) {
        static const double AR_MIN = 0.1, AR_MAX = 0.9;
        static const double TS_MIN = 1, TS_MAX = 15;
        static const double TH_MIN = 0.001, TH_MAX = 0.1;
        static const double TW_MIN = 1, TW_MAX = 5;
        static const double TA_MIN = 0, TA_MAX = 1;
        static const double LCNT_MIN = 1, LCNT_MAX = 25;
        changed |= ImGui::SliderScalar("Aspect Ratio", ImGuiDataType_Double, &c.aspectratio, &AR_MIN, &AR_MAX);
        {
            float bg[4];
            parseColorString(c.BackgroundColor, bg);
            if (ImGui::ColorEdit3("Background", bg, ImGuiColorEditFlags_NoInputs)) {
                char buf[16];
                snprintf(buf, sizeof(buf), "#%02x%02x%02x", (int)(bg[0] * 255), (int)(bg[1] * 255), (int)(bg[2] * 255));
                c.BackgroundColor = buf;
                changed = true;
            }
        }
        changed |= ImGui::Checkbox("Mathstick Mode", &c.MathstickMode);
        ImGui::SameLine();
        changed |= ImGui::Checkbox("Diagonal Ticks", &c.DiagonalTickArrangement);
        changed |= ImGui::Checkbox("Harmonic Spacing", &c.HarmonicInvtervalSpacing);
        ImGui::SameLine();
        changed |= ImGui::Checkbox("Ordinal Finder", &c.EnableOrdinalFinder);
        changed |= ImGui::Checkbox("Set ViewPort", &c.EnableSetViewPort);
        ImGui::SameLine();
        changed |= ImGui::Checkbox("Slow Mode", &c.SlowMode);
        changed |= ImGui::Checkbox("Current Pos State", &c.ShowCurrentPositionState);
        ImGui::SameLine();
        changed |= ImGui::Checkbox("Cursor Tooltip", &c.ShowCursorTooltip);

        ImGui::Separator();
        changed |= ImGui::SliderScalar("Tick Spacing", ImGuiDataType_Double, &c.TickSpacing, &TS_MIN, &TS_MAX);
        changed |= ImGui::SliderScalar("Tick Height", ImGuiDataType_Double, &c.Tickheight, &TH_MIN, &TH_MAX);
        changed |= ImGui::SliderScalar("Tick Width", ImGuiDataType_Double, &c.TickWidth, &TW_MIN, &TW_MAX);
        changed |= ImGui::SliderScalar("Tick Anchor Point", ImGuiDataType_Double, &c.TickAnchorPoint, &TA_MIN, &TA_MAX);
        changed |= ImGui::SliderScalar("Labels Count", ImGuiDataType_Double, &c.labelscount, &LCNT_MIN, &LCNT_MAX);
        changed |= ImGui::SliderInt("FPS Precision", &c.fpsPrecision, 1, 5);
        changed |= ImGui::SliderInt("Max Intervals Division", &c.MaxIntervalsDivision, -1, 100);
        changed |= ImGui::SliderInt("Max Interval Depth", &c.MaxIntervalDepth, -1, 100);
    } else {
        ImGui::InputTextMultiline("##jsoneditor", &jsonBuffer, ImVec2(-1, ImGui::GetTextLineHeight() * 16));
    }

    if (ImGui::Button("Apply Configuration", ImVec2(-1, 0))) {
        if (useJsonEditor) {
            Json j;
            std::string err;
            if (!Json::parse(jsonBuffer, j, err)) {
                toast("Malformed configuration: " + err, 5.0);
            } else {
                c.mergeFrom(j);
                if (c.modes.empty()) c.modes = { { 0, "both" } };
                toast("Configuration applied");
            }
        } else {
            jsonBuffer = c.toJson().dump(4);
            toast("Configuration applied");
        }
        changed = true;
    }

    ImGui::End();
    if (changed) engine.markDirty();
}

void App::buildOverlayUI() {
    buildFloatingGuis();
    buildSettingsMenu();
}

// -------------------------------------------------------------------- run --

int App::run() {
    g_app = this;
    if (!glfwInit()) {
        fprintf(stderr, "glfwInit failed\n");
        return 1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

    window = glfwCreateWindow(1280, 800, "Generalized Transfinite Number Line (C++ port)", nullptr, nullptr);
    if (!window) {
        fprintf(stderr, "glfwCreateWindow failed\n");
        glfwTerminate();
        return 1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        fprintf(stderr, "gladLoadGLLoader failed\n");
        return 1;
    }

    int fw = 0, fh = 0;
    glfwGetFramebufferSize(window, &fw, &fh);
    renderer.resize(fw, fh);
    renderer.init();
    if (!text.init(&renderer)) {
        fprintf(stderr, "Text renderer init failed\n");
        return 1;
    }

    // Install our callbacks BEFORE ImGui so imgui_impl_glfw chains to them.
    glfwSetFramebufferSizeCallback(window, cbResize);
    glfwSetMouseButtonCallback(window, cbMouseButton);
    glfwSetCursorPosCallback(window, cbCursorPos);
    glfwSetCursorEnterCallback(window, cbCursorEnter);
    glfwSetScrollCallback(window, cbScroll);
    glfwSetKeyCallback(window, cbKey);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    // Notations (compiled-in registry replaces JS script injection).
    notations = availableNotations();
    initialBackup = Config();
    engine.W = fw;
    engine.H = fh;
    switchNotation(0); // BMS default; also runs engine.init()
    jsonBuffer = engine.config.toJson().dump(4);
    engine.frame();

    lastFrameMs = nowMs();

    while (!glfwWindowShouldClose(window)) {
        double now = nowMs();
        double dtMs = now - lastFrameMs;
        lastFrameMs = now;
        if (dtMs > 0) engine.fps = 1000.0 / dtMs;

        glfwPollEvents();

        int cw = 0, ch = 0;
        glfwGetFramebufferSize(window, &cw, &ch);
        if ((cw != engine.W || ch != engine.H) && cw > 0 && ch > 0) onResize(cw, ch);

        engine.settingsOpen = settingsOpen;
        double dtSec = std::min(dtMs / 1000.0, 0.25);
        engine.stepKeyboard(dtSec);
        engine.frame();

        drawScene();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        buildOverlayUI();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    text.shutdown();
    renderer.shutdown();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
