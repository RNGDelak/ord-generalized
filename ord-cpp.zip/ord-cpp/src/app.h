// Application shell: GLFW window, input plumbing, scene drawing, ImGui UI.
#pragma once
#include <memory>
#include <string>
#include <vector>
#include "engine.h"
#include "renderer.h"
#include "text.h"

struct GLFWwindow;

class App {
public:
    int run();

    // called from static GLFW callbacks
    void onResize(int w, int h);
    void onMouseButton(int button, int action, int mods);
    void onCursorPos(double x, double y);
    void onCursorEnter(bool entered);
    void onScroll(double xoff, double yoff);
    void onKey(int key, int scancode, int action, int mods);

private:
    GLFWwindow* window = nullptr;
    Engine engine;
    Renderer renderer;
    TextRenderer text;

    std::vector<std::pair<std::string, std::shared_ptr<Notation>>> notations;
    int currentNotation = 0;

    Config initialBackup; // config before any notation load (JS initialConfigBackup)

    bool settingsOpen = false;
    bool showHint = true;
    bool useJsonEditor = false;
    int slotSelect = 0;
    int presetSelect = 0;

    std::string jsonBuffer;
    char finderInput[256] = { 0 };
    int finderPrecision = 40;
    char vpPos[64] = { '0', '.', '5', 0 };
    char vpZoom[64] = { '1', '.', '0', 0 };

    double cursorX = -1, cursorY = -1;
    bool cursorActive = false;

    std::string toastMsg;
    double toastUntil = 0;

    double lastFrameMs = 0;

    void toast(const std::string& msg, double seconds = 3.0);
    void switchNotation(int idx);
    void adjustDepth(int amount);

    // scene drawing (plot.js render())
    void drawScene();
    void drawTicks();
    void drawScreenDivisionLine();
    void drawMiddleNumberLineDivision();
    void drawTimelineLabels();
    void drawSample();
    void drawHUD();
    void drawHudStats();
    void drawFps();
    void drawTooltip();
    void drawSelectionBox();

    // ImGui overlay (ui.js / index.html chrome)
    void buildOverlayUI();
    void buildSettingsMenu();
    void buildFloatingGuis();
    void saveConfigToSlot();
    void loadConfigFromSlot();

    Color cfgColor(const std::string& s) const;
};
