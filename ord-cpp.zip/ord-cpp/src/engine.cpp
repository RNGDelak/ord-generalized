#include "engine.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>

// ---------------------------------------------------------------- helpers --

bool parseColorString(const std::string& s, float out[4]) {
    out[0] = out[1] = out[2] = 1.0f;
    out[3] = 1.0f;
    if (s.empty()) return false;
    if (s[0] == '#') {
        std::string h = s.substr(1);
        auto hexv = [](char c) -> int {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return 0;
        };
        if (h.size() == 3) {
            out[0] = (hexv(h[0]) * 17) / 255.0f;
            out[1] = (hexv(h[1]) * 17) / 255.0f;
            out[2] = (hexv(h[2]) * 17) / 255.0f;
            return true;
        }
        if (h.size() >= 6) {
            out[0] = (hexv(h[0]) * 16 + hexv(h[1])) / 255.0f;
            out[1] = (hexv(h[2]) * 16 + hexv(h[3])) / 255.0f;
            out[2] = (hexv(h[4]) * 16 + hexv(h[5])) / 255.0f;
            return true;
        }
        return false;
    }
    // rgb(...) / rgba(...)
    size_t lp = s.find('('), rp = s.find(')');
    if (lp == std::string::npos || rp == std::string::npos || rp <= lp + 1) return false;
    std::string inner = s.substr(lp + 1, rp - lp - 1);
    std::vector<std::string> parts;
    std::string cur;
    for (char c : inner) {
        if (c == ',') { parts.push_back(cur); cur.clear(); }
        else cur += c;
    }
    parts.push_back(cur);
    if (parts.size() < 3) return false;
    out[0] = (float)strtod(parts[0].c_str(), nullptr) / 255.0f;
    out[1] = (float)strtod(parts[1].c_str(), nullptr) / 255.0f;
    out[2] = (float)strtod(parts[2].c_str(), nullptr) / 255.0f;
    out[3] = parts.size() >= 4 ? (float)strtod(parts[3].c_str(), nullptr) : 1.0f;
    return true;
}

std::string toFixed(double v, int digits) {
    char buf[64];
    snprintf(buf, sizeof(buf), "%.*f", digits, v);
    return buf;
}

namespace {

// PRECISION_SCALE is always a power of ten; k = exponent.
long long scaleExp(const BigInt& scale) { return scale.numDigits() - 1; }

// a * b / scale (truncating), where scale = 10^k.
BigInt mulDivScale(const BigInt& a, const BigInt& b, const BigInt& scale) {
    return (a * b).divPow10(scaleExp(scale));
}

std::string toLowerCopy(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}

std::string trimCopy(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace((unsigned char)s[a])) a++;
    while (b > a && isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}

} // namespace

// --------------------------------------------------------- BigInt helpers --

BigInt Engine::toBigInt(double num) const {
    // JS: BigInt(Math.round(num * 1e6)) * (PRECISION_SCALE / 1000000n)
    double scaled = std::round(num * 1e6);
    BigInt bi((long long)scaled);
    return bi.mulPow10(scaleExp(PRECISION_SCALE) - 6);
}

double Engine::toNum(const BigInt& b) const {
    return b.toDouble() / PRECISION_SCALE.toDouble();
}

BigInt Engine::converge1BigInt(const BigInt& a, const BigInt& b, double rescale) const {
    BigInt rescaleBI = toBigInt(rescale * config.aspectratio);
    return b + mulDivScale(a - b, rescaleBI, PRECISION_SCALE);
}

void Engine::updateAdaptivePrecisionScale() {
    BigInt currentWidthBI = x1 - x0;
    if (currentWidthBI.sgn() <= 0) {
        PRECISION_SCALE = BigInt::pow10(10);
        return;
    }
    long long log10Zoom = scaleExp(PRECISION_SCALE) + 1 - currentWidthBI.numDigits();
    if (log10Zoom < 0) log10Zoom = 0;

    int mantissa = config.BigIntPrecisionMantissa ? config.BigIntPrecisionMantissa : 8;
    long long requiredDigits = std::max(10LL, log10Zoom + mantissa + 10);
    BigInt nextScale = BigInt::pow10(requiredDigits);

    if (nextScale != PRECISION_SCALE) {
        long long oldE = scaleExp(PRECISION_SCALE);
        long long newE = requiredDigits;
        if (newE >= oldE) {
            x0 = x0.mulPow10(newE - oldE);
            x1 = x1.mulPow10(newE - oldE);
        } else {
            x0 = x0.divPow10(oldE - newE);
            x1 = x1.divPow10(oldE - newE);
        }
        PRECISION_SCALE = nextScale;
    }
}

// -------------------------------------------------------------- tree logic --

void Engine::initTicks(double width) {
    size_t size = (size_t)std::ceil(width);
    ticks.assign(size, TickEntry());
    impor.assign(size, 0.0);
    labelsToDraw.clear();
}

void Engine::importanceSeg(double sx0, double sx1, double width) {
    if (sx0 <= 0 || sx0 > width) return;
    if (ticks.empty()) return;
    long long idx = (long long)std::floor(sx0);
    idx = std::max(0LL, std::min((long long)ticks.size() - 1, idx));
    impor[(size_t)idx] = std::max(impor[(size_t)idx], sx1 - sx0);
}

void Engine::tickmark(double sx0, double sx1, const Ord& o0, double width) {
    if (sx0 < 0 || sx0 >= width) return;
    importanceSeg(sx0, sx1, width);
    if (ticks.empty()) return;
    long long idx = (long long)std::floor(sx0);
    idx = std::max(0LL, std::min((long long)ticks.size() - 1, idx));
    double l = sx1 - sx0;
    TickEntry& t = ticks[(size_t)idx];
    if (!t.valid || l > t.importance) {
        t.valid = true;
        t.color = notation->classifyOrdinal(o0);
        t.ord = o0;
        t.importance = l;
    }
}

void Engine::tickmarkLabel(double sx0, double sx1, const Ord& o0, double width) {
    (void)sx1;
    if (sx0 < 0 || sx0 >= width) return;
    if (impor.empty()) return;
    long long idx = (long long)std::floor(sx0);
    idx = std::max(0LL, std::min((long long)impor.size() - 1, idx));
    labelsToDraw.push_back({ sx0, o0, impor[(size_t)idx] });
}

void Engine::segmentBigInt(const BigInt& bx0, const BigInt& bx1, const Ord& o0, const Ord& o1,
                           const BigInt& epsBI, const BigInt& xminBI, const BigInt& xmaxBI,
                           long long depth, long long lefts, const SegCallback& callback, double widthNum) {
    if (bx1 <= xminBI || bx0 > xmaxBI) return;

    double x0Num = toNum(bx0);
    double x1Num = toNum(bx1);
    importanceSeg(x0Num, x1Num, widthNum);

    if ((bx1 - bx0) < epsBI || (config.MaxIntervalDepth >= 0 && depth >= config.MaxIntervalDepth)) {
        callback(x0Num, x1Num, o0, widthNum);
        return;
    }

    Ord Zero = notation->zero();
    Ord Limit = notation->limit();

    if (notation->cmp(o1, Limit) == 0 || (!notation->isSuccessor(o1) && notation->cmp(o1, Zero) != 0)) {
        double rescale = config.HarmonicInvtervalSpacing ? 1.0 : 2.0 / (double)(lefts + 2);
        BigInt top = bx1 - epsBI;
        BigInt s_x0 = bx0, s_x1 = bx0;
        long long n = 0;

        for (n = 0; s_x0 < top && s_x0 < xmaxBI; n++) {
            if (n > 0) s_x0 = s_x1;
            s_x1 = converge1BigInt(s_x0, bx1, 1.0);
            if (n > config.MaxIntervalsDivision && config.MaxIntervalsDivision > -1) break;
        }

        long long m = n + 2;
        std::vector<Ord> seq((size_t)m);
        for (long long idx = 0; idx < m; idx++) seq[(size_t)idx] = notation->fs(o1, idx);

        long long ofs = 0;
        for (ofs = 0; ofs < m && notation->cmp(seq[(size_t)ofs], o0) <= 0; ofs++)
            ;

        while (ofs + n > m) {
            m = ofs + n;
            seq.assign((size_t)m, Ord());
            for (long long idx = 0; idx < m; idx++) seq[(size_t)idx] = notation->fs(o1, idx);
            for (ofs = 0; ofs < m && notation->cmp(seq[(size_t)ofs], o0) <= 0; ofs++)
                ;
        }

        // JS: `seq[ofs].length > 0 && seq[ofs][len-1] === 0` (only true for flat-array notations)
        if (ofs < m && notation->lastEntryIsZero(seq[(size_t)ofs])) {
            rescale = 1.0;
        }

        s_x0 = bx0;
        s_x1 = bx0;
        for (n = 0; s_x0 < top && s_x0 < xmaxBI && ofs + n < m; n++) {
            if (n > 0) s_x0 = s_x1;
            s_x1 = converge1BigInt(s_x0, bx1, n ? 1.0 : rescale);

            Ord next_o0 = (n == 0) ? o0 : seq[(size_t)(ofs + n - 1)];
            Ord next_o1 = seq[(size_t)(ofs + n)];

            segmentBigInt(s_x0, s_x1, next_o0, next_o1, epsBI, xminBI, xmaxBI,
                          depth + 1, n ? 0 : lefts + 1, callback, widthNum);
        }
    } else {
        callback(x0Num, x1Num, o0, widthNum);
    }
}

void Engine::computeTree(double width) {
    initTicks(width);

    BigInt epsBI = toBigInt(config.TickSpacing);
    BigInt xminBI(0);
    BigInt xmaxBI = toBigInt(width);

    segmentBigInt(x0, x1, notation->zero(), notation->limit(), epsBI, xminBI, xmaxBI, 0, 0,
                  [this](double a, double b, const Ord& o, double w) { tickmark(a, b, o, w); }, width);

    tickmarkLabel(toNum(x0), toNum(x0), notation->zero(), width);

    BigInt labelEpsBI = toBigInt((double)W / config.labelscount);
    segmentBigInt(x0, x1, notation->zero(), notation->limit(), labelEpsBI, xminBI, xmaxBI, 0, 0,
                  [this](double a, double b, const Ord& o, double w) { tickmarkLabel(a, b, o, w); }, width);

    tickmarkLabel(toNum(x1), toNum(x1), notation->limit(), width);
}

// ------------------------------------------------------------------- frame --

void Engine::samplerCallback(double sx0, double sx1, const Ord& o0, double xmax) {
    (void)sx1;
    double d = std::fabs(sx0 - (xmax - 0.5));
    if (d < samplerBd) {
        samplerBd = d;
        samplerOrd = o0;
    }
}

void Engine::sampleHighPrecision(double x, double width) {
    sampleLines.clear();
    sampleValid = false;
    if (!config.ShowSample) return;

    samplerBd = 1e20;
    samplerOrd = nullptr;

    BigInt xBI = toBigInt(x);
    if (xBI <= x0) {
        samplerOrd = notation->zero();
        samplerBd = 0;
    } else if (xBI >= x1) {
        samplerOrd = notation->limit();
        samplerBd = 0;
    } else {
        segmentBigInt(x0, x1, notation->zero(), notation->limit(),
                      toBigInt(1), xBI, toBigInt(x + 1),
                      0, 0, [this](double a, double b, const Ord& o, double w) { samplerCallback(a, b, o, w); }, width);
    }

    if (samplerBd < 1e20 && samplerOrd) {
        for (const auto& mi : config.modes) {
            if (mi.target != "both" && mi.target != "sample") continue;
            auto names = notation->displayNames();
            if (mi.mode >= 0 && (size_t)mi.mode < names.size()) {
                sampleLines.push_back(notation->display(samplerOrd, names[(size_t)mi.mode]));
            }
        }
        sampleColor = config.ColorSample ? notation->classifyOrdinal(samplerOrd) : config.DefaultSampleColor;
        sampleValid = true;
    }
}

void Engine::frame() {
    if (!dirty || !notation) return;
    dirty = false;

    updateAdaptivePrecisionScale();

    if (config.Rendernumberline) {
        computeTree((double)W);
    }

    tHeight = H * config.Tickheight;
    ilxw = W > 0 ? 1.0 / std::log((double)W) : 0.0;

    sampleHighPrecision(W / 2.0, (double)W);

    if (config.ShowCurrentPositionState) {
        updateCameraStats();
    } else {
        zoomText.clear();
        posText.clear();
    }
}

std::vector<HudItem> Engine::hudItems() const {
    std::vector<HudItem> items;
    if (config.SlowMode) items.push_back({ "Slow Mode Enabled", "rgb(255, 0, 0)" });
    if (config.LockScreen) items.push_back({ "Screen Locked", "rgb(255, 0, 0)" });
    if (config.ZoomIntoMouse) items.push_back({ "Zoom Into Mouse Enabled", "rgb(0, 255, 0)" });
    if (config.HarmonicInvtervalSpacing) items.push_back({ "Harmonic Interval Spacing Enabled", "rgb(0, 255, 0)" });

    static const char* arrowKeys[4] = { "arrowleft", "arrowright", "arrowup", "arrowdown" };
    static const char* arrowNames[4] = { "Left Arrow", "Right Arrow", "Up Arrow", "Down Arrow" };
    for (int i = 0; i < 4; i++) {
        auto it = toggleHeldKeys.find(arrowKeys[i]);
        if (it != toggleHeldKeys.end() && it->second) {
            items.push_back({ std::string("Toggled Holding ") + arrowNames[i], "rgb(255, 145, 0)" });
        }
    }
    return items;
}

bool Engine::divisionLineVisible() const {
    bool interacting = mouse.isDown ||
                       activeKeys.count("arrowleft") || activeKeys.count("arrowright") ||
                       activeKeys.count("arrowup") || activeKeys.count("arrowdown");
    return (interacting && config.AlwaysShowDivisionOnInteraction) ||
           (!interacting && config.AlwaysShowDivisionOnIdle);
}

std::vector<std::pair<std::string, std::string>> Engine::legendEntries() const {
    return notation ? notation->ordinalTypes() : std::vector<std::pair<std::string, std::string>>();
}

std::string Engine::aliasFor(const Ord& ord) const {
    std::string aliasName;
    for (const auto& [name, defOrd] : notation->aliases()) {
        if (notation->cmp(ord, defOrd) == 0) aliasName = name; // last match wins (JS forEach)
    }
    return aliasName;
}

// ---------------------------------------------------------------- formatting

std::string Engine::formatBigIntZoom(const BigInt& currentWidthBI, const BigInt& canvasWidthBI) {
    if (currentWidthBI.sgn() <= 0 || canvasWidthBI.isZero()) return "1.00x";

    std::string sNum = currentWidthBI.toString();
    std::string sDen = canvasWidthBI.toString();
    if (sNum[0] == '-') sNum = sNum.substr(1);
    if (sDen[0] == '-') sDen = sDen.substr(1);

    long long len1 = (long long)sNum.size();
    long long len2 = (long long)sDen.size();

    double mant1 = strtod(sNum.substr(0, 15).c_str(), nullptr) / std::pow(10.0, (double)(std::min(15LL, len1) - 1));
    double mant2 = strtod(sDen.substr(0, 15).c_str(), nullptr) / std::pow(10.0, (double)(std::min(15LL, len2) - 1));

    double mantissa = mant1 / mant2;
    long long exp = len1 - len2;

    if (mantissa >= 10) {
        mantissa /= 10;
        exp += 1;
    } else if (mantissa < 1 && mantissa > 0) {
        mantissa *= 10;
        exp -= 1;
    }

    if (exp >= -2 && exp <= 4) {
        double val = mantissa * std::pow(10.0, (double)exp);
        return toFixed(val, 2) + "x";
    }
    // JS template `e+${exp}` prints negative exp with its minus sign: "e+-3"
    return toFixed(mantissa, 2) + "e+" + std::to_string(exp) + "x";
}

std::string Engine::formatBigIntFraction(const BigInt& numerator, const BigInt& denominator, int decimals) {
    if (denominator.isZero()) {
        int md0 = std::max(4, decimals);
        return "0." + std::string((size_t)md0, '0');
    }
    bool isNegative = (numerator.sgn() < 0) != (denominator.sgn() < 0);
    BigInt num = numerator.sgn() < 0 ? -numerator : numerator;
    BigInt den = denominator.sgn() < 0 ? -denominator : denominator;

    int maxDecimals = std::max(4, decimals);
    BigInt scale = BigInt::pow10(maxDecimals);
    BigInt scaledNum = (num * scale) / den;
    std::string str = scaledNum.toString();
    if ((long long)str.size() < maxDecimals + 1) {
        str = std::string((size_t)(maxDecimals + 1) - str.size(), '0') + str;
    }
    std::string intPart = str.substr(0, str.size() - (size_t)maxDecimals);
    std::string fracPart = str.substr(str.size() - (size_t)maxDecimals);
    if (intPart.empty()) intPart = "0";

    bool fracNonZero = fracPart.find_first_of("123456789") != std::string::npos;
    std::string sign = (isNegative && (intPart != "0" || fracNonZero)) ? "-" : "";
    return sign + intPart + "." + fracPart;
}

void Engine::updateCameraStats() {
    BigInt currentWidthBI = x1 - x0;
    BigInt canvasWidthBI = toBigInt((double)W);
    zoomText = "Zoom: " + formatBigIntZoom(currentWidthBI, canvasWidthBI);

    long long expDiff = currentWidthBI.numDigits() - canvasWidthBI.numDigits();
    long long log10Zoom = std::max(0LL, expDiff);
    int mantissa = config.BigIntPrecisionMantissa ? config.BigIntPrecisionMantissa : 8;
    int decimalPlaces = (int)std::max(4LL, log10Zoom + mantissa);

    BigInt centerScreenBI = toBigInt(W / 2.0);
    BigInt numBI = centerScreenBI - x0;
    posText = "World Position: " + formatBigIntFraction(numBI, currentWidthBI, decimalPlaces);
}

// ------------------------------------------------------------------ tooltip --

int Engine::getOrdinalDepth(const Ord& a, const Ord& limitOrd) const {
    if (notation->cmp(a, limitOrd) == 0) return 0;

    Ord current = limitOrd;
    int depth = 0;
    const int maxSafetyIter = 1000;

    while (notation->cmp(current, a) > 0 && depth < maxSafetyIter) {
        Ord nextTerm;
        for (long long k = 0; k < 10000; k++) {
            Ord term = notation->fs(current, k);
            if (notation->cmp(term, a) >= 0) {
                nextTerm = term;
                break;
            }
        }
        if (!nextTerm) break;

        current = nextTerm;
        depth++;

        if (notation->cmp(current, a) == 0) return depth;
    }
    return depth;
}

std::string Engine::buildTooltip(double px, double py) const {
    if (!config.ShowCursorTooltip || !notation) return "";

    double slope = config.DiagonalTickArrangement ? config.TickSlopeArrangement : 0;
    double lineY = (H / 2.0) + (slope * H * (px / (double)W - 0.5));

    double proximity = std::max(40.0, H * config.Tickheight * 1.5);
    if (std::fabs(py - lineY) > proximity) return "";

    const TickEntry* tick = nullptr;
    long long targetX = (long long)std::floor(px);
    long long tickX = -1;

    for (long long x = targetX; x >= 0; x--) {
        if ((size_t)x < ticks.size() && ticks[(size_t)x].valid && ticks[(size_t)x].ord) {
            tick = &ticks[(size_t)x];
            tickX = x;
            break;
        }
    }
    if (!tick) {
        for (long long x = targetX + 1; x < (long long)ticks.size(); x++) {
            if (ticks[(size_t)x].valid && ticks[(size_t)x].ord) {
                tick = &ticks[(size_t)x];
                tickX = x;
                break;
            }
        }
    }
    if (!tick || !tick->ord) return "";

    Ord ord = tick->ord;

    int primaryMode = !config.modes.empty() ? config.modes[0].mode : 0;
    auto names = notation->displayNames();
    std::string modeName = (primaryMode >= 0 && (size_t)primaryMode < names.size())
                               ? names[(size_t)primaryMode]
                               : std::to_string(primaryMode);
    std::string ordStr = notation->display(ord, modeName);

    std::string classification = "Unknown";
    std::string hexLower = toLowerCopy(tick->color);
    if (!hexLower.empty()) {
        if (hexLower == "#ffffff" || notation->cmp(ord, notation->limit()) == 0) {
            classification = "Limit";
        } else {
            for (const auto& [name, col] : notation->ordinalTypes()) {
                if (!col.empty() && toLowerCopy(col) == hexLower) {
                    classification = name;
                    break;
                }
            }
        }
    }
    if (classification == "Unknown") {
        if (notation->cmp(ord, notation->zero()) == 0) classification = "Zero";
        else if (notation->isSuccessor(ord)) classification = "Successor Ordinal";
        else classification = "Normal";
    }

    BigInt currentWidthBI = x1 - x0;
    BigInt numBI = toBigInt((double)tickX) - x0;
    std::string posStr = formatBigIntFraction(numBI, currentWidthBI, 8);

    int depthInt = getOrdinalDepth(ord, notation->limit());

    std::string aliasesStr;
    {
        std::vector<std::string> found;
        for (const auto& [name, defOrd] : notation->aliases()) {
            if (notation->cmp(ord, defOrd) == 0) found.push_back(name);
        }
        for (size_t i = 0; i < found.size(); i++) {
            if (i) aliasesStr += ", ";
            aliasesStr += found[i];
        }
    }

    bool isLimit = notation->cmp(ord, notation->limit()) == 0 ||
                   (!notation->isSuccessor(ord) && notation->cmp(ord, notation->zero()) != 0);

    std::string fsLines;
    if (isLimit) {
        fsLines = "\nFundamental Sequence:\n";
        for (int i = 0; i <= config.tooltipfsterms; i++) {
            try {
                Ord term = notation->fs(ord, i);
                fsLines += std::to_string(i) + ": " + notation->display(term, modeName) + "\n";
            } catch (...) {
                fsLines += std::to_string(i) + ": -\n";
            }
        }
        fsLines += "...";
    }

    std::string text = "Ordinal: " + ordStr + "\n";
    text += "Classification: " + classification + "\n";
    text += "Position: " + posStr + "\n";
    text += "Depth: " + std::to_string(depthInt) + "\n";
    if (!aliasesStr.empty()) text += "Description : " + aliasesStr + "\n";
    text += fsLines;
    return text;
}

// ----------------------------------------------------------------- viewport --

void Engine::resetViewport() {
    if (settingsOpen) return;
    history.push_back({ x0, x1 });

    double minZoom = W * 0.8;
    x0 = toBigInt(0.5 * (W - minZoom));
    x1 = toBigInt(0.5 * (W + minZoom));
    dirty = true;
}

void Engine::resize(int newW, int newH) {
    int oldWidth = W;
    W = newW;
    H = newH;
    if (oldWidth > 0 && newW > 0) {
        BigInt widthRatioBI = toBigInt((double)newW / (double)oldWidth);
        x0 = mulDivScale(x0, widthRatioBI, PRECISION_SCALE);
        x1 = mulDivScale(x1, widthRatioBI, PRECISION_SCALE);
    }
    dirty = true;
}

void Engine::init() {
    PRECISION_SCALE = BigInt::pow10(10);
    history.clear();
    selection.active = false;

    double minZoom = W * 0.8;
    x0 = toBigInt(0.5 * (W - minZoom));
    x1 = toBigInt(0.5 * (W + minZoom));
    dirty = true;
}

void Engine::clampViewportBounds() {
    if (!config.PanOutFencing) return;

    BigInt minOverlap = toBigInt(W * config.panFenceOverlap);
    BigInt currentWidth = x1 - x0;
    BigInt canvasWidthBI = toBigInt((double)W);

    if (x0 > canvasWidthBI - minOverlap) {
        x0 = canvasWidthBI - minOverlap;
        x1 = x0 + currentWidth;
    }
    if (x1 < minOverlap) {
        x1 = minOverlap;
        x0 = x1 - currentWidth;
    }
}

void Engine::applySelectionZoom() {
    if (!config.SlowMode || !selection.active) return;
    selection.active = false;

    double xStart = std::min(selection.startX, selection.currentX);
    double xEnd = std::max(selection.startX, selection.currentX);

    if (xEnd - xStart > 5) {
        history.push_back({ x0, x1 });

        BigInt W_BI = toBigInt((double)W);
        BigInt xStartBI = toBigInt(xStart);
        BigInt boxW_BI = toBigInt(xEnd - xStart);

        if (!boxW_BI.isZero()) {
            x0 = (x0 - xStartBI) * W_BI / boxW_BI;
            x1 = (x1 - xStartBI) * W_BI / boxW_BI;
        }

        clampViewportBounds();
        dirty = true;
    }
}

bool Engine::undoViewport() {
    if (settingsOpen) return false;
    if (!history.empty()) {
        auto prev = history.back();
        history.pop_back();
        x0 = prev.first;
        x1 = prev.second;
        dirty = true;
        return true;
    }
    return false;
}

// -------------------------------------------------------------------- input --

void Engine::pointerDown(double x, double y) {
    if (config.LockScreen || settingsOpen) return;
    mouse.isDown = true;
    mouse.lastX = x;
    mouse.lastY = y;

    if (config.SlowMode) {
        selection.active = true;
        selection.startX = x;
        selection.startY = y;
        selection.currentX = x;
        selection.currentY = y;
    }
}

void Engine::pointerMove(double clientX, double clientY) {
    if (config.LockScreen || settingsOpen || !mouse.isDown) return;

    double movementX = clientX - mouse.lastX;
    double movementY = clientY - mouse.lastY;

    mouse.lastX = clientX;
    mouse.lastY = clientY;

    if (config.SlowMode) {
        selection.currentX = clientX;
        selection.currentY = clientY;
        return;
    }

    BigInt dxBI = toBigInt(movementX);
    double dy = movementY;

    x0 += dxBI;
    x1 += dxBI;

    if (dy != 0) {
        double zoomFactor = std::max(0.05, 1 - (dy * config.zoomDragFactor));
        BigInt zoomFactorBI = toBigInt(zoomFactor);
        double targetX = config.ZoomIntoMouse ? clientX : (W / 2.0);
        BigInt mxBI = toBigInt(targetX);

        BigInt nextX0 = mxBI + mulDivScale(x0 - mxBI, zoomFactorBI, PRECISION_SCALE);
        BigInt nextX1 = mxBI + mulDivScale(x1 - mxBI, zoomFactorBI, PRECISION_SCALE);
        BigInt maxAllowedWidthBI = toBigInt(W * config.maxAllowedWidthFactor);

        if (!config.ZoomOutFencing || ((nextX1 - nextX0) >= maxAllowedWidthBI)) {
            x0 = nextX0;
            x1 = nextX1;
        } else {
            BigInt currentWidth = x1 - x0;
            if (currentWidth.sgn() > 0) {
                BigInt scaleToLimitBI = (maxAllowedWidthBI * PRECISION_SCALE) / currentWidth;
                x0 = mxBI + mulDivScale(x0 - mxBI, scaleToLimitBI, PRECISION_SCALE);
                x1 = mxBI + mulDivScale(x1 - mxBI, scaleToLimitBI, PRECISION_SCALE);
            }
        }
    }

    clampViewportBounds();
    dirty = true;
}

void Engine::pointerUp() {
    mouse.isDown = false;
    applySelectionZoom();
}

void Engine::wheel(double deltaY, double clientX) {
    if (config.LockScreen) return;
    if (settingsOpen || config.SlowMode) return;

    double zoomFactor = deltaY < 0 ? config.wheelZoomIn : config.wheelZoomOut;
    BigInt zoomFactorBI = toBigInt(zoomFactor);
    BigInt mxBI = toBigInt(clientX);
    BigInt maxAllowedWidthBI = toBigInt(W * config.maxAllowedWidthFactor);

    if (!config.ZoomOutFencing || ((x1 - x0) >= maxAllowedWidthBI || deltaY < 0)) {
        x0 = mxBI + mulDivScale(x0 - mxBI, zoomFactorBI, PRECISION_SCALE);
        x1 = mxBI + mulDivScale(x1 - mxBI, zoomFactorBI, PRECISION_SCALE);
    }
    clampViewportBounds();
    dirty = true;
}

void Engine::stepKeyboard(double dtSeconds) {
    if (settingsOpen || config.LockScreen) return;

    double totalDt = std::min(dtSeconds, 1.0);

    if (activeKeys.count("shift")) {
        totalDt *= config.shiftMultiplier;
    } else if (activeKeys.count("control") || activeKeys.count("ctrl")) {
        totalDt *= config.ctrlMultiplier;
    }

    bool moved = false;

    if (!config.SlowMode) {
        const double FIXED_STEP = 1.0 / 60.0;
        double accumulator = totalDt;

        while (accumulator > 0) {
            double dt = std::min(accumulator, FIXED_STEP);
            accumulator -= dt;

            BigInt panSpeedBI = toBigInt(W * config.panSpeedBaseFactor * dt);
            BigInt zoomFactorInBI = toBigInt(std::pow(config.zoomSpeedBase, dt));
            BigInt zoomFactorOutBI = toBigInt(std::pow(1 / config.zoomSpeedBase, dt));
            BigInt mxBI = toBigInt(W / 2.0);

            if (activeKeys.count("arrowleft")) {
                x0 += panSpeedBI;
                x1 += panSpeedBI;
                moved = true;
            }
            if (activeKeys.count("arrowright")) {
                x0 -= panSpeedBI;
                x1 -= panSpeedBI;
                moved = true;
            }
            if (activeKeys.count("arrowup")) {
                x0 = mxBI + mulDivScale(x0 - mxBI, zoomFactorInBI, PRECISION_SCALE);
                x1 = mxBI + mulDivScale(x1 - mxBI, zoomFactorInBI, PRECISION_SCALE);
                moved = true;
            }
            if (activeKeys.count("arrowdown")) {
                BigInt currentWidth = x1 - x0;
                BigInt maxAllowedWidthBI = toBigInt(W * config.maxAllowedWidthFactor);
                BigInt targetWidth = mulDivScale(currentWidth, zoomFactorOutBI, PRECISION_SCALE);

                if (!config.ZoomOutFencing || targetWidth >= maxAllowedWidthBI) {
                    x0 = mxBI + mulDivScale(x0 - mxBI, zoomFactorOutBI, PRECISION_SCALE);
                    x1 = mxBI + mulDivScale(x1 - mxBI, zoomFactorOutBI, PRECISION_SCALE);
                } else if (currentWidth.sgn() > 0) {
                    BigInt scaleToLimitBI = (maxAllowedWidthBI * PRECISION_SCALE) / currentWidth;
                    x0 = mxBI + mulDivScale(x0 - mxBI, scaleToLimitBI, PRECISION_SCALE);
                    x1 = mxBI + mulDivScale(x1 - mxBI, scaleToLimitBI, PRECISION_SCALE);
                }
                moved = true;
            }
        }
    }

    if (moved) {
        clampViewportBounds();
        dirty = true;
    }
}

// ------------------------------------------------------------ ui.js helpers --

BigInt Engine::parseToBigIntScaled(const std::string& strIn, const BigInt& scale) {
    std::string str = trimCopy(strIn);
    if (str.empty()) throw std::runtime_error("Invalid string");
    str = toLowerCopy(str);

    bool isNegative = false;
    if (str[0] == '-') {
        isNegative = true;
        str = str.substr(1);
    } else if (str[0] == '+') {
        str = str.substr(1);
    }

    long long expVal = 0;
    std::string coeff = str;
    size_t epos = str.find('e');
    if (epos != std::string::npos) {
        coeff = str.substr(0, epos);
        std::string expStr = str.substr(epos + 1);
        if (expStr.empty()) throw std::runtime_error("Invalid string");
        try {
            expVal = std::stoll(expStr);
        } catch (...) {
            throw std::runtime_error("Invalid string");
        }
    }

    std::string intPart = coeff, fracPart;
    size_t dot = coeff.find('.');
    if (dot != std::string::npos) {
        intPart = coeff.substr(0, dot);
        fracPart = coeff.substr(dot + 1);
    }

    std::string combined = intPart + fracPart;
    size_t nz = combined.find_first_not_of('0');
    combined = (nz == std::string::npos) ? "0" : combined.substr(nz);

    for (char c : combined) {
        if (!isdigit((unsigned char)c)) throw std::runtime_error("Invalid string");
    }

    long long netExponent = expVal - (long long)fracPart.size();
    BigInt baseBI = BigInt::parseDecimal(combined);
    BigInt result;

    if (netExponent >= 0) {
        result = baseBI.mulPow10(netExponent) * scale;
    } else {
        result = (baseBI * scale).divPow10(-netExponent);
    }

    return isNegative ? -result : result;
}

bool Engine::triggerViewportZoom(const std::string& posStrIn, const std::string& zoomStrIn, std::string& err) {
    std::string posStr = trimCopy(posStrIn);
    std::string zoomStr = trimCopy(zoomStrIn);

    if (posStr.empty() || zoomStr.empty()) {
        err = "Invalid position or zoom";
        return false;
    }

    std::string zlow = toLowerCopy(zoomStr);
    long long expVal = 0;
    size_t epos = zlow.find('e');
    if (epos != std::string::npos) {
        expVal = (long long)strtol(zlow.c_str() + epos + 1, nullptr, 10);
    }

    int mantissa = config.BigIntPrecisionMantissa ? config.BigIntPrecisionMantissa : 8;
    long long requiredDigits = std::max(35LL, std::llabs(expVal) + mantissa + 50);
    BigInt nextScale = BigInt::pow10(requiredDigits);

    if (nextScale > PRECISION_SCALE) {
        long long oldE = scaleExp(PRECISION_SCALE);
        x0 = x0.mulPow10(requiredDigits - oldE);
        x1 = x1.mulPow10(requiredDigits - oldE);
        PRECISION_SCALE = nextScale;
    }

    BigInt pos, zoom;
    try {
        pos = parseToBigIntScaled(posStr, PRECISION_SCALE);
        zoom = parseToBigIntScaled(zoomStr, PRECISION_SCALE);
    } catch (...) {
        err = "Invalid position or zoom";
        return false;
    }

    if (zoom.sgn() <= 0) {
        err = "Invalid position or zoom";
        return false;
    }

    history.push_back({ x0, x1 });

    BigInt canvasWidthBI = toBigInt((double)W);
    BigInt widthBI = mulDivScale(canvasWidthBI, zoom, PRECISION_SCALE);
    BigInt centerScreenBI = toBigInt(W / 2.0);

    BigInt nx0 = centerScreenBI - mulDivScale(widthBI, pos, PRECISION_SCALE);
    x0 = nx0;
    x1 = nx0 + widthBI;
    dirty = true;
    return true;
}

FindResult Engine::findOrdinalPathBigInt(const Ord& targetOrd, int precisionDigits) const {
    BigInt SCALE = BigInt::pow10(precisionDigits);
    BigInt X0(0);
    BigInt X1 = SCALE;
    Ord o0 = notation->zero();
    Ord o1 = notation->limit();
    Ord Zero = o0, Limit = o1;
    long long lefts = 0;

    for (;;) {
        if (notation->cmp(o0, targetOrd) == 0) {
            return { true, X0, X1 - X0, SCALE };
        }
        if (notation->cmp(targetOrd, o0) < 0 || notation->cmp(targetOrd, o1) >= 0) {
            break;
        }

        if (notation->cmp(o1, Limit) == 0 || (!notation->isSuccessor(o1) && notation->cmp(o1, Zero) != 0)) {
            double rescaleNum = config.HarmonicInvtervalSpacing ? 1.0 : 2.0 / (double)(lefts + 2);
            long long m = 2;
            std::vector<Ord> seq((size_t)m);
            for (long long idx = 0; idx < m; idx++) seq[(size_t)idx] = notation->fs(o1, idx);
            long long ofs = 0;
            for (ofs = 0; ofs < m && notation->cmp(seq[(size_t)ofs], o0) <= 0; ofs++)
                ;

            long long n = 0;
            bool foundSub = false;
            while (true) {
                if (ofs + n >= m) {
                    m = ofs + n + 5;
                    seq.assign((size_t)m, Ord());
                    for (long long idx = 0; idx < m; idx++) seq[(size_t)idx] = notation->fs(o1, idx);
                }
                Ord next_o0 = (n == 0) ? o0 : seq[(size_t)(ofs + n - 1)];
                Ord next_o1 = seq[(size_t)(ofs + n)];

                if (notation->cmp(targetOrd, next_o0) >= 0 && notation->cmp(targetOrd, next_o1) < 0) {
                    bool isZeroEnd = (ofs < m && notation->lastEntryIsZero(seq[(size_t)ofs]));
                    double actualRescaleNum = isZeroEnd ? 1.0 : rescaleNum;
                    BigInt s_x0 = X0, s_x1 = X0;

                    for (long long step = 0; step <= n; step++) {
                        if (step > 0) s_x0 = s_x1;
                        double rNum = step ? 1.0 : actualRescaleNum;
                        BigInt factor((long long)std::round(rNum * config.aspectratio * 1e6));
                        s_x1 = X1 + (s_x0 - X1) * factor / BigInt(1000000);
                    }
                    X0 = s_x0;
                    X1 = s_x1;
                    o0 = next_o0;
                    o1 = next_o1;
                    lefts = (n == 0) ? lefts + 1 : 0;
                    foundSub = true;
                    break;
                }
                n++;
            }
            if (foundSub) continue;
        }
        break;
    }
    return { false, BigInt(), BigInt(), BigInt() };
}

bool Engine::findAndZoomToOrdinal(const std::string& inputStrIn, int precisionDigits, std::string& err) {
    std::string inputStr = trimCopy(inputStrIn);
    if (inputStr.empty()) return false;

    if (!notation->hasParser()) {
        err = "The current notation system does not support parsing.";
        return false;
    }

    Ord targetOrd;
    try {
        targetOrd = notation->parse(inputStr);
    } catch (const std::exception& e) {
        err = std::string("Failed to parse ordinal: ") + e.what();
        return false;
    }
    if (!targetOrd) {
        err = "Failed to parse ordinal.";
        return false;
    }

    FindResult P = findOrdinalPathBigInt(targetOrd, precisionDigits);

    if (P.found) {
        history.push_back({ x0, x1 });
        BigInt pWidth = P.width.sgn() <= 0 ? BigInt(1) : P.width;
        BigInt targetPixelWidthBI = toBigInt(W * 0.1);
        BigInt totalWidth_BI = (targetPixelWidthBI * P.scale) / pWidth;
        BigInt centerOffsetBI = toBigInt(W / 2.0);
        long long scaleE = scaleExp(P.scale);
        x0 = centerOffsetBI - (totalWidth_BI * P.x).divPow10(scaleE);
        x1 = x0 + totalWidth_BI;
        config.MaxIntervalDepth = -1;

        clampViewportBounds();
        dirty = true;
        return true;
    }
    err = "Ordinal parsed, but could not be located on the timeline (too deep or not a rendered component).";
    return false;
}

void Engine::setNotation(const std::shared_ptr<Notation>& n) {
    notation = n;
    config.modes = n->initialModes();
    init();
}
