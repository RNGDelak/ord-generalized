@echo off
cd /d C:\Users\DELL\Documents\Qoder\2026-09-27\3a26177d\ord-cpp
if not exist vendor mkdir vendor
if not exist vendor\glad\include\glad mkdir vendor\glad\include\glad
if not exist vendor\glad\include\KHR mkdir vendor\glad\include\KHR
if not exist vendor\stb mkdir vendor\stb
if not exist vendor\downloads mkdir vendor\downloads

echo [1/6] glad.c > vendor\dl.log
curl -L --retry 3 -o vendor\glad\glad.c https://raw.githubusercontent.com/JoeyDeVries/LearnOpenGL/master/src/glad.c >> vendor\dl.log 2>&1
echo [2/6] glad.h >> vendor\dl.log
curl -L --retry 3 -o vendor\glad\include\glad\glad.h https://raw.githubusercontent.com/JoeyDeVries/LearnOpenGL/master/include/glad/glad.h >> vendor\dl.log 2>&1
echo [3/6] khrplatform.h >> vendor\dl.log
curl -L --retry 3 -o vendor\glad\include\KHR\khrplatform.h https://raw.githubusercontent.com/JoeyDeVries/LearnOpenGL/master/include/KHR/khrplatform.h >> vendor\dl.log 2>&1
echo [4/6] stb_truetype.h >> vendor\dl.log
curl -L --retry 3 -o vendor\stb\stb_truetype.h https://raw.githubusercontent.com/nothings/stb/master/stb_truetype.h >> vendor\dl.log 2>&1
echo [5/6] imgui zip >> vendor\dl.log
curl -L --retry 3 -o vendor\downloads\imgui.zip https://github.com/ocornut/imgui/archive/refs/tags/v1.91.8.zip >> vendor\dl.log 2>&1
echo [6/6] glfw zip >> vendor\dl.log
curl -L --retry 3 -o vendor\downloads\glfw.zip https://github.com/glfw/glfw/releases/download/3.4/glfw-3.4.zip >> vendor\dl.log 2>&1
echo DONE >> vendor\dl.log
